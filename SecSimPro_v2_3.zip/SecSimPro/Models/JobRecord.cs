using System;
using System.Collections.Generic;

namespace SecSimPro.Models
{
    // ─────────────────────────────────────────────────────────────────────────
    //  Job state per SEMI E40 (Process Job Management)
    // ─────────────────────────────────────────────────────────────────────────
    public enum JobState
    {
        Unknown,
        Queued,
        Executing,
        Paused,
        Completed,
        Aborted,
        Stopped
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Per-slot result
    // ─────────────────────────────────────────────────────────────────────────
    public enum SlotState
    {
        Empty,
        Pending,
        Processing,
        Pass,
        Fail,
        Skipped,
        Unknown
    }

    public class SlotResult
    {
        public int       SlotNumber  { get; set; }
        public string    SubstrateId { get; set; }
        public SlotState State       { get; set; } = SlotState.Unknown;
        public string    Result      { get; set; }
        public DateTime? ProcessedAt { get; set; }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Job event (one S6F11 received)
    // ─────────────────────────────────────────────────────────────────────────
    public class JobEvent
    {
        public DateTime          Timestamp   { get; set; } = DateTime.Now;
        public uint              CeidValue   { get; set; }
        public string            CeidName    { get; set; }
        public string            JobId       { get; set; }
        public Dictionary<string, string> Data { get; set; } = new Dictionary<string, string>();

        public string DataSummary
        {
            get
            {
                var parts = new List<string>();
                foreach (var kv in Data)
                    parts.Add(string.Format("{0}={1}", kv.Key, kv.Value));
                return string.Join("  ", parts);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Job record — full lifecycle of one process job
    // ─────────────────────────────────────────────────────────────────────────
    public class JobRecord
    {
        public string       JobId          { get; set; } = "";
        public string       RecipeId       { get; set; } = "";
        public string       LotId          { get; set; } = "";
        public string       CarrierId      { get; set; } = "";
        public JobState     State          { get; set; } = JobState.Unknown;
        public DateTime?    CreatedAt      { get; set; }
        public DateTime?    StartedAt      { get; set; }
        public DateTime?    FinishedAt     { get; set; }
        public string       ProcessResult  { get; set; } = "";
        public string       AbortReason    { get; set; } = "";

        public List<SlotResult>  Slots  { get; set; } = new List<SlotResult>();
        public List<JobEvent>    Events { get; set; } = new List<JobEvent>();

        public TimeSpan? ElapsedTime =>
            StartedAt.HasValue
                ? (FinishedAt.HasValue ? FinishedAt.Value - StartedAt.Value
                                        : DateTime.Now    - StartedAt.Value)
                : (TimeSpan?)null;

        public bool IsActive =>
            State == JobState.Queued   ||
            State == JobState.Executing ||
            State == JobState.Paused;

        public bool IsComplete =>
            State == JobState.Completed ||
            State == JobState.Aborted   ||
            State == JobState.Stopped;

        public string StateDisplay
        {
            get
            {
                switch (State)
                {
                    case JobState.Queued:    return "QUEUED";
                    case JobState.Executing: return "EXECUTING";
                    case JobState.Paused:    return "PAUSED";
                    case JobState.Completed: return "COMPLETED";
                    case JobState.Aborted:   return "ABORTED";
                    case JobState.Stopped:   return "STOPPED";
                    default:                 return "UNKNOWN";
                }
            }
        }

        public JobRecord()
        {
            // Pre-populate 25 slots (standard FOUP)
            for (int i = 1; i <= 25; i++)
                Slots.Add(new SlotResult { SlotNumber = i, State = SlotState.Empty });
        }

        public void SetSlotState(int slot, SlotState state, string result = "")
        {
            if (slot < 1 || slot > Slots.Count) return;
            var s = Slots[slot - 1];
            s.State       = state;
            s.Result      = result;
            s.ProcessedAt = DateTime.Now;
        }
    }
}
