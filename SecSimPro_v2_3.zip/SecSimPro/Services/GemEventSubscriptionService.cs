using System;
using System.Collections.Generic;
using System.Threading;
using SecSimPro.Models;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  GemEventSubscriptionService
    //
    //  Sends the standard GEM report definition sequence after GEM Online:
    //
    //    S2F33 — Define Reports    (create ReportIDs with their DVIDs)
    //    S2F35 — Link Event-Report (bind CEIDs to ReportIDs)
    //    S2F37 — Enable/Disable CE (enable all job CEIDs)
    //
    //  The host must send these before any S6F11 event reports will arrive.
    //  This service is called automatically when GemOnline is achieved.
    // ─────────────────────────────────────────────────────────────────────────
    public class GemEventSubscriptionService
    {
        // ── Report definitions ────────────────────────────────
        //  ReportID 1  — Job start data
        //  ReportID 2  — Job finish data
        //  ReportID 3  — Job abort data
        //  ReportID 4  — Substrate processing data
        //  ReportID 5  — Alarm data

        private static readonly Dictionary<uint, uint[]> ReportDvids
            = new Dictionary<uint, uint[]>
        {
            { 1, new uint[] { GemDvid.ProcessJobId, GemDvid.RecipeId,
                              GemDvid.LotId, GemDvid.CarrierId,
                              GemDvid.StartTime } },

            { 2, new uint[] { GemDvid.ProcessJobId, GemDvid.RecipeId,
                              GemDvid.LotId, GemDvid.EndTime,
                              GemDvid.ProcessResult } },

            { 3, new uint[] { GemDvid.ProcessJobId, GemDvid.AbortReason } },

            { 4, new uint[] { GemDvid.ProcessJobId, GemDvid.SubstrateId,
                              GemDvid.SlotNumber } },

            { 5, new uint[] { GemDvid.AlarmId, GemDvid.AlarmText,
                              GemDvid.ProcessJobId } },
        };

        // CEID → ReportID mapping
        private static readonly Dictionary<uint, uint> CeidToReport
            = new Dictionary<uint, uint>
        {
            // Job start events → Report 1
            { GemCeid.ProcessJobCreated,         1 },
            { GemCeid.ProcessJobQueued,          1 },
            { GemCeid.ProcessJobStarted,         1 },
            { GemCeid.ProcessJobPaused,          1 },
            { GemCeid.ProcessJobResumed,         1 },
            { GemCeid.ControlJobCreated,         1 },
            { GemCeid.ControlJobStarted,         1 },

            // Job finish events → Report 2
            { GemCeid.ProcessJobFinished,        2 },
            { GemCeid.ProcessJobStopped,         2 },
            { GemCeid.ProcessJobCancelled,       2 },
            { GemCeid.ControlJobCompleted,       2 },

            // Job abort events → Report 3
            { GemCeid.ProcessJobAborted,         3 },
            { GemCeid.ControlJobAborted,         3 },

            // Substrate events → Report 4
            { GemCeid.SubstrateProcessingStart,  4 },
            { GemCeid.SubstrateProcessingEnd,    4 },

            // Alarm events → Report 5
            { GemCeid.AlarmSet,                  5 },
            { GemCeid.AlarmCleared,              5 },
        };

        // ── Dependencies ──────────────────────────────────────
        private readonly TcpConnectionService _conn;

        public event EventHandler<string> SubscriptionLog;

        public GemEventSubscriptionService(TcpConnectionService conn)
        {
            _conn = conn;
        }

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Run full subscription sequence
        // ─────────────────────────────────────────────────────
        public void Subscribe(ushort sessionId)
        {
            Log("Event subscription starting (S2F33 → S2F35 → S2F37)...");

            try
            {
                // Small delay — let GEM Online settle
                Thread.Sleep(300);

                // Step 1: Define reports
                if (!SendS2F33(sessionId))
                {
                    Log("S2F33 Define Reports failed — subscription aborted.");
                    return;
                }
                Log("S2F33 Define Reports: OK");

                Thread.Sleep(100);

                // Step 2: Link CEIDs to reports
                if (!SendS2F35(sessionId))
                {
                    Log("S2F35 Link Event-Report failed — subscription aborted.");
                    return;
                }
                Log("S2F35 Link Event-Report: OK");

                Thread.Sleep(100);

                // Step 3: Enable all job CEIDs
                if (!SendS2F37(sessionId, enable: true))
                {
                    Log("S2F37 Enable CEIDs failed.");
                    return;
                }
                Log(string.Format("S2F37 Enable CEIDs: OK — {0} CEIDs enabled.",
                    GemCeid.JobCeids.Length));

                Log("Event subscription complete. Equipment will now send S6F11 on job events.");
            }
            catch (Exception ex)
            {
                Log("Subscription error: " + ex.Message);
            }
        }

        // ─────────────────────────────────────────────────────
        //  S2F33 — Define Report
        //
        //  Body: <L n                           -- n reports
        //           <L 2
        //             <U4 ReportID>
        //             <L m <U4 DVID1> ... >    -- m DVIDs
        //           >
        //         >
        // ─────────────────────────────────────────────────────
        private bool SendS2F33(ushort sid)
        {
            var reportItems = new List<byte[]>();

            foreach (var kv in ReportDvids)
            {
                uint   reportId = kv.Key;
                uint[] dvids    = kv.Value;

                // Build DVID list
                var dvidItems = new List<byte[]>();
                foreach (var dvid in dvids)
                    dvidItems.Add(SecsIIMessage.EncodeU4(dvid));

                // <L 2 <U4 ReportID> <L m DVIDs>>
                byte[] reportEntry = SecsIIMessage.EncodeList(
                    SecsIIMessage.EncodeU4(reportId),
                    SecsIIMessage.EncodeList(dvidItems.ToArray()));

                reportItems.Add(reportEntry);
            }

            byte[] body = SecsIIMessage.EncodeList(reportItems.ToArray());

            _conn.SendDataMessage(sid, 2, 33, true, body,
                rspStream: 2, rspFunc: 34,
                onReply: reply =>
                {
                    // S2F34 body: <B DRACK>  (0=ok)
                    byte? ack = ParseSingleByte(reply.Data);
                    Log(string.Format("S2F34 DRACK=0x{0}", ack.HasValue ? ack.Value.ToString("X2") : "??"));
                    return ack.HasValue && ack.Value == 0;
                });

            return true; // fire-and-forget for now; failure caught by reply handler
        }

        // ─────────────────────────────────────────────────────
        //  S2F35 — Link Event Report
        //
        //  Body: <L n                           -- n events
        //           <L 2
        //             <U4 CEID>
        //             <L m <U4 ReportID1> ...>
        //           >
        //         >
        // ─────────────────────────────────────────────────────
        private bool SendS2F35(ushort sid)
        {
            var ceItems = new List<byte[]>();

            foreach (var kv in CeidToReport)
            {
                uint ceid     = kv.Key;
                uint reportId = kv.Value;

                byte[] ceEntry = SecsIIMessage.EncodeList(
                    SecsIIMessage.EncodeU4(ceid),
                    SecsIIMessage.EncodeList(
                        SecsIIMessage.EncodeU4(reportId)));

                ceItems.Add(ceEntry);
            }

            byte[] body = SecsIIMessage.EncodeList(ceItems.ToArray());

            _conn.SendDataMessage(sid, 2, 35, true, body,
                rspStream: 2, rspFunc: 36,
                onReply: reply =>
                {
                    byte? ack = ParseSingleByte(reply.Data);
                    Log(string.Format("S2F36 LRACK=0x{0}", ack.HasValue ? ack.Value.ToString("X2") : "??"));
                    return ack.HasValue && ack.Value == 0;
                });

            return true;
        }

        // ─────────────────────────────────────────────────────
        //  S2F37 — Enable/Disable Collection Event
        //
        //  Body: <L 2
        //           <B CEED>       -- 0=disable, 1=enable
        //           <L n <U4 CEID1> ...>
        //         >
        // ─────────────────────────────────────────────────────
        private bool SendS2F37(ushort sid, bool enable)
        {
            var ceidItems = new List<byte[]>();
            foreach (var ceid in GemCeid.JobCeids)
                ceidItems.Add(SecsIIMessage.EncodeU4(ceid));

            byte[] body = SecsIIMessage.EncodeList(
                SecsIIMessage.EncodeBinary(enable ? (byte)1 : (byte)0),
                SecsIIMessage.EncodeList(ceidItems.ToArray()));

            _conn.SendDataMessage(sid, 2, 37, true, body,
                rspStream: 2, rspFunc: 38,
                onReply: reply =>
                {
                    byte? ack = ParseSingleByte(reply.Data);
                    Log(string.Format("S2F38 ERACK=0x{0}", ack.HasValue ? ack.Value.ToString("X2") : "??"));
                    return ack.HasValue && ack.Value == 0;
                });

            return true;
        }

        // ─────────────────────────────────────────────────────
        //  Helper: parse first byte from a binary SECS-II item
        // ─────────────────────────────────────────────────────
        private static byte? ParseSingleByte(byte[] body)
        {
            if (body == null || body.Length < 2) return null;
            if ((body[0] & 0xFC) != (byte)SecsFormat.Binary) return null;
            int lenBytes = body[0] & 0x03;
            if (lenBytes == 0 || body.Length < 1 + lenBytes + 1) return null;
            return body[1 + lenBytes];
        }

        private void Log(string msg) =>
            SubscriptionLog?.Invoke(this, msg);
    }
}
