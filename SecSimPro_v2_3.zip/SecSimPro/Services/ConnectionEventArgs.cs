using System;

namespace SecSimPro.Services
{
    public enum ConnectionStatus
    {
        Disconnected,
        Connecting,
        TcpConnected,
        Selected,
        GemOnline,
        Error
    }

    public enum LogSeverity { Info, Success, Warning, Error, Hsms, Gem }

    public class ConnectionEventArgs : EventArgs
    {
        public ConnectionStatus Status    { get; set; }
        public string           Message   { get; set; }
        public LogSeverity      Severity  { get; set; }
        public DateTime         Timestamp { get; set; }
        public string           IpAddress { get; set; }
        public int              Port      { get; set; }

        public ConnectionEventArgs(ConnectionStatus status, string message,
                                   LogSeverity severity = LogSeverity.Info,
                                   string ip = "", int port = 0)
        {
            Status    = status;
            Message   = message;
            Severity  = severity;
            Timestamp = DateTime.Now;
            IpAddress = ip;
            Port      = port;
        }
    }
}
