using System.Collections.Generic;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  Standard Cimetrix GEM Collection Event IDs (CEIDs)
    //  Based on Cimetrix ICE standard GEM implementation
    // ─────────────────────────────────────────────────────────────────────────
    public static class GemCeid
    {
        // ── Equipment state ───────────────────────────────────
        public const uint EquipmentOffline         = 1;
        public const uint ControlStateLocal        = 2;
        public const uint ControlStateRemote       = 3;
        public const uint EquipmentOnlineLocal     = 4;
        public const uint EquipmentOnlineRemote    = 5;

        // ── Process Job (SEMI E40) ────────────────────────────
        public const uint ProcessJobCreated        = 30;
        public const uint ProcessJobQueued         = 31;
        public const uint ProcessJobStarted        = 32;
        public const uint ProcessJobPaused         = 33;
        public const uint ProcessJobResumed        = 34;
        public const uint ProcessJobStopped        = 35;
        public const uint ProcessJobFinished       = 36;
        public const uint ProcessJobAborted        = 37;
        public const uint ProcessJobCancelled      = 38;

        // ── Control Job (SEMI E94) ────────────────────────────
        public const uint ControlJobCreated        = 50;
        public const uint ControlJobStarted        = 51;
        public const uint ControlJobCompleted      = 52;
        public const uint ControlJobAborted        = 53;
        public const uint ControlJobPaused         = 54;
        public const uint ControlJobResumed        = 55;

        // ── Substrate / Wafer ─────────────────────────────────
        public const uint SubstrateLocated         = 60;
        public const uint SubstrateProcessingStart = 61;
        public const uint SubstrateProcessingEnd   = 62;
        public const uint SubstrateTransportStart  = 63;
        public const uint SubstrateTransportEnd    = 64;

        // ── Alarms ────────────────────────────────────────────
        public const uint AlarmSet                 = 100;
        public const uint AlarmCleared             = 101;

        // ── Material / Carrier ────────────────────────────────
        public const uint MaterialArrived          = 110;
        public const uint MaterialRemoved          = 111;
        public const uint CarrierDocked            = 112;
        public const uint CarrierUndocked          = 113;

        // ─────────────────────────────────────────────────────
        //  CEID → human-readable name lookup
        // ─────────────────────────────────────────────────────
        private static readonly Dictionary<uint, string> _names
            = new Dictionary<uint, string>
        {
            { EquipmentOffline,          "Equipment Offline"           },
            { ControlStateLocal,         "Control State Local"         },
            { ControlStateRemote,        "Control State Remote"        },
            { EquipmentOnlineLocal,      "Equipment Online Local"      },
            { EquipmentOnlineRemote,     "Equipment Online Remote"     },
            { ProcessJobCreated,         "Process Job Created"         },
            { ProcessJobQueued,          "Process Job Queued"          },
            { ProcessJobStarted,         "Process Job Started"         },
            { ProcessJobPaused,          "Process Job Paused"          },
            { ProcessJobResumed,         "Process Job Resumed"         },
            { ProcessJobStopped,         "Process Job Stopped"         },
            { ProcessJobFinished,        "Process Job Finished"        },
            { ProcessJobAborted,         "Process Job Aborted"         },
            { ProcessJobCancelled,       "Process Job Cancelled"       },
            { ControlJobCreated,         "Control Job Created"         },
            { ControlJobStarted,         "Control Job Started"         },
            { ControlJobCompleted,       "Control Job Completed"       },
            { ControlJobAborted,         "Control Job Aborted"         },
            { ControlJobPaused,          "Control Job Paused"          },
            { ControlJobResumed,         "Control Job Resumed"         },
            { SubstrateLocated,          "Substrate Located"           },
            { SubstrateProcessingStart,  "Substrate Processing Start"  },
            { SubstrateProcessingEnd,    "Substrate Processing End"    },
            { SubstrateTransportStart,   "Substrate Transport Start"   },
            { SubstrateTransportEnd,     "Substrate Transport End"     },
            { AlarmSet,                  "Alarm Set"                   },
            { AlarmCleared,              "Alarm Cleared"               },
            { MaterialArrived,           "Material Arrived"            },
            { MaterialRemoved,           "Material Removed"            },
            { CarrierDocked,             "Carrier Docked"              },
            { CarrierUndocked,           "Carrier Undocked"            },
        };

        public static string GetName(uint ceid)
        {
            string name;
            return _names.TryGetValue(ceid, out name)
                ? name
                : string.Format("CEID {0}", ceid);
        }

        // ─────────────────────────────────────────────────────
        //  Job-related CEIDs we subscribe to
        // ─────────────────────────────────────────────────────
        public static readonly uint[] JobCeids =
        {
            ProcessJobCreated,
            ProcessJobQueued,
            ProcessJobStarted,
            ProcessJobPaused,
            ProcessJobResumed,
            ProcessJobStopped,
            ProcessJobFinished,
            ProcessJobAborted,
            ProcessJobCancelled,
            ControlJobCreated,
            ControlJobStarted,
            ControlJobCompleted,
            ControlJobAborted,
            SubstrateProcessingStart,
            SubstrateProcessingEnd,
            AlarmSet,
            AlarmCleared
        };
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Standard Cimetrix Status Variable IDs (SVIDs)
    // ─────────────────────────────────────────────────────────────────────────
    public static class GemSvid
    {
        public const uint ClockTime          = 1;
        public const uint ControlState       = 2;
        public const uint EventsEnabled      = 3;
        public const uint AlarmsEnabled      = 4;
        public const uint AlarmsSet          = 5;
        public const uint ProcessJobId       = 10;
        public const uint ProcessJobState    = 11;
        public const uint RecipeId           = 12;
        public const uint LotId             = 13;
        public const uint CarrierId         = 14;
        public const uint SubstrateCount    = 15;
        public const uint ProcessTime       = 20;
        public const uint RemainingTime     = 21;
        public const uint SlotMap           = 22;
        public const uint EquipmentState    = 30;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Standard Cimetrix Data Variable IDs (DVIDs)
    //  These are reported with collection events via S6F11
    // ─────────────────────────────────────────────────────────────────────────
    public static class GemDvid
    {
        public const uint ProcessJobId      = 1;
        public const uint RecipeId          = 2;
        public const uint LotId            = 3;
        public const uint CarrierId        = 4;
        public const uint SubstrateId      = 5;
        public const uint SlotNumber       = 6;
        public const uint StartTime        = 10;
        public const uint EndTime          = 11;
        public const uint ProcessResult    = 12;
        public const uint AbortReason      = 13;
        public const uint AlarmId          = 20;
        public const uint AlarmText        = 21;
        public const uint ControlJobId     = 30;

        private static readonly Dictionary<uint, string> _names
            = new Dictionary<uint, string>
        {
            { ProcessJobId,   "ProcessJobID"   },
            { RecipeId,       "RecipeID"       },
            { LotId,          "LotID"          },
            { CarrierId,      "CarrierID"      },
            { SubstrateId,    "SubstrateID"    },
            { SlotNumber,     "SlotNumber"     },
            { StartTime,      "StartTime"      },
            { EndTime,        "EndTime"        },
            { ProcessResult,  "ProcessResult"  },
            { AbortReason,    "AbortReason"    },
            { AlarmId,        "AlarmID"        },
            { AlarmText,      "AlarmText"      },
            { ControlJobId,   "ControlJobID"   },
        };

        public static string GetName(uint dvid)
        {
            string name;
            return _names.TryGetValue(dvid, out name)
                ? name
                : string.Format("DVID {0}", dvid);
        }
    }
}
