using System;
using System.Collections.Generic;
using System.Threading;
using SecSimPro.Models;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  JobMonitorService
    //
    //  Receives parsed S6F11 event data from TcpConnectionService,
    //  maintains the current job and job history, and fires events
    //  for the UI to refresh.
    // ─────────────────────────────────────────────────────────────────────────
    public class JobMonitorService
    {
        private readonly object _lock = new object();

        // ── State ──────────────────────────────────────────────
        private JobRecord                _currentJob;
        private readonly List<JobRecord> _jobHistory = new List<JobRecord>();
        private readonly List<JobEvent>  _allEvents  = new List<JobEvent>();

        // ── Public read access ────────────────────────────────
        public JobRecord           CurrentJob  { get { lock (_lock) return _currentJob; } }
        public IList<JobRecord>    JobHistory  { get { lock (_lock) return _jobHistory.AsReadOnly(); } }
        public IList<JobEvent>     AllEvents   { get { lock (_lock) return _allEvents.AsReadOnly(); } }

        // ── Events ────────────────────────────────────────────
        public event EventHandler<JobRecord> JobStateChanged;
        public event EventHandler<JobEvent>  EventReceived;
        public event EventHandler            JobHistoryUpdated;

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Process an incoming S6F11 message
        //  Called by TcpConnectionService when S6F11 arrives
        // ─────────────────────────────────────────────────────
        public void ProcessS6F11(ParsedS6F11 ev)
        {
            var jobEvent = new JobEvent
            {
                CeidValue = ev.Ceid,
                CeidName  = GemCeid.GetName(ev.Ceid),
                Data      = ev.Data
            };

            // Extract job ID from event data
            string jobId = "";
            ev.Data.TryGetValue(GemDvid.GetName(GemDvid.ProcessJobId), out jobId);
            if (string.IsNullOrEmpty(jobId))
                ev.Data.TryGetValue("ProcessJobID", out jobId);
            jobEvent.JobId = jobId ?? "";

            lock (_lock)
            {
                _allEvents.Add(jobEvent);
                HandleCeid(ev.Ceid, jobEvent, ev.Data);
            }

            EventReceived?.Invoke(this, jobEvent);
        }

        // ─────────────────────────────────────────────────────
        //  CEID dispatch
        // ─────────────────────────────────────────────────────
        private void HandleCeid(uint ceid, JobEvent ev, Dictionary<string, string> data)
        {
            switch (ceid)
            {
                case GemCeid.ProcessJobCreated:
                case GemCeid.ProcessJobQueued:
                    OnJobCreatedOrQueued(ev, data);
                    break;

                case GemCeid.ProcessJobStarted:
                case GemCeid.ControlJobStarted:
                    OnJobStarted(ev, data);
                    break;

                case GemCeid.ProcessJobPaused:
                case GemCeid.ControlJobPaused:
                    OnJobPaused(ev, data);
                    break;

                case GemCeid.ProcessJobResumed:
                case GemCeid.ControlJobResumed:
                    OnJobResumed(ev, data);
                    break;

                case GemCeid.ProcessJobFinished:
                case GemCeid.ProcessJobStopped:
                case GemCeid.ProcessJobCancelled:
                case GemCeid.ControlJobCompleted:
                    OnJobFinished(ev, data, ceid);
                    break;

                case GemCeid.ProcessJobAborted:
                case GemCeid.ControlJobAborted:
                    OnJobAborted(ev, data);
                    break;

                case GemCeid.SubstrateProcessingStart:
                    OnSubstrateStart(ev, data);
                    break;

                case GemCeid.SubstrateProcessingEnd:
                    OnSubstrateEnd(ev, data);
                    break;
            }
        }

        // ─────────────────────────────────────────────────────
        //  Job state handlers
        // ─────────────────────────────────────────────────────
        private void OnJobCreatedOrQueued(JobEvent ev, Dictionary<string, string> data)
        {
            var job = EnsureCurrentJob(ev.JobId, data);
            job.State = JobState.Queued;
            if (!job.CreatedAt.HasValue) job.CreatedAt = ev.Timestamp;
            job.Events.Add(ev);
            FireJobChanged(job);
        }

        private void OnJobStarted(JobEvent ev, Dictionary<string, string> data)
        {
            var job = EnsureCurrentJob(ev.JobId, data);
            job.State     = JobState.Executing;
            job.StartedAt = ev.Timestamp;

            string st;
            if (data.TryGetValue("StartTime", out st) && !string.IsNullOrEmpty(st))
            {
                DateTime dt;
                if (DateTime.TryParse(st, out dt)) job.StartedAt = dt;
            }

            // Mark all occupied slots as Pending
            foreach (var slot in job.Slots)
                if (slot.State == SlotState.Empty || slot.State == SlotState.Unknown)
                    slot.State = SlotState.Pending;

            job.Events.Add(ev);
            FireJobChanged(job);
        }

        private void OnJobPaused(JobEvent ev, Dictionary<string, string> data)
        {
            if (_currentJob == null) return;
            _currentJob.State = JobState.Paused;
            _currentJob.Events.Add(ev);
            FireJobChanged(_currentJob);
        }

        private void OnJobResumed(JobEvent ev, Dictionary<string, string> data)
        {
            if (_currentJob == null) return;
            _currentJob.State = JobState.Executing;
            _currentJob.Events.Add(ev);
            FireJobChanged(_currentJob);
        }

        private void OnJobFinished(JobEvent ev, Dictionary<string, string> data, uint ceid)
        {
            var job = _currentJob ?? EnsureCurrentJob(ev.JobId, data);
            job.State      = JobState.Completed;
            job.FinishedAt = ev.Timestamp;

            string result;
            if (data.TryGetValue("ProcessResult", out result))
                job.ProcessResult = result;

            string et;
            if (data.TryGetValue("EndTime", out et) && !string.IsNullOrEmpty(et))
            {
                DateTime dt;
                if (DateTime.TryParse(et, out dt)) job.FinishedAt = dt;
            }

            // Mark any still-pending slots as Pass (default)
            foreach (var slot in job.Slots)
                if (slot.State == SlotState.Pending || slot.State == SlotState.Processing)
                    slot.State = string.Equals(job.ProcessResult, "FAIL",
                        StringComparison.OrdinalIgnoreCase)
                        ? SlotState.Fail : SlotState.Pass;

            job.Events.Add(ev);
            ArchiveCurrentJob();
        }

        private void OnJobAborted(JobEvent ev, Dictionary<string, string> data)
        {
            var job = _currentJob ?? EnsureCurrentJob(ev.JobId, data);
            job.State      = JobState.Aborted;
            job.FinishedAt = ev.Timestamp;

            string reason;
            if (data.TryGetValue("AbortReason", out reason))
                job.AbortReason = reason;

            // Mark pending slots as Fail
            foreach (var slot in job.Slots)
                if (slot.State == SlotState.Pending || slot.State == SlotState.Processing)
                    slot.State = SlotState.Fail;

            job.Events.Add(ev);
            ArchiveCurrentJob();
        }

        private void OnSubstrateStart(JobEvent ev, Dictionary<string, string> data)
        {
            if (_currentJob == null) return;

            string slotStr;
            if (data.TryGetValue("SlotNumber", out slotStr))
            {
                int slot;
                if (int.TryParse(slotStr, out slot))
                    _currentJob.SetSlotState(slot, SlotState.Processing);
            }

            _currentJob.Events.Add(ev);
            FireJobChanged(_currentJob);
        }

        private void OnSubstrateEnd(JobEvent ev, Dictionary<string, string> data)
        {
            if (_currentJob == null) return;

            string slotStr, result;
            data.TryGetValue("SlotNumber", out slotStr);
            data.TryGetValue("ProcessResult", out result);

            int slot;
            if (slotStr != null && int.TryParse(slotStr, out slot))
            {
                SlotState s = string.Equals(result, "FAIL", StringComparison.OrdinalIgnoreCase)
                    ? SlotState.Fail : SlotState.Pass;
                _currentJob.SetSlotState(slot, s, result ?? "PASS");
            }

            _currentJob.Events.Add(ev);
            FireJobChanged(_currentJob);
        }

        // ─────────────────────────────────────────────────────
        //  Helpers
        // ─────────────────────────────────────────────────────
        private JobRecord EnsureCurrentJob(string jobId, Dictionary<string, string> data)
        {
            if (_currentJob == null || _currentJob.IsComplete)
                _currentJob = new JobRecord { JobId = jobId ?? "" };

            if (!string.IsNullOrEmpty(jobId))
                _currentJob.JobId = jobId;

            // Populate from data if available
            string val;
            if (string.IsNullOrEmpty(_currentJob.RecipeId))
            {
                if (data.TryGetValue("RecipeID", out val)) _currentJob.RecipeId  = val ?? "";
            }
            if (string.IsNullOrEmpty(_currentJob.LotId))
            {
                if (data.TryGetValue("LotID",    out val)) _currentJob.LotId     = val ?? "";
            }
            if (string.IsNullOrEmpty(_currentJob.CarrierId))
            {
                if (data.TryGetValue("CarrierID", out val)) _currentJob.CarrierId = val ?? "";
            }

            return _currentJob;
        }

        private void ArchiveCurrentJob()
        {
            if (_currentJob == null) return;
            _jobHistory.Insert(0, _currentJob);

            // Keep last 100 jobs
            while (_jobHistory.Count > 100)
                _jobHistory.RemoveAt(_jobHistory.Count - 1);

            FireJobChanged(_currentJob);
            JobHistoryUpdated?.Invoke(this, EventArgs.Empty);
            _currentJob = null;
        }

        private void FireJobChanged(JobRecord job) =>
            JobStateChanged?.Invoke(this, job);

        // ─────────────────────────────────────────────────────
        //  Reset on disconnect
        // ─────────────────────────────────────────────────────
        public void Reset()
        {
            lock (_lock)
            {
                if (_currentJob != null && _currentJob.IsActive)
                {
                    _currentJob.State      = JobState.Aborted;
                    _currentJob.FinishedAt = DateTime.Now;
                    _currentJob.AbortReason = "Host disconnected";
                    _jobHistory.Insert(0, _currentJob);
                }
                _currentJob = null;
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  ParsedS6F11 — decoded S6F11 payload passed from TcpConnectionService
    // ─────────────────────────────────────────────────────────────────────────
    public class ParsedS6F11
    {
        public uint                       Ceid { get; set; }
        public Dictionary<string, string> Data { get; set; } = new Dictionary<string, string>();
    }
}
