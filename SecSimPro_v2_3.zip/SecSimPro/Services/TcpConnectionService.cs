using System;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using SecSimPro.Models;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  TcpConnectionService  v2.2
    //
    //  Implements the full HSMS (SEMI E37) + GEM (SEMI E30) connection stack:
    //
    //  Stage 1 — TCP Connect
    //  Stage 2 — HSMS Select.req / Select.rsp  (T7 timeout)
    //  Stage 3 — GEM Establish Communications  (S1F13 / S1F14)
    //            Handles BOTH host-initiated AND equipment-initiated S1F13
    //  Keep-alive — Linktest.req / Linktest.rsp every N seconds
    //  Disconnect  — Separate.req then close socket
    // ─────────────────────────────────────────────────────────────────────────
    public class TcpConnectionService : IDisposable
    {
        // ── HSMS timers (seconds) ─────────────────────────────
        private const int T3  = 45;   // reply timeout
        private const int T6  = 5;    // control msg timeout
        private const int T7  = 10;   // not-selected timeout
        private const int T8r = 5;    // socket read timeout

        private int _linktestInterval = 15;

        // ── Socket state ──────────────────────────────────────
        private TcpClient               _tcp;
        private NetworkStream           _stream;
        private CancellationTokenSource _cts;
        private Thread                  _rxThread;
        private Thread                  _linktestThread;
        private readonly object         _txLock  = new object();
        private uint                    _sysCtr  = 1;
        private int                     _linktestFailures;

        // ── Synchronisation latches ───────────────────────────
        private readonly ManualResetEventSlim _selectLatch   = new ManualResetEventSlim(false);
        private readonly ManualResetEventSlim _s1f14Latch    = new ManualResetEventSlim(false);
        private readonly ManualResetEventSlim _linktestLatch = new ManualResetEventSlim(false);

        private HsmsSelectStatus _selectStatus;
        private byte?            _inboundCommAck;
        private bool             _gemHandshakeDone;
        private bool             _disposed;

        private ConnectionProfile _profile;

        // ── Sub-services (wired after construction) ──────────
        public GemEventSubscriptionService SubscriptionService { get; private set; }
        public JobMonitorService           JobMonitor          { get; private set; }

        // ── Reply waiters dict ────────────────────────────────
        private readonly System.Collections.Generic.Dictionary<uint,
            System.Action<HsmsMessage>> _replyWaiters
            = new System.Collections.Generic.Dictionary<uint, System.Action<HsmsMessage>>();

        // ── Public ────────────────────────────────────────────
        public ConnectionStatus    CurrentStatus     { get; private set; } = ConnectionStatus.Disconnected;
        public EquipmentConnection CurrentConnection { get; private set; }
        public bool IsConnected => CurrentStatus == ConnectionStatus.Selected
                                || CurrentStatus == ConnectionStatus.GemOnline;

        public event EventHandler<ConnectionEventArgs> ConnectionStatusChanged;
        public event EventHandler<ConnectionEventArgs> LogMessage;

        public TcpConnectionService()
        {
            SubscriptionService = new GemEventSubscriptionService(this);
            SubscriptionService.SubscriptionLog += (s, msg) =>
                Log(LogSeverity.Gem, "[SUB] " + msg);

            JobMonitor = new JobMonitorService();
        }

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Connect
        // ─────────────────────────────────────────────────────
        public void Connect(ConnectionProfile p)
        {
            if (CurrentStatus != ConnectionStatus.Disconnected &&
                CurrentStatus != ConnectionStatus.Error)
            {
                Log(LogSeverity.Warning, "Already connected. Disconnect first.");
                return;
            }

            _profile          = p;
            _linktestInterval = p.LinktestIntervalSec > 0 ? p.LinktestIntervalSec : 15;
            _gemHandshakeDone = false;

            CurrentConnection = new EquipmentConnection
            {
                IpAddress   = p.IpAddress,
                Port        = p.Port,
                Description = p.Description,
                SessionId   = p.SessionId,
                Status      = ConnectionStatus.Connecting
            };

            ChangeStatus(ConnectionStatus.Connecting,
                string.Format("Connecting to {0}:{1}...", p.IpAddress, p.Port),
                LogSeverity.Info, p.IpAddress, p.Port);

            Task.Run(() => RunConnect(p));
        }

        // ─────────────────────────────────────────────────────
        //  STAGE 1 — TCP connect
        // ─────────────────────────────────────────────────────
        private void RunConnect(ConnectionProfile p)
        {
            try
            {
                _tcp         = new TcpClient();
                _tcp.NoDelay = true;

                if (!_tcp.ConnectAsync(p.IpAddress, p.Port)
                         .Wait(TimeSpan.FromSeconds(p.TimeoutSeconds)))
                { Fail(string.Format("TCP timeout after {0}s.", p.TimeoutSeconds), p); return; }

                if (!_tcp.Connected)
                { Fail("TCP refused by host.", p); return; }

                _stream              = _tcp.GetStream();
                _stream.ReadTimeout  = T8r * 1000;
                _stream.WriteTimeout = T8r * 1000;

                Log(LogSeverity.Info,
                    string.Format("TCP connected to {0}:{1}", p.IpAddress, p.Port));

                ChangeStatus(ConnectionStatus.TcpConnected,
                    string.Format("TCP up. Sending HSMS Select.req (Session 0x{0:X4})...", p.SessionId),
                    LogSeverity.Hsms, p.IpAddress, p.Port);

                _cts = new CancellationTokenSource();
                StartRxLoop(_cts.Token);
                RunHsmsSelect(p);
            }
            catch (SocketException ex) { Fail("Socket: " + SockMsg(ex.SocketErrorCode), p); }
            catch (Exception ex)       { Fail("Connect error: " + ex.Message, p); }
        }

        // ─────────────────────────────────────────────────────
        //  STAGE 2 — HSMS Select
        // ─────────────────────────────────────────────────────
        private void RunHsmsSelect(ConnectionProfile p)
        {
            try
            {
                _selectLatch.Reset();
                var req = HsmsMessage.BuildSelectReq(p.SessionId, NextSys());
                TxLog(req); Send(req.ToBytes());

                if (!_selectLatch.Wait(TimeSpan.FromSeconds(T7)))
                {
                    Fail(string.Format(
                        "No Select.rsp within T7={0}s. Check Session ID matches equipment config.", T7), p);
                    return;
                }

                if (_selectStatus != HsmsSelectStatus.Success)
                {
                    Fail(string.Format(
                        "Select rejected — {0} (0x{1:X2}). Verify Session ID.", _selectStatus, (byte)_selectStatus), p);
                    return;
                }

                CurrentConnection.Status    = ConnectionStatus.Selected;
                CurrentConnection.SessionId = p.SessionId;

                ChangeStatus(ConnectionStatus.Selected,
                    string.Format("HSMS Selected (Session 0x{0:X4}). Starting GEM handshake...", p.SessionId),
                    LogSeverity.Hsms, p.IpAddress, p.Port);

                StartLinktestTimer(_cts.Token);

                if (p.UseGem)
                    RunGemHandshake(p);
                else
                    FinalizeSelected(p);
            }
            catch (Exception ex) { Fail("HSMS Select error: " + ex.Message, p); }
        }

        // ─────────────────────────────────────────────────────
        //  STAGE 3 — GEM Establish Communications
        //
        //  Handles both paths simultaneously:
        //    PATH A: Host sends S1F13  → waits for EQ S1F14
        //    PATH B: EQ sends S1F13   → host replies S1F14(COMMACK=0)
        //            receive loop sets latch
        // ─────────────────────────────────────────────────────
        private void RunGemHandshake(ConnectionProfile p)
        {
            Log(LogSeverity.Gem,
                "GEM: Starting Establish Communications (S1F13/S1F14)...");
            Log(LogSeverity.Gem,
                "GEM: Sending S1F13 AND listening for equipment-initiated S1F13 simultaneously.");

            _s1f14Latch.Reset();
            _inboundCommAck = null;

            byte[] body = SecsIIMessage.S1F13_EstablishCommsReq(
                p.HostMdln ?? "SecSimPro", p.HostSoftrev ?? "2.2");
            var msg = HsmsMessage.BuildDataMessage(p.SessionId, 1, 13, true, NextSys(), body);

            Log(LogSeverity.Gem,
                string.Format("GEM: TX S1F13 body=[{0}]",
                    BitConverter.ToString(body).Replace("-", " ")));
            TxLog(msg); Send(msg.ToBytes());

            bool recv = _s1f14Latch.Wait(TimeSpan.FromSeconds(T3));

            if (!recv)
            {
                Log(LogSeverity.Warning,
                    string.Format("GEM: No S1F14 within T3={0}s. Staying HSMS SELECTED.", T3));
                FinalizeSelected(p);
                return;
            }

            byte ack = _inboundCommAck ?? 0xFF;
            if (ack == 0x00)
                AchieveGemOnline(p, "S1F14 COMMACK=0 received");
            else
            {
                Log(LogSeverity.Warning,
                    string.Format("GEM: S1F14 COMMACK=0x{0:X2} — not accepted. Staying SELECTED.", ack));
                FinalizeSelected(p);
            }
        }

        private void AchieveGemOnline(ConnectionProfile p, string reason)
        {
            if (_gemHandshakeDone) return;
            _gemHandshakeDone = true;

            CurrentConnection.Status      = ConnectionStatus.GemOnline;
            CurrentConnection.ConnectedAt = DateTime.Now;

            ChangeStatus(ConnectionStatus.GemOnline,
                string.Format("GEM Online — {0}. Equipment is in COMMUNICATING state.", reason),
                LogSeverity.Gem, p.IpAddress, p.Port);

            if (p.SendDateTimeOnConnect)
                SendDateTimeSet(p);

            // Auto-subscribe to job events
            var subThread = new System.Threading.Thread(() =>
                SubscriptionService.Subscribe(p.SessionId))
            { IsBackground = true, Name = "GEM-Subscribe" };
            subThread.Start();
        }

        private void FinalizeSelected(ConnectionProfile p)
        {
            if (CurrentStatus == ConnectionStatus.Selected ||
                CurrentStatus == ConnectionStatus.TcpConnected)
            {
                CurrentConnection.ConnectedAt = DateTime.Now;
                ChangeStatus(ConnectionStatus.Selected,
                    "HSMS Selected. Communication ready.",
                    LogSeverity.Success, p.IpAddress, p.Port);
            }
        }

        private void SendDateTimeSet(ConnectionProfile p)
        {
            try
            {
                var dt    = DateTime.Now;
                var body  = SecsIIMessage.S2F31_DateTimeSet(dt);
                var dtMsg = HsmsMessage.BuildDataMessage(p.SessionId, 2, 31, true, NextSys(), body);
                Log(LogSeverity.Gem,
                    string.Format("GEM: TX S2F31 Date/Time Set: {0:yyyy-MM-dd HH:mm:ss}", dt));
                TxLog(dtMsg); Send(dtMsg.ToBytes());
            }
            catch (Exception ex)
            {
                Log(LogSeverity.Warning, "GEM: S2F31 failed: " + ex.Message);
            }
        }

        // ─────────────────────────────────────────────────────
        //  RECEIVE LOOP
        // ─────────────────────────────────────────────────────
        private void StartRxLoop(CancellationToken token)
        {
            _rxThread = new Thread(() =>
            {
                Log(LogSeverity.Info, "RX thread started.");
                try
                {
                    while (!token.IsCancellationRequested)
                    {
                        byte[] lenBuf = ReadExact(4, token);
                        if (lenBuf == null) break;

                        uint msgLen = (uint)((lenBuf[0] << 24) | (lenBuf[1] << 16)
                                           | (lenBuf[2] << 8)  |  lenBuf[3]);

                        if (msgLen < HsmsMessage.HeaderLength || msgLen > 8 * 1024 * 1024)
                        {
                            Log(LogSeverity.Error,
                                string.Format("RX: Invalid length {0} — closing.", msgLen));
                            break;
                        }

                        byte[] hdr  = ReadExact(HsmsMessage.HeaderLength, token);
                        if (hdr == null) break;

                        int    dlen = (int)msgLen - HsmsMessage.HeaderLength;
                        byte[] data = dlen > 0 ? ReadExact(dlen, token) : new byte[0];
                        if (dlen > 0 && data == null) break;

                        Dispatch(HsmsMessage.FromHeader(hdr, data));
                    }
                }
                catch (OperationCanceledException) { }
                catch (IOException)                { }
                catch (Exception ex)
                {
                    if (!token.IsCancellationRequested)
                        Log(LogSeverity.Error, "RX: " + ex.Message);
                }
                finally
                {
                    if (!token.IsCancellationRequested)
                    {
                        Log(LogSeverity.Warning, "RX loop ended — connection dropped.");
                        HandleDropped();
                    }
                    Log(LogSeverity.Info, "RX thread exiting.");
                }
            })
            { IsBackground = true, Name = "HSMS-RX" };
            _rxThread.Start();
        }

        // ─────────────────────────────────────────────────────
        //  MESSAGE DISPATCH
        // ─────────────────────────────────────────────────────
        private void Dispatch(HsmsMessage msg)
        {
            Log(LogSeverity.Hsms, "RX <- " + msg.ToString());
            if (msg.IsControlMessage) HandleControl(msg);
            else                       HandleData(msg);
        }

        private void HandleControl(HsmsMessage msg)
        {
            switch (msg.SType)
            {
                case HsmsSType.SelectRsp:
                    _selectStatus = msg.SelectStatus;
                    _selectLatch.Set();
                    break;

                case HsmsSType.SelectReq:
                    var srsp = HsmsMessage.BuildSelectRsp(
                        msg.SessionId, msg.SystemBytes, HsmsSelectStatus.Success);
                    TxLog(srsp); Send(srsp.ToBytes());
                    break;

                case HsmsSType.LinktestReq:
                    var lrsp = HsmsMessage.BuildLinktestRsp(msg.SystemBytes);
                    TxLog(lrsp); Send(lrsp.ToBytes());
                    break;

                case HsmsSType.LinktestRsp:
                    _linktestFailures = 0;
                    _linktestLatch.Set();
                    break;

                case HsmsSType.SeparateReq:
                    Log(LogSeverity.Warning, "Equipment sent Separate.req — closing session.");
                    HandleDropped();
                    break;

                default:
                    Log(LogSeverity.Hsms, "Unhandled control: " + msg.SType.ToString());
                    break;
            }
        }

        private void HandleData(HsmsMessage msg)
        {
            ushort sid = CurrentConnection != null ? CurrentConnection.SessionId
                       : _profile != null ? _profile.SessionId : (ushort)0;

            // ── S1F1 — Are You There ──────────────────────────
            if (msg.Stream == 1 && msg.Function == 1)
            {
                var r = HsmsMessage.BuildDataMessage(sid, 1, 2, false,
                    msg.SystemBytes, SecsIIMessage.S1F2_OnLineData());
                Log(LogSeverity.Gem, "GEM: RX S1F1 -> TX S1F2");
                TxLog(r); Send(r.ToBytes());
                return;
            }

            // ── S1F13 — Equipment-initiated Establish Comms ───
            if (msg.Stream == 1 && msg.Function == 13)
            {
                var parsed  = SecsIIMessage.ParseMdlnSoftrev(msg.Data);
                string mdln    = parsed.Item1;
                string softrev = parsed.Item2;

                Log(LogSeverity.Gem,
                    string.Format("GEM: RX S1F13 from equipment (MDLN='{0}' SOFTREV='{1}')",
                        mdln ?? "", softrev ?? ""));
                Log(LogSeverity.Gem, "GEM: TX S1F14 COMMACK=0x00 (Accepted)");

                byte[] ackBody = SecsIIMessage.S1F14_EstablishCommsAck(
                    0x00,
                    _profile != null ? _profile.HostMdln    ?? "SecSimPro" : "SecSimPro",
                    _profile != null ? _profile.HostSoftrev ?? "2.2"       : "2.2");

                var reply = HsmsMessage.BuildDataMessage(
                    msg.SessionId, 1, 14, false, msg.SystemBytes, ackBody);
                TxLog(reply); Send(reply.ToBytes());

                _inboundCommAck = 0x00;
                _s1f14Latch.Set();

                if (!_gemHandshakeDone && _profile != null)
                    AchieveGemOnline(_profile,
                        "Equipment sent S1F13 — replied S1F14(COMMACK=0)");
                return;
            }

            // ── S1F14 — Reply to our S1F13 ────────────────────
            if (msg.Stream == 1 && msg.Function == 14)
            {
                byte? ack = SecsIIMessage.ParseS1F14CommAck(msg.Data);
                Log(LogSeverity.Gem,
                    string.Format("GEM: RX S1F14 COMMACK=0x{0}  raw=[{1}]",
                        ack.HasValue ? ack.Value.ToString("X2") : "??",
                        BitConverter.ToString(msg.Data).Replace("-", " ")));
                _inboundCommAck = ack;
                _s1f14Latch.Set();
                return;
            }

            // ── S1F2 — On-Line Data ───────────────────────────
            if (msg.Stream == 1 && msg.Function == 2)
            {
                Log(LogSeverity.Gem, "GEM: S1F2 On-Line Data received.");
                return;
            }

            // ── S1F15 — Request OFF-LINE ──────────────────────
            if (msg.Stream == 1 && msg.Function == 15)
            {
                Log(LogSeverity.Warning, "GEM: RX S1F15 Request OFF-LINE. Acknowledging.");
                var r = HsmsMessage.BuildDataMessage(
                    sid, 1, 16, false, msg.SystemBytes, new byte[0]);
                TxLog(r); Send(r.ToBytes());
                return;
            }

            // ── S2F17 — Date/Time Request ─────────────────────
            if (msg.Stream == 2 && msg.Function == 17)
            {
                Log(LogSeverity.Gem, "GEM: RX S2F17 Date/Time request. TX S2F18...");
                var dtBody = SecsIIMessage.S2F18_DateTimeData(DateTime.Now);
                var r = HsmsMessage.BuildDataMessage(
                    sid, 2, 18, false, msg.SystemBytes, dtBody);
                TxLog(r); Send(r.ToBytes());
                return;
            }

            // ── S6F11 — Event Report Send ─────────────────────
            if (msg.Stream == 6 && msg.Function == 11)
            {
                HandleS6F11(msg, sid);
                return;
            }

            // ── S6F11 reply (S6F12) handling ──────────────────
            if (msg.Stream == 6 && msg.Function == 12)
            {
                // Ack from equipment to our S6F12 — ignore
                return;
            }

            // ── Reply dispatch for pending waiters ───────────
            if (!msg.ReplyBit)
            {
                System.Action<HsmsMessage> waiter;
                lock (_replyWaiters)
                {
                    if (_replyWaiters.TryGetValue(msg.SystemBytes, out waiter))
                        _replyWaiters.Remove(msg.SystemBytes);
                }
                if (waiter != null) { waiter(msg); return; }
            }

            // ── S9 — SECS-II errors ───────────────────────────
            if (msg.Stream == 9)
            {
                Log(LogSeverity.Warning,
                    string.Format("SECS-II S9F{0} {1} from equipment.", msg.Function, GetS9Desc(msg.Function)));
                return;
            }

            Log(LogSeverity.Info,
                string.Format("Data S{0}F{1} received ({2}B — not handled).",
                    msg.Stream, msg.Function, msg.Data.Length));
        }

        // ─────────────────────────────────────────────────────
        //  LINKTEST TIMER
        // ─────────────────────────────────────────────────────
        private void StartLinktestTimer(CancellationToken token)
        {
            _linktestThread = new Thread(() =>
            {
                Log(LogSeverity.Hsms,
                    string.Format("Linktest started — interval={0}s T6={1}s.",
                        _linktestInterval, T6));

                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        for (int i = 0; i < _linktestInterval * 10; i++)
                        {
                            if (token.IsCancellationRequested) return;
                            Thread.Sleep(100);
                        }
                        if (token.IsCancellationRequested) return;

                        _linktestLatch.Reset();
                        var req = HsmsMessage.BuildLinktestReq(NextSys());
                        TxLog(req); Send(req.ToBytes());

                        if (!_linktestLatch.Wait(TimeSpan.FromSeconds(T6)))
                        {
                            _linktestFailures++;
                            Log(LogSeverity.Warning,
                                string.Format("Linktest timeout #{0}/2 (T6={1}s).",
                                    _linktestFailures, T6));
                            if (_linktestFailures >= 2)
                            {
                                Log(LogSeverity.Error,
                                    "Two consecutive linktest failures — connection lost.");
                                HandleDropped();
                                return;
                            }
                        }
                        else
                        {
                            _linktestFailures = 0;
                            Log(LogSeverity.Hsms, "Linktest OK.");
                        }
                    }
                    catch (OperationCanceledException) { return; }
                    catch { return; }
                }
            })
            { IsBackground = true, Name = "HSMS-Linktest" };
            _linktestThread.Start();
        }

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Disconnect
        // ─────────────────────────────────────────────────────
        public void Disconnect()
        {
            try
            {
                string ip   = CurrentConnection != null ? CurrentConnection.IpAddress : "";
                int    port = CurrentConnection != null ? CurrentConnection.Port      : 0;

                if (_stream != null &&
                    (CurrentStatus == ConnectionStatus.Selected ||
                     CurrentStatus == ConnectionStatus.GemOnline))
                {
                    try
                    {
                        var sep = HsmsMessage.BuildSeparateReq(
                            CurrentConnection != null ? CurrentConnection.SessionId : (ushort)0,
                            NextSys());
                        TxLog(sep); Send(sep.ToBytes());
                        Thread.Sleep(150);
                    }
                    catch { }
                }

                Cleanup();
                JobMonitor.Reset();

                if (CurrentConnection != null)
                {
                    CurrentConnection.Status         = ConnectionStatus.Disconnected;
                    CurrentConnection.DisconnectedAt = DateTime.Now;
                }

                ChangeStatus(ConnectionStatus.Disconnected,
                    string.Format("Disconnected from {0}:{1}.", ip, port),
                    LogSeverity.Warning, ip, port);
            }
            catch (Exception ex)
            {
                Log(LogSeverity.Error, "Disconnect error: " + ex.Message);
            }
        }

        // ─────────────────────────────────────────────────────
        //  INTERNAL HELPERS
        // ─────────────────────────────────────────────────────
        private void HandleDropped()
        {
            if (CurrentStatus == ConnectionStatus.Disconnected) return;

            string ip   = CurrentConnection != null ? CurrentConnection.IpAddress : "";
            int    port = CurrentConnection != null ? CurrentConnection.Port      : 0;

            Cleanup();
            JobMonitor.Reset();

            if (CurrentConnection != null)
                CurrentConnection.Status = ConnectionStatus.Error;

            ChangeStatus(ConnectionStatus.Error,
                "Connection lost — equipment closed session or network failure.",
                LogSeverity.Error, ip, port);
        }

        private void Cleanup()
        {
            _cts?.Cancel();
            try { _stream?.Close(); } catch { }
            try { _tcp?.Close();    } catch { }
            _stream = null;
            _tcp    = null;
        }

        private byte[] ReadExact(int count, CancellationToken token)
        {
            var buf = new byte[count];
            int rx  = 0;
            while (rx < count)
            {
                if (token.IsCancellationRequested) return null;
                int n;
                try { n = _stream.Read(buf, rx, count - rx); }
                catch (IOException ex)
                    when (ex.InnerException is SocketException sx &&
                          sx.SocketErrorCode == SocketError.TimedOut) { continue; }
                if (n == 0) return null;
                rx += n;
            }
            return buf;
        }

        private void Send(byte[] data)
        {
            lock (_txLock) { _stream?.Write(data, 0, data.Length); }
        }

        private void TxLog(HsmsMessage m) =>
            Log(LogSeverity.Hsms, "TX -> " + m.ToString());

        private uint NextSys() => _sysCtr++;

        private void ChangeStatus(ConnectionStatus st, string msg, LogSeverity sev,
                                   string ip = "", int port = 0)
        {
            CurrentStatus = st;
            ConnectionStatusChanged?.Invoke(this,
                new ConnectionEventArgs(st, msg, sev, ip, port));
        }

        private void Log(LogSeverity sev, string msg) =>
            LogMessage?.Invoke(this,
                new ConnectionEventArgs(CurrentStatus, msg, sev));

        private void Fail(string msg, ConnectionProfile p)
        {
            Cleanup();
            if (CurrentConnection != null)
                CurrentConnection.Status = ConnectionStatus.Error;
            ChangeStatus(ConnectionStatus.Error, msg,
                LogSeverity.Error,
                p != null ? p.IpAddress : "",
                p != null ? p.Port      : 0);
        }

        private static string SockMsg(SocketError e)
        {
            switch (e)
            {
                case SocketError.ConnectionRefused:  return "Connection refused — check IP/port.";
                case SocketError.HostUnreachable:
                case SocketError.HostNotFound:       return "Host not found / unreachable.";
                case SocketError.NetworkUnreachable: return "Network unreachable.";
                case SocketError.TimedOut:           return "Timed out — equipment offline?";
                default:                              return e.ToString();
            }
        }

        // ─────────────────────────────────────────────────────
        //  S6F11 — Event Report Send handler
        // ─────────────────────────────────────────────────────
        private void HandleS6F11(HsmsMessage msg, ushort sid)
        {
            // Send S6F12 ack immediately
            var ack = HsmsMessage.BuildDataMessage(sid, 6, 12, false, msg.SystemBytes,
                SecsIIMessage.EncodeBinary(0));
            Send(ack.ToBytes());

            // Parse S6F11 body
            // Structure: <L 3 <U4 DATAID> <U4 CEID> <L n reports>>
            var parsed = ParseS6F11Body(msg.Data);
            if (parsed == null)
            {
                Log(LogSeverity.Warning, "S6F11: Could not parse event body.");
                return;
            }

            Log(LogSeverity.Gem,
                string.Format("S6F11: CEID={0} ({1}) — {2} data item(s)",
                    parsed.Ceid, GemCeid.GetName(parsed.Ceid), parsed.Data.Count));

            JobMonitor.ProcessS6F11(parsed);
        }

        private ParsedS6F11 ParseS6F11Body(byte[] body)
        {
            if (body == null || body.Length < 4) return null;
            try
            {
                var result = new ParsedS6F11();
                int pos    = 0;

                // Outer list
                if ((body[pos] & 0xFC) != (byte)SecsFormat.List) return null;
                int listLenBytes = body[pos] & 0x03;
                pos += 1 + listLenBytes;   // skip list header

                // DATAID (U4 or U2)
                pos = SkipItem(body, pos);

                // CEID (U4)
                result.Ceid = ReadU4Item(body, ref pos);

                // Reports list: <L n <L 2 <U4 ReportID> <L m <item>...>>>
                if (pos < body.Length && (body[pos] & 0xFC) == (byte)SecsFormat.List)
                {
                    int rptListLenBytes = body[pos] & 0x03;
                    int rptCount        = 0;
                    for (int i = 0; i < rptListLenBytes; i++)
                        rptCount = (rptCount << 8) | body[pos + 1 + i];
                    pos += 1 + rptListLenBytes;

                    for (int r = 0; r < rptCount; r++)
                    {
                        if (pos >= body.Length) break;
                        // Each report: <L 2 <U4 ReportID> <L m items>>
                        if ((body[pos] & 0xFC) != (byte)SecsFormat.List) break;
                        int rl = body[pos] & 0x03;
                        pos += 1 + rl;

                        uint reportId = ReadU4Item(body, ref pos);

                        // Data items list
                        if (pos >= body.Length) break;
                        if ((body[pos] & 0xFC) != (byte)SecsFormat.List) { pos = SkipItem(body, pos); continue; }
                        int dl = body[pos] & 0x03;
                        int dcount = 0;
                        for (int i = 0; i < dl; i++) dcount = (dcount << 8) | body[pos + 1 + i];
                        pos += 1 + dl;

                        // Decode each data item using DVID ordering from the report definition
                        uint[] dvids = GetReportDvids(reportId);
                        for (int d = 0; d < dcount && pos < body.Length; d++)
                        {
                            string val = ReadItemAsString(body, ref pos);
                            string key = (dvids != null && d < dvids.Length)
                                ? GemDvid.GetName(dvids[d])
                                : string.Format("Item{0}", d + 1);
                            if (!string.IsNullOrEmpty(val))
                                result.Data[key] = val;
                        }
                    }
                }

                return result;
            }
            catch { return null; }
        }

        private static uint[] GetReportDvids(uint reportId)
        {
            switch (reportId)
            {
                case 1: return new uint[] { GemDvid.ProcessJobId, GemDvid.RecipeId,
                                             GemDvid.LotId, GemDvid.CarrierId, GemDvid.StartTime };
                case 2: return new uint[] { GemDvid.ProcessJobId, GemDvid.RecipeId,
                                             GemDvid.LotId, GemDvid.EndTime, GemDvid.ProcessResult };
                case 3: return new uint[] { GemDvid.ProcessJobId, GemDvid.AbortReason };
                case 4: return new uint[] { GemDvid.ProcessJobId, GemDvid.SubstrateId, GemDvid.SlotNumber };
                case 5: return new uint[] { GemDvid.AlarmId, GemDvid.AlarmText, GemDvid.ProcessJobId };
                default: return null;
            }
        }

        private static int SkipItem(byte[] body, int pos)
        {
            if (pos >= body.Length) return pos;
            byte fmt      = body[pos];
            int  lenBytes = fmt & 0x03;
            int  len      = 0;
            for (int i = 1; i <= lenBytes && pos + i < body.Length; i++)
                len = (len << 8) | body[pos + i];
            bool isList = (fmt & 0xFC) == (byte)SecsFormat.List;
            if (isList) return pos + 1 + lenBytes; // skip header only; caller handles children
            return pos + 1 + lenBytes + len;
        }

        private static uint ReadU4Item(byte[] body, ref int pos)
        {
            if (pos >= body.Length) return 0;
            byte fmt      = body[pos];
            int  lenBytes = fmt & 0x03;
            int  len      = 0;
            for (int i = 1; i <= lenBytes && pos + i < body.Length; i++)
                len = (len << 8) | body[pos + i];
            pos += 1 + lenBytes;
            if (len == 0 || pos + len > body.Length) return 0;
            uint val = 0;
            for (int i = 0; i < len && i < 4; i++)
                val = (val << 8) | body[pos + i];
            pos += len;
            return val;
        }

        private static string ReadItemAsString(byte[] body, ref int pos)
        {
            if (pos >= body.Length) return "";
            byte fmt      = body[pos];
            int  lenBytes = fmt & 0x03;
            int  len      = 0;
            for (int i = 1; i <= lenBytes && pos + i < body.Length; i++)
                len = (len << 8) | body[pos + i];
            pos += 1 + lenBytes;
            if (len == 0) return "";
            byte fmtCode = (byte)(fmt & 0xFC);

            if (fmtCode == (byte)SecsFormat.ASCII)
            {
                string s = System.Text.Encoding.ASCII.GetString(body, pos, System.Math.Min(len, body.Length - pos));
                pos += len;
                return s.Trim();
            }
            if (len <= 4)
            {
                uint v = 0;
                for (int i = 0; i < len && pos + i < body.Length; i++)
                    v = (v << 8) | body[pos + i];
                pos += len;
                return v.ToString();
            }
            pos += len;
            return "(binary)";
        }

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Send a data message (used by subscription service)
        //  onReply is called on the RX thread when the matching reply arrives.
        // ─────────────────────────────────────────────────────
        public void SendDataMessage(ushort sessionId, byte stream, byte func,
            bool replyReq, byte[] body,
            byte rspStream = 0, byte rspFunc = 0,
            System.Func<HsmsMessage, bool> onReply = null)
        {
            if (_stream == null)
            {
                Log(LogSeverity.Warning, string.Format("Cannot send S{0}F{1} — not connected.", stream, func));
                return;
            }

            uint sys = NextSys();
            var  msg = HsmsMessage.BuildDataMessage(sessionId, stream, func, replyReq, sys, body);

            if (replyReq && onReply != null)
            {
                lock (_replyWaiters)
                    _replyWaiters[sys] = reply =>
                    {
                        try { onReply(reply); }
                        catch (Exception ex)
                        { Log(LogSeverity.Warning, string.Format("Reply handler error S{0}F{1}: {2}", stream, func, ex.Message)); }
                    };
            }

            Log(LogSeverity.Gem, string.Format("TX S{0}F{1}  sys=0x{2:X8}", stream, func, sys));
            Send(msg.ToBytes());
        }

        private static string GetS9Desc(byte f)
        {
            switch (f)
            {
                case 1:  return "(Unrecognised Device ID)";
                case 3:  return "(Unrecognised Stream)";
                case 5:  return "(Unrecognised Function)";
                case 7:  return "(Illegal Data)";
                case 9:  return "(Transaction Timer Timeout)";
                case 11: return "(Data Too Long)";
                case 13: return "(Conversation Timeout)";
                default: return "";
            }
        }

        public void Dispose()
        {
            if (!_disposed) { Cleanup(); _disposed = true; }
        }
    }
}
