using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using SecSimPro.Models;
using SecSimPro.Services;

namespace SecSimPro.Forms
{
    // ─────────────────────────────────────────────────────────────────────────
    //  JobMonitorPanel — live job run monitoring window
    //
    //  Layout:
    //    Top    : Current job status card (JobID, Recipe, Lot, State, timers)
    //    Middle : Slot map (25 slots, colour-coded per state) + Event log
    //    Bottom : Job history grid
    // ─────────────────────────────────────────────────────────────────────────
    public class JobMonitorPanel : Form
    {
        private readonly TcpConnectionService _svc;
        private readonly JobMonitorService    _monitor;

        // ── Current job controls ──────────────────────────────
        private Label  lblJobId,       valJobId;
        private Label  lblRecipe,      valRecipe;
        private Label  lblLot,         valLot;
        private Label  lblCarrier,     valCarrier;
        private Label  lblState,       valState;
        private Label  lblElapsed,     valElapsed;
        private Label  lblResult,      valResult;
        private Panel  pnlStateBadge;

        // ── Slot map ──────────────────────────────────────────
        private SlotMapControl slotMap;

        // ── Event log ─────────────────────────────────────────
        private DataGridView dgvEvents;

        // ── Job history ───────────────────────────────────────
        private DataGridView dgvHistory;

        // ── Timer ─────────────────────────────────────────────
        private Timer _uiTimer;

        // ── Colours ───────────────────────────────────────────
        private static readonly Color BgDark   = Color.FromArgb(16, 22, 36);
        private static readonly Color BgPanel  = Color.FromArgb(24, 32, 50);
        private static readonly Color BgCard   = Color.FromArgb(30, 40, 62);
        private static readonly Color Accent   = Color.FromArgb(0, 140, 220);
        private static readonly Color TextMain = Color.FromArgb(210, 220, 235);
        private static readonly Color TextDim  = Color.FromArgb(100, 115, 140);

        public JobMonitorPanel(TcpConnectionService svc)
        {
            _svc     = svc;
            _monitor = svc.JobMonitor;

            BuildUI();
            WireEvents();
            RefreshCurrentJob();

            _uiTimer = new Timer { Interval = 1000 };
            _uiTimer.Tick += (s, e) => UpdateElapsedTimer();
            _uiTimer.Start();
        }

        // ─────────────────────────────────────────────────────
        //  UI Construction
        // ─────────────────────────────────────────────────────
        private void BuildUI()
        {
            Text            = "Job Monitor  —  SecSimPro";
            Size            = new Size(1100, 720);
            MinimumSize     = new Size(900, 600);
            BackColor       = BgDark;
            ForeColor       = TextMain;
            Font            = new Font("Segoe UI", 8.5f);
            StartPosition   = FormStartPosition.Manual;
            FormBorderStyle = FormBorderStyle.SizableToolWindow;
            ShowInTaskbar   = false;

            // ── Top: current job card ─────────────────────────
            var pnlJobCard = BuildJobCard();
            pnlJobCard.Dock   = DockStyle.Top;
            pnlJobCard.Height = 115;

            // ── Middle: slot map + event log ──────────────────
            var splitMid = new SplitContainer
            {
                Dock             = DockStyle.Fill,
                Orientation      = Orientation.Vertical,
                SplitterDistance = 300,
                SplitterWidth    = 5,
                BackColor        = BgDark,
                Panel1MinSize    = 260,
                Panel2MinSize    = 300
            };

            // Slot map panel
            slotMap = new SlotMapControl { Dock = DockStyle.Fill };
            var grpSlots = WrapGroup("Slot Map  (25-slot FOUP)", slotMap);
            grpSlots.Dock = DockStyle.Fill;
            splitMid.Panel1.Controls.Add(grpSlots);
            splitMid.Panel1.BackColor = BgDark;

            // Event log
            dgvEvents = BuildGrid(new[]
            {
                ("Time",   85,  false),
                ("CEID",   50,  false),
                ("Event",  160, false),
                ("JobID",  100, false),
                ("Data",   0,   true)
            });
            var grpEvents = WrapGroup("Event Log  (S6F11 received)", dgvEvents);
            grpEvents.Dock = DockStyle.Fill;
            splitMid.Panel2.Controls.Add(grpEvents);
            splitMid.Panel2.BackColor = BgDark;

            // ── Bottom: job history ───────────────────────────
            dgvHistory = BuildGrid(new[]
            {
                ("Job ID",    120, false),
                ("Recipe",    120, false),
                ("Lot ID",    100, false),
                ("Started",   130, false),
                ("Finished",  130, false),
                ("Duration",   80, false),
                ("Result",     80, false),
                ("State",       0, true)
            });
            dgvHistory.Height = 140;
            var grpHistory = WrapGroup("Job History", dgvHistory);
            grpHistory.Dock   = DockStyle.Bottom;
            grpHistory.Height = 168;

            Controls.Add(splitMid);
            Controls.Add(grpHistory);
            Controls.Add(pnlJobCard);
        }

        private Panel BuildJobCard()
        {
            var pnl = new Panel { BackColor = BgCard, Padding = new Padding(10, 8, 10, 8) };

            int lx = 10, cx = 110, gap = 180, row = 24;

            // Row 1
            AddField(pnl, "Job ID:",    lx,        8,  out lblJobId,   out valJobId);
            AddField(pnl, "Recipe:",    lx + gap,  8,  out lblRecipe,  out valRecipe);
            AddField(pnl, "Lot ID:",    lx+gap*2,  8,  out lblLot,     out valLot);
            AddField(pnl, "Carrier:",   lx+gap*3,  8,  out lblCarrier, out valCarrier);

            // Row 2
            AddField(pnl, "State:",     lx,        8+row, out lblState,   out valState);
            AddField(pnl, "Elapsed:",   lx + gap,  8+row, out lblElapsed, out valElapsed);
            AddField(pnl, "Result:",    lx+gap*2,  8+row, out lblResult,  out valResult);

            // State badge (coloured dot)
            pnlStateBadge = new Panel
            {
                Size      = new Size(12, 12),
                Location  = new Point(cx - 18, 8 + row + 6),
                BackColor = Color.Gray
            };
            pnlStateBadge.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.FillEllipse(new SolidBrush(pnlStateBadge.BackColor),
                    0, 0, 11, 11);
            };
            pnlStateBadge.BackColorChanged += (s, e) => pnlStateBadge.Invalidate();
            pnl.Controls.Add(pnlStateBadge);

            // Separator line
            var sep = new Panel
            {
                Location  = new Point(0, 8 + row * 2 + 6),
                Size      = new Size(5000, 1),
                BackColor = Color.FromArgb(50, 65, 90)
            };
            pnl.Controls.Add(sep);

            return pnl;
        }

        private void AddField(Panel parent, string label, int x, int y,
            out Label lblCtrl, out Label valCtrl)
        {
            int cx = x + 90;
            lblCtrl = new Label
            {
                Text      = label,
                Location  = new Point(x, y + 2),
                AutoSize  = true,
                Font      = new Font("Segoe UI", 8.5f),
                ForeColor = TextDim
            };
            valCtrl = new Label
            {
                Text      = "---",
                Location  = new Point(cx, y),
                Size      = new Size(155, 20),
                Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = TextMain
            };
            parent.Controls.Add(lblCtrl);
            parent.Controls.Add(valCtrl);
        }

        private DataGridView BuildGrid((string name, int width, bool fill)[] cols)
        {
            var dgv = new DataGridView
            {
                BackgroundColor       = Color.FromArgb(14, 20, 34),
                ForeColor             = TextMain,
                GridColor             = Color.FromArgb(36, 48, 70),
                BorderStyle           = BorderStyle.None,
                ReadOnly              = true,
                AllowUserToAddRows    = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible     = false,
                SelectionMode         = DataGridViewSelectionMode.FullRowSelect,
                Font                  = new Font("Consolas", 8.5f),
                ColumnHeadersHeight   = 24,
                RowTemplate           = { Height = 19 },
                EnableHeadersVisualStyles = false
            };

            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(24, 34, 56);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(120, 160, 210);
            dgv.ColumnHeadersDefaultCellStyle.Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            dgv.DefaultCellStyle.BackColor              = Color.FromArgb(14, 20, 34);
            dgv.DefaultCellStyle.ForeColor              = TextMain;
            dgv.DefaultCellStyle.SelectionBackColor     = Color.FromArgb(35, 55, 95);

            foreach (var (name, width, fill) in cols)
            {
                var col = new DataGridViewTextBoxColumn { HeaderText = name, ReadOnly = true };
                if (fill)
                    col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                else
                    col.Width = width;
                dgv.Columns.Add(col);
            }

            return dgv;
        }

        private GroupBox WrapGroup(string title, Control child)
        {
            var grp = new GroupBox
            {
                Text      = "  " + title,
                ForeColor = Accent,
                BackColor = BgPanel,
                Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
                Padding   = new Padding(4)
            };
            child.Dock = DockStyle.Fill;
            grp.Controls.Add(child);
            return grp;
        }

        // ─────────────────────────────────────────────────────
        //  Event wiring
        // ─────────────────────────────────────────────────────
        private void WireEvents()
        {
            _monitor.JobStateChanged   += OnJobStateChanged;
            _monitor.EventReceived     += OnEventReceived;
            _monitor.JobHistoryUpdated += OnJobHistoryUpdated;
        }

        private void OnJobStateChanged(object sender, JobRecord job)
        {
            if (InvokeRequired) { Invoke(new Action(() => OnJobStateChanged(sender, job))); return; }
            RefreshCurrentJob();
            slotMap.SetSlots(job.Slots);
        }

        private void OnEventReceived(object sender, JobEvent ev)
        {
            if (InvokeRequired) { Invoke(new Action(() => OnEventReceived(sender, ev))); return; }
            AddEventRow(ev);
        }

        private void OnJobHistoryUpdated(object sender, EventArgs e)
        {
            if (InvokeRequired) { Invoke(new Action(() => OnJobHistoryUpdated(sender, e))); return; }
            RefreshJobHistory();
        }

        // ─────────────────────────────────────────────────────
        //  Refresh methods
        // ─────────────────────────────────────────────────────
        private void RefreshCurrentJob()
        {
            var job = _monitor.CurrentJob;
            if (job == null)
            {
                valJobId.Text   = "---";
                valRecipe.Text  = "---";
                valLot.Text     = "---";
                valCarrier.Text = "---";
                valState.Text   = "No active job";
                valElapsed.Text = "---";
                valResult.Text  = "---";
                pnlStateBadge.BackColor = Color.Gray;
                slotMap.Clear();
                return;
            }

            valJobId.Text   = string.IsNullOrEmpty(job.JobId)    ? "---" : job.JobId;
            valRecipe.Text  = string.IsNullOrEmpty(job.RecipeId)  ? "---" : job.RecipeId;
            valLot.Text     = string.IsNullOrEmpty(job.LotId)     ? "---" : job.LotId;
            valCarrier.Text = string.IsNullOrEmpty(job.CarrierId) ? "---" : job.CarrierId;
            valState.Text   = job.StateDisplay;
            valResult.Text  = string.IsNullOrEmpty(job.ProcessResult) ? "---" : job.ProcessResult;

            pnlStateBadge.BackColor = StateColor(job.State);
            valState.ForeColor      = StateColor(job.State);

            slotMap.SetSlots(job.Slots);
        }

        private void UpdateElapsedTimer()
        {
            var job = _monitor.CurrentJob;
            if (job == null || !job.ElapsedTime.HasValue)
            { valElapsed.Text = "---"; return; }

            var t = job.ElapsedTime.Value;
            valElapsed.Text = string.Format("{0:D2}:{1:D2}:{2:D2}", (int)t.TotalHours, t.Minutes, t.Seconds);
        }

        private void AddEventRow(JobEvent ev)
        {
            int row = dgvEvents.Rows.Add(
                ev.Timestamp.ToString("HH:mm:ss.fff"),
                ev.CeidValue.ToString(),
                ev.CeidName,
                ev.JobId,
                ev.DataSummary);

            // Colour-code by event type
            Color rowColor = RowColorForCeid(ev.CeidValue);
            dgvEvents.Rows[row].DefaultCellStyle.ForeColor = rowColor;

            if (dgvEvents.Rows.Count > 0)
                dgvEvents.FirstDisplayedScrollingRowIndex = dgvEvents.Rows.Count - 1;
        }

        private void RefreshJobHistory()
        {
            dgvHistory.Rows.Clear();
            foreach (var job in _monitor.JobHistory)
            {
                string duration = "---";
                if (job.StartedAt.HasValue && job.FinishedAt.HasValue)
                {
                    var t = job.FinishedAt.Value - job.StartedAt.Value;
                    duration = string.Format("{0:D2}:{1:D2}:{2:D2}",
                        (int)t.TotalHours, t.Minutes, t.Seconds);
                }

                int row = dgvHistory.Rows.Add(
                    job.JobId,
                    job.RecipeId,
                    job.LotId,
                    job.StartedAt.HasValue   ? job.StartedAt.Value.ToString("HH:mm:ss")   : "---",
                    job.FinishedAt.HasValue  ? job.FinishedAt.Value.ToString("HH:mm:ss")  : "---",
                    duration,
                    string.IsNullOrEmpty(job.ProcessResult) ? "---" : job.ProcessResult,
                    job.StateDisplay);

                dgvHistory.Rows[row].DefaultCellStyle.ForeColor = StateColor(job.State);
            }
        }

        // ─────────────────────────────────────────────────────
        //  Colour helpers
        // ─────────────────────────────────────────────────────
        private static Color StateColor(JobState s)
        {
            switch (s)
            {
                case JobState.Executing: return Color.FromArgb(0, 200, 100);
                case JobState.Paused:    return Color.FromArgb(240, 170, 0);
                case JobState.Queued:    return Color.FromArgb(80, 160, 220);
                case JobState.Completed: return Color.FromArgb(0, 180, 90);
                case JobState.Aborted:   return Color.FromArgb(210, 50, 50);
                case JobState.Stopped:   return Color.FromArgb(180, 100, 0);
                default:                 return Color.FromArgb(130, 130, 150);
            }
        }

        private static Color RowColorForCeid(uint ceid)
        {
            if (ceid == GemCeid.ProcessJobStarted || ceid == GemCeid.ControlJobStarted)
                return Color.FromArgb(0, 200, 100);
            if (ceid == GemCeid.ProcessJobFinished || ceid == GemCeid.ControlJobCompleted)
                return Color.FromArgb(0, 180, 90);
            if (ceid == GemCeid.ProcessJobAborted || ceid == GemCeid.ControlJobAborted)
                return Color.FromArgb(210, 60, 60);
            if (ceid == GemCeid.AlarmSet)
                return Color.FromArgb(220, 80, 80);
            if (ceid == GemCeid.ProcessJobPaused)
                return Color.FromArgb(240, 170, 0);
            return Color.FromArgb(160, 175, 200);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; Hide(); return; }
            _uiTimer?.Stop();
            base.OnFormClosing(e);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SlotMapControl — 25-slot FOUP visualisation, owner-drawn
    // ─────────────────────────────────────────────────────────────────────────
    internal class SlotMapControl : Control
    {
        private List<SlotResult> _slots = new List<SlotResult>();
        private const int Cols = 5, Rows = 5, SlotCount = 25;

        public SlotMapControl()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.UserPaint |
                     ControlStyles.OptimizedDoubleBuffer, true);
            BackColor = Color.FromArgb(20, 28, 44);
            Clear();
        }

        public void Clear()
        {
            _slots.Clear();
            for (int i = 1; i <= SlotCount; i++)
                _slots.Add(new SlotResult { SlotNumber = i, State = SlotState.Empty });
            Invalidate();
        }

        public void SetSlots(List<SlotResult> slots)
        {
            _slots = new List<SlotResult>(slots);
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode     = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            g.Clear(BackColor);

            if (_slots.Count == 0) return;

            int padX   = 12, padY = 16;
            int slotW  = (Width  - padX * 2) / Cols;
            int slotH  = (Height - padY * 2) / Rows;
            int corner = 5;

            for (int i = 0; i < SlotCount && i < _slots.Count; i++)
            {
                int col  = i % Cols;
                int row  = i / Cols;
                int x    = padX + col * slotW;
                int y    = padY + row * slotH;
                var slot = _slots[i];

                Color fill   = SlotFill(slot.State);
                Color border = SlotBorder(slot.State);

                var rect = new Rectangle(x + 3, y + 3, slotW - 6, slotH - 6);

                // Shadow
                using (var br = new SolidBrush(Color.FromArgb(30, 0, 0, 0)))
                    g.FillRoundedRect(br, rect.X + 2, rect.Y + 2, rect.Width, rect.Height, corner);

                // Fill
                using (var br = new SolidBrush(fill))
                    g.FillRoundedRect(br, rect.X, rect.Y, rect.Width, rect.Height, corner);

                // Border
                using (var pen = new Pen(border, slot.State == SlotState.Processing ? 2f : 1f))
                    g.DrawRoundedRect(pen, rect.X, rect.Y, rect.Width, rect.Height, corner);

                // Slot number
                using (var f  = new Font("Segoe UI", 7.5f, FontStyle.Bold))
                using (var sf = new StringFormat { Alignment = StringAlignment.Center,
                                                   LineAlignment = StringAlignment.Center })
                {
                    Color tc = slot.State == SlotState.Empty
                        ? Color.FromArgb(60, 70, 90)
                        : Color.White;
                    string label = slot.SlotNumber.ToString();
                    if (slot.State == SlotState.Pass)   label = "✓ " + label;
                    if (slot.State == SlotState.Fail)   label = "✗ " + label;
                    g.DrawString(label, f, new SolidBrush(tc), rect, sf);
                }
            }

            // Legend
            DrawLegend(g, padX, Height - 14);
        }

        private void DrawLegend(Graphics g, int x, int y)
        {
            var items = new[]
            {
                (SlotState.Empty,      "Empty"),
                (SlotState.Pending,    "Pending"),
                (SlotState.Processing, "Processing"),
                (SlotState.Pass,       "Pass"),
                (SlotState.Fail,       "Fail"),
            };
            int lx = x;
            using (var f = new Font("Segoe UI", 7f))
            {
                foreach (var (state, label) in items)
                {
                    using (var br = new SolidBrush(SlotFill(state)))
                        g.FillEllipse(br, lx, y, 8, 8);
                    using (var br = new SolidBrush(Color.FromArgb(130, 145, 165)))
                        g.DrawString(label, f, br, lx + 11, y - 1);
                    lx += 65;
                }
            }
        }

        private static Color SlotFill(SlotState s)
        {
            switch (s)
            {
                case SlotState.Empty:      return Color.FromArgb(28, 36, 55);
                case SlotState.Pending:    return Color.FromArgb(50, 80, 130);
                case SlotState.Processing: return Color.FromArgb(0, 140, 200);
                case SlotState.Pass:       return Color.FromArgb(0, 150, 70);
                case SlotState.Fail:       return Color.FromArgb(170, 30, 30);
                case SlotState.Skipped:    return Color.FromArgb(80, 80, 80);
                default:                   return Color.FromArgb(50, 55, 70);
            }
        }

        private static Color SlotBorder(SlotState s)
        {
            switch (s)
            {
                case SlotState.Processing: return Color.FromArgb(0, 200, 255);
                case SlotState.Pass:       return Color.FromArgb(0, 220, 100);
                case SlotState.Fail:       return Color.FromArgb(230, 50, 50);
                case SlotState.Pending:    return Color.FromArgb(80, 130, 200);
                default:                   return Color.FromArgb(40, 52, 76);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Graphics helpers
    // ─────────────────────────────────────────────────────────────────────────
    internal static class GfxExt
    {
        public static void FillRoundedRect(this Graphics g, Brush b,
            int x, int y, int w, int h, int r)
        {
            using (var path = RndPath(x, y, w, h, r)) g.FillPath(b, path);
        }

        public static void DrawRoundedRect(this Graphics g, Pen p,
            int x, int y, int w, int h, int r)
        {
            using (var path = RndPath(x, y, w, h, r)) g.DrawPath(p, path);
        }

        private static GraphicsPath RndPath(int x, int y, int w, int h, int r)
        {
            var path = new GraphicsPath();
            path.AddArc(x,         y,         r*2, r*2, 180, 90);
            path.AddArc(x+w-r*2,   y,         r*2, r*2, 270, 90);
            path.AddArc(x+w-r*2,   y+h-r*2,   r*2, r*2,   0, 90);
            path.AddArc(x,         y+h-r*2,   r*2, r*2,  90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
