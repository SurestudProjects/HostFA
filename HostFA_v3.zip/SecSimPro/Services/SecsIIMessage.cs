using System;
using System.Text;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  SECS-II data format codes  (SEMI E5 §9)
    //
    //  Each item header byte:
    //    bits 7-2 : format code
    //    bits 1-0 : number of length bytes that follow (1, 2, or 3)
    // ─────────────────────────────────────────────────────────────────────────
    public enum SecsFormat : byte
    {
        List    = 0x00,
        Binary  = 0x08,
        Boolean = 0x24,
        ASCII   = 0x40,
        JIS8    = 0x44,
        I8      = 0x60,
        I1      = 0x62,
        I2      = 0x64,
        I4      = 0x68,
        F8      = 0x80,
        F4      = 0x90,
        U8      = 0xA0,
        U1      = 0xA4,
        U2      = 0xA8,
        U4      = 0xB0
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SecsIIMessage
    //
    //  Correct SECS-II (SEMI E5) encoding/decoding for all GEM messages.
    //
    //  KEY RULES used here:
    //    • Every item starts with 1+ header bytes:
    //        byte[0]      = (format_code | numLenBytes)
    //        byte[1..n]   = length of data that follows, big-endian, numLenBytes wide
    //    • List items contain numLenBytes-encoded COUNT of child items (not bytes!)
    //    • We always use 1 length byte (numLenBytes=1) for simplicity since all
    //      our payloads are well under 255 bytes.
    // ─────────────────────────────────────────────────────────────────────────
    public class MdlnSoftrev
    {
        public string Item1 { get; }
        public string Item2 { get; }
        public MdlnSoftrev(string mdln, string softrev) { Item1 = mdln; Item2 = softrev; }
    }

    public static class SecsIIMessage
    {
        // ── S1F1 — Are You There ─────────────────────────────
        // Primary, header-only (no body)
        public static byte[] S1F1_AreYouThere() => new byte[0];

        // ── S1F2 — On Line Data ──────────────────────────────
        // Reply to S1F1 from host side, or from equipment as unsolicited
        // Body: <L 0>  (empty list — host sends nothing)
        public static byte[] S1F2_OnLineData() => EncodeList();

        // ── S1F13 — Establish Communications Request (ECR) ───
        //
        // SEMI E30 §6.3 specifies the HOST body as:
        //   <L 2
        //     <A[n] MDLN>      — model name (host name or empty)
        //     <A[n] SOFTREV>   — software revision (or empty)
        //   >
        //
        // Many simulators require this exact structure. Sending L[0] causes them
        // to silently reject or ignore the message, leaving equipment in ENABLED.
        //
        public static byte[] S1F13_EstablishCommsReq(string mdln = "", string softrev = "")
        {
            return EncodeList(
                EncodeASCII(mdln    ?? ""),
                EncodeASCII(softrev ?? "")
            );
        }

        // ── S1F14 — Establish Communications Acknowledge (ECA) ─
        //
        // Body: <L 2
        //   <B[1] COMMACK>    — 0x00 = accepted
        //   <L 2
        //     <A[n] MDLN>
        //     <A[n] SOFTREV>
        //   >
        // >
        //
        public static byte[] S1F14_EstablishCommsAck(byte commAck, string mdln = "", string softrev = "")
        {
            return EncodeList(
                EncodeBinary(commAck),
                EncodeList(
                    EncodeASCII(mdln    ?? ""),
                    EncodeASCII(softrev ?? "")
                )
            );
        }

        // ── S1F15 — Request OFF-LINE ──────────────────────────
        public static byte[] S1F15_RequestOffline() => new byte[0];

        // ── S1F17 — Request ON-LINE ───────────────────────────
        public static byte[] S1F17_RequestOnline() => new byte[0];

        // ── S2F17 — Date and Time Request ────────────────────
        // Header-only (no body)
        public static byte[] S2F17_DateTimeReq() => new byte[0];

        // ── S2F18 — Date and Time Data (reply to S2F17) ──────
        // Body: <A[16]> yyyyMMddHHmmsscc  (cc = centiseconds, 2 digits)
        public static byte[] S2F18_DateTimeData(DateTime dt)
        {
            string ts = dt.ToString("yyyyMMddHHmmss")
                      + (dt.Millisecond / 10).ToString("D2");
            return EncodeASCII(ts);
        }

        // ── S2F31 — Date and Time Set ─────────────────────────
        // Body: same format as S2F18
        public static byte[] S2F31_DateTimeSet(DateTime dt) => S2F18_DateTimeData(dt);

        // ─────────────────────────────────────────────────────
        //  PARSE HELPERS
        // ─────────────────────────────────────────────────────

        /// <summary>
        /// Parse COMMACK byte from an S1F14 body.
        ///
        /// Expected structure:
        ///   body[0]          = List header  (0x01 | numLenBytes, then count=2)
        ///   body[1]          = count of list items = 2
        ///   body[2]          = Binary header (0x08 | numLenBytes)
        ///   body[3]          = length = 1
        ///   body[4]          = COMMACK value  ← this is what we want
        ///
        /// Returns null if parsing fails (format not as expected).
        /// </summary>
        public static byte? ParseS1F14CommAck(byte[] body)
        {
            if (body == null || body.Length < 5) return null;

            try
            {
                int pos = 0;

                // Expect a List item
                if ((body[pos] & 0xFC) != (byte)SecsFormat.List) return null;
                int listLenBytes = body[pos] & 0x03;
                if (listLenBytes == 0) return null;
                pos += 1 + listLenBytes;           // skip list header + count byte(s)

                // Expect a Binary item (COMMACK)
                if (pos >= body.Length) return null;
                if ((body[pos] & 0xFC) != (byte)SecsFormat.Binary) return null;
                int binLenBytes = body[pos] & 0x03;
                if (binLenBytes == 0) return null;
                pos++;                             // move past format byte

                // Read the length of the binary item
                int binLen = 0;
                for (int i = 0; i < binLenBytes && pos < body.Length; i++)
                    binLen = (binLen << 8) | body[pos++];

                if (binLen < 1 || pos >= body.Length) return null;

                return body[pos];                  // COMMACK value
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Parse MDLN and SOFTREV from an incoming S1F13 or S1F14 body.
        /// Returns (mdln, softrev) — either may be null/empty if not present.
        /// </summary>
        public static MdlnSoftrev ParseMdlnSoftrev(byte[] body)
        {
            if (body == null || body.Length < 2) return new MdlnSoftrev(null, null);

            try
            {
                int pos = 0;

                // Skip outer list header
                if ((body[pos] & 0xFC) != (byte)SecsFormat.List) return new MdlnSoftrev(null, null);
                int listLenBytes = body[pos] & 0x03;
                pos += 1 + listLenBytes;

                string mdln    = ReadASCIIItem(body, ref pos);
                string softrev = ReadASCIIItem(body, ref pos);
                return new MdlnSoftrev(mdln, softrev);
            }
            catch
            {
                return new MdlnSoftrev(null, null);
            }
        }

        private static string ReadASCIIItem(byte[] body, ref int pos)
        {
            if (pos >= body.Length) return null;
            if ((body[pos] & 0xFC) != (byte)SecsFormat.ASCII) return null;

            int lenBytes = body[pos] & 0x03;
            pos++;
            if (lenBytes == 0) return string.Empty;

            int len = 0;
            for (int i = 0; i < lenBytes && pos < body.Length; i++)
                len = (len << 8) | body[pos++];

            if (pos + len > body.Length) return null;
            string s = Encoding.ASCII.GetString(body, pos, len);
            pos += len;
            return s;
        }

        // ─────────────────────────────────────────────────────
        //  ENCODING PRIMITIVES
        //
        //  All items use 1 length byte (covers up to 255 bytes of payload).
        //  For production use with large data, extend to 2/3 length bytes.
        // ─────────────────────────────────────────────────────

        /// <summary>Encode any SECS-II item: [formatByte | 0x01] [len] [data...]</summary>
        public static byte[] EncodeItem(SecsFormat fmt, byte[] data)
        {
            int len = data?.Length ?? 0;

            // Choose minimum number of length bytes needed
            int numLenBytes = len <= 0xFF ? 1 : len <= 0xFFFF ? 2 : 3;

            byte[] result = new byte[1 + numLenBytes + len];
            result[0] = (byte)((byte)fmt | numLenBytes);

            // Write length big-endian into numLenBytes bytes
            int tmp = len;
            for (int i = numLenBytes; i >= 1; i--)
            {
                result[i] = (byte)(tmp & 0xFF);
                tmp >>= 8;
            }

            if (len > 0)
                Array.Copy(data, 0, result, 1 + numLenBytes, len);

            return result;
        }

        /// <summary>
        /// Encode a List item containing the given child items.
        /// Note: the length field of a List item = NUMBER OF ITEMS (not byte count).
        /// </summary>
        public static byte[] EncodeList(params byte[][] items)
        {
            int count    = items?.Length ?? 0;
            int dataSize = 0;
            if (items != null)
                foreach (var item in items)
                    dataSize += item?.Length ?? 0;

            // List header: format=0x00, numLenBytes=1, then count byte
            byte[] result = new byte[2 + dataSize];
            result[0] = (byte)((byte)SecsFormat.List | 0x01);
            result[1] = (byte)count;

            int pos = 2;
            if (items != null)
            {
                foreach (var item in items)
                {
                    if (item == null || item.Length == 0) continue;
                    Array.Copy(item, 0, result, pos, item.Length);
                    pos += item.Length;
                }
            }
            return result;
        }

        public static byte[] EncodeASCII(string s)
        {
            byte[] raw = Encoding.ASCII.GetBytes(s ?? string.Empty);
            return EncodeItem(SecsFormat.ASCII, raw);
        }

        public static byte[] EncodeBinary(byte value)
        {
            return EncodeItem(SecsFormat.Binary, new byte[] { value });
        }

        public static byte[] EncodeU1(byte value)
        {
            return EncodeItem(SecsFormat.U1, new byte[] { value });
        }

        public static byte[] EncodeU2(ushort value)
        {
            return EncodeItem(SecsFormat.U2, new byte[]
                { (byte)(value >> 8), (byte)value });
        }

        public static byte[] EncodeU4(uint value)
        {
            return EncodeItem(SecsFormat.U4, new byte[]
                { (byte)(value >> 24), (byte)(value >> 16),
                  (byte)(value >> 8),  (byte)value });
        }

        public static byte[] EncodeBool(bool value)
        {
            return EncodeItem(SecsFormat.Boolean, new byte[] { value ? (byte)1 : (byte)0 });
        }
    }
}
