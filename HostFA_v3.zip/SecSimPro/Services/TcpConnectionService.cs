using System;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using SecSimPro.Models;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  TcpConnectionService  v3
    //
    //  Layers:
    //    Transport  : TCP socket
    //    Session    : HSMS (SEMI E37) — Select / Linktest / Separate
    //    Application: GEM  (SEMI E30) — Communication / Control / Processing
    //
    //  GEM state engine is exposed publicly so the UI can:
    //    • read current states at any time
    //    • issue manual override transitions
    //    • subscribe to StateChanged events
    // ─────────────────────────────────────────────────────────────────────────
    public class TcpConnectionService : IDisposable
    {
        // ── Timers ────────────────────────────────────────────
        private const int T3  = 45;   // reply timeout (s)
        private const int T6  = 5;    // control msg timeout (s)
        private const int T7  = 10;   // not-selected timeout (s)
        private const int T8r = 5;    // socket read timeout (s)

        private int _linktestInterval = 15;

        // ── Socket ────────────────────────────────────────────
        private TcpClient               _tcp;
        private NetworkStream           _stream;
        private CancellationTokenSource _cts;
        private Thread                  _rxThread;
        private Thread                  _linktestThread;
        private readonly object         _txLock = new object();
        private uint                    _sysCtr = 1;

        // ── Latches ───────────────────────────────────────────
        private readonly ManualResetEventSlim _selectLatch   = new ManualResetEventSlim(false);
        private readonly ManualResetEventSlim _s1f14Latch    = new ManualResetEventSlim(false);
        private readonly ManualResetEventSlim _linktestLatch = new ManualResetEventSlim(false);

        private HsmsSelectStatus _selectStatus;
        private byte?            _inboundCommAck;
        private bool             _gemHandshakeDone;
        private int              _linktestFailures;
        private bool             _disposed;

        private ConnectionProfile _profile;

        // ── GEM State Engine (public — UI reads + commands it) ─
        public GemStateEngine GemState { get; } = new GemStateEngine();

        // ── Public status & connection ────────────────────────
        public ConnectionStatus    CurrentStatus     { get; private set; } = ConnectionStatus.Disconnected;
        public EquipmentConnection CurrentConnection { get; private set; }
        public bool IsConnected => CurrentStatus == ConnectionStatus.Selected
                                || CurrentStatus == ConnectionStatus.GemOnline;

        public event EventHandler<ConnectionEventArgs> ConnectionStatusChanged;
        public event EventHandler<ConnectionEventArgs> LogMessage;

        public TcpConnectionService()
        {
            // Forward GEM state changes as log messages
            GemState.StateChanged += (s, e) =>
            {
                string msg = e.FromState == e.ToState
                    ? $"GEM [{e.StateMachine}] Transition ignored: {e.FromState} + {e.Trigger} — {e.Reason}"
                    : $"GEM [{e.StateMachine}] {e.FromState} → {e.ToState}  (trigger: {e.Trigger}{(string.IsNullOrEmpty(e.Reason) ? "" : ", " + e.Reason)})";

                Log(LogSeverity.State, msg);
            };
        }

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Connect
        // ─────────────────────────────────────────────────────
        public void Connect(ConnectionProfile p)
        {
            if (CurrentStatus != ConnectionStatus.Disconnected &&
                CurrentStatus != ConnectionStatus.Error)
            {
                Log(LogSeverity.Warning, "Already connected. Disconnect first.");
                return;
            }

            _profile          = p;
            _linktestInterval = p.LinktestIntervalSec > 0 ? p.LinktestIntervalSec : 15;
            _gemHandshakeDone = false;

            GemState.Reset("New connection starting");

            CurrentConnection = new EquipmentConnection
            {
                IpAddress   = p.IpAddress,
                Port        = p.Port,
                Description = p.Description,
                SessionId   = p.SessionId,
                Status      = ConnectionStatus.Connecting
            };

            ChangeStatus(ConnectionStatus.Connecting,
                $"Connecting to {p.IpAddress}:{p.Port}...",
                LogSeverity.Info, p.IpAddress, p.Port);

            Task.Run(() => RunConnect(p));
        }

        // ─────────────────────────────────────────────────────
        //  STAGE 1 — TCP
        // ─────────────────────────────────────────────────────
        private void RunConnect(ConnectionProfile p)
        {
            try
            {
                _tcp         = new TcpClient();
                _tcp.NoDelay = true;

                if (!_tcp.ConnectAsync(p.IpAddress, p.Port)
                         .Wait(TimeSpan.FromSeconds(p.TimeoutSeconds)))
                { Fail($"TCP timeout after {p.TimeoutSeconds}s.", p); return; }

                if (!_tcp.Connected)
                { Fail("TCP refused.", p); return; }

                _stream              = _tcp.GetStream();
                _stream.ReadTimeout  = T8r * 1000;
                _stream.WriteTimeout = T8r * 1000;

                Log(LogSeverity.Info, $"TCP connected → {p.IpAddress}:{p.Port}");

                // GEM: DISABLED → ENABLED (TCP up, ready for HSMS handshake)
                GemState.ApplyComm(CommTrigger.Enable, "TCP connected");

                ChangeStatus(ConnectionStatus.TcpConnected,
                    $"TCP up. Sending HSMS Select.req (Session 0x{p.SessionId:X4})...",
                    LogSeverity.Hsms, p.IpAddress, p.Port);

                _cts = new CancellationTokenSource();
                StartRxLoop(_cts.Token);
                RunHsmsSelect(p);
            }
            catch (SocketException ex) { Fail($"Socket: {SockMsg(ex.SocketErrorCode)}", p); }
            catch (Exception ex)       { Fail($"Connect error: {ex.Message}", p); }
        }

        // ─────────────────────────────────────────────────────
        //  STAGE 2 — HSMS Select
        // ─────────────────────────────────────────────────────
        private void RunHsmsSelect(ConnectionProfile p)
        {
            try
            {
                _selectLatch.Reset();
                var req = HsmsMessage.BuildSelectReq(p.SessionId, NextSys());
                TxLog(req); Send(req.ToBytes());

                if (!_selectLatch.Wait(TimeSpan.FromSeconds(T7)))
                {
                    Fail($"No Select.rsp within T7={T7}s. Check Session ID.", p);
                    return;
                }

                if (_selectStatus != HsmsSelectStatus.Success)
                {
                    Fail($"Select rejected — {_selectStatus} (0x{(byte)_selectStatus:X2}).", p);
                    return;
                }

                CurrentConnection.Status    = ConnectionStatus.Selected;
                CurrentConnection.SessionId = p.SessionId;

                ChangeStatus(ConnectionStatus.Selected,
                    $"HSMS Selected ✓  Session=0x{p.SessionId:X4}. Starting GEM handshake...",
                    LogSeverity.Hsms, p.IpAddress, p.Port);

                StartLinktestTimer(_cts.Token);

                if (p.UseGem)
                    RunGemHandshake(p);
                else
                    FinalizeSelected(p);
            }
            catch (Exception ex) { Fail($"HSMS Select error: {ex.Message}", p); }
        }

        // ─────────────────────────────────────────────────────
        //  STAGE 3 — GEM Establish Communications
        // ─────────────────────────────────────────────────────
        private void RunGemHandshake(ConnectionProfile p)
        {
            Log(LogSeverity.Gem, "GEM: Starting Establish Communications (S1F13 ↔ S1F14)...");
            Log(LogSeverity.Gem, "GEM: Sending S1F13 AND listening for equipment S1F13 simultaneously.");

            _s1f14Latch.Reset();
            _inboundCommAck = null;

            byte[] body = SecsIIMessage.S1F13_EstablishCommsReq(
                p.HostMdln ?? "SecSimPro", p.HostSoftrev ?? "2.0");
            var msg = HsmsMessage.BuildDataMessage(p.SessionId, 1, 13, true, NextSys(), body);

            Log(LogSeverity.Gem,
                $"GEM: TX → S1F13  body=[{BitConverter.ToString(body).Replace("-", " ")}]");
            TxLog(msg); Send(msg.ToBytes());

            bool recv = _s1f14Latch.Wait(TimeSpan.FromSeconds(T3));

            if (!recv)
            {
                Log(LogSeverity.Warning,
                    $"GEM: No S1F14 within T3={T3}s. Staying HSMS SELECTED (no GEM Online).");
                FinalizeSelected(p);
                return;
            }

            byte ack = _inboundCommAck ?? 0xFF;
            if (ack == 0x00)
                AchieveGemOnline(p, "S1F14 COMMACK=0 received");
            else
            {
                Log(LogSeverity.Warning,
                    $"GEM: S1F14 COMMACK=0x{ack:X2} — not accepted. Staying SELECTED.");
                FinalizeSelected(p);
            }
        }

        // ─────────────────────────────────────────────────────
        //  GEM Online achievement — called from either path
        // ─────────────────────────────────────────────────────
        private void AchieveGemOnline(ConnectionProfile p, string reason)
        {
            if (_gemHandshakeDone) return;
            _gemHandshakeDone = true;

            // Comm: ENABLED → COMMUNICATING
            GemState.ApplyComm(CommTrigger.CommSuccess, reason);

            // Control: OFF-LINE → ATTEMPT → ON-LINE LOCAL (auto)
            GemState.ApplyControl(ControlTrigger.GoOnLine, "GEM Online");
            GemState.ApplyControl(ControlTrigger.OnLineSuccess, "Auto on-line local");

            CurrentConnection.Status      = ConnectionStatus.GemOnline;
            CurrentConnection.ConnectedAt = DateTime.Now;

            ChangeStatus(ConnectionStatus.GemOnline,
                "GEM Online ✓  Communication State: COMMUNICATING  Control: ON-LINE LOCAL",
                LogSeverity.Gem, p.IpAddress, p.Port);

            if (p.SendDateTimeOnConnect)
                SendDateTimeSet(p);
        }

        private void FinalizeSelected(ConnectionProfile p)
        {
            if (CurrentStatus == ConnectionStatus.Selected ||
                CurrentStatus == ConnectionStatus.TcpConnected)
            {
                CurrentConnection.ConnectedAt = DateTime.Now;
                ChangeStatus(ConnectionStatus.Selected,
                    "HSMS Selected — GEM handshake not completed.",
                    LogSeverity.Success, p.IpAddress, p.Port);
            }
        }

        private void SendDateTimeSet(ConnectionProfile p)
        {
            try
            {
                var dt   = DateTime.Now;
                var body = SecsIIMessage.S2F31_DateTimeSet(dt);
                var dtMsg = HsmsMessage.BuildDataMessage(p.SessionId, 2, 31, true, NextSys(), body);
                Log(LogSeverity.Gem, $"GEM: TX → S2F31 Date/Time Set: {dt:yyyy-MM-dd HH:mm:ss}");
                TxLog(dtMsg); Send(dtMsg.ToBytes());
            }
            catch (Exception ex)
            {
                Log(LogSeverity.Warning, $"GEM: S2F31 failed: {ex.Message}");
            }
        }

        // ─────────────────────────────────────────────────────
        //  RECEIVE LOOP
        // ─────────────────────────────────────────────────────
        private void StartRxLoop(CancellationToken token)
        {
            _rxThread = new Thread(() =>
            {
                Log(LogSeverity.Info, "RX thread started.");
                try
                {
                    while (!token.IsCancellationRequested)
                    {
                        byte[] lenBuf = ReadExact(4, token);
                        if (lenBuf == null) break;

                        uint msgLen = (uint)((lenBuf[0] << 24) | (lenBuf[1] << 16)
                                           | (lenBuf[2] << 8)  |  lenBuf[3]);

                        if (msgLen < HsmsMessage.HeaderLength || msgLen > 8 * 1024 * 1024)
                        { Log(LogSeverity.Error, $"RX: Bad length {msgLen} — closing."); break; }

                        byte[] hdr  = ReadExact(HsmsMessage.HeaderLength, token);
                        if (hdr == null) break;

                        int    dlen = (int)msgLen - HsmsMessage.HeaderLength;
                        byte[] data = dlen > 0 ? ReadExact(dlen, token) : new byte[0];
                        if (dlen > 0 && data == null) break;

                        Dispatch(HsmsMessage.FromHeader(hdr, data));
                    }
                }
                catch (OperationCanceledException) { }
                catch (IOException)                { }
                catch (Exception ex)
                {
                    if (!token.IsCancellationRequested)
                        Log(LogSeverity.Error, $"RX: {ex.Message}");
                }
                finally
                {
                    if (!token.IsCancellationRequested)
                    { Log(LogSeverity.Warning, "RX loop ended — dropped."); HandleDropped(); }
                    Log(LogSeverity.Info, "RX thread exiting.");
                }
            })
            { IsBackground = true, Name = "HSMS-RX" };
            _rxThread.Start();
        }

        // ─────────────────────────────────────────────────────
        //  DISPATCH
        // ─────────────────────────────────────────────────────
        private void Dispatch(HsmsMessage msg)
        {
            Log(LogSeverity.Hsms, $"RX ← {msg}");
            if (msg.IsControlMessage) HandleControl(msg);
            else                       HandleData(msg);
        }

        private void HandleControl(HsmsMessage msg)
        {
            switch (msg.SType)
            {
                case HsmsSType.SelectRsp:
                    _selectStatus = msg.SelectStatus;
                    _selectLatch.Set();
                    break;

                case HsmsSType.SelectReq:
                    var srsp = HsmsMessage.BuildSelectRsp(
                        msg.SessionId, msg.SystemBytes, HsmsSelectStatus.Success);
                    TxLog(srsp); Send(srsp.ToBytes());
                    break;

                case HsmsSType.LinktestReq:
                    var lrsp = HsmsMessage.BuildLinktestRsp(msg.SystemBytes);
                    TxLog(lrsp); Send(lrsp.ToBytes());
                    break;

                case HsmsSType.LinktestRsp:
                    _linktestFailures = 0;
                    _linktestLatch.Set();
                    break;

                case HsmsSType.SeparateReq:
                    Log(LogSeverity.Warning, "Equipment sent Separate.req — closing session.");
                    HandleDropped();
                    break;

                default:
                    Log(LogSeverity.Hsms, $"Unhandled control: {msg.SType}");
                    break;
            }
        }

        private void HandleData(HsmsMessage msg)
        {
            ushort sid = CurrentConnection?.SessionId ?? _profile?.SessionId ?? 0;

            // ── S1F1 — Are You There ──────────────────────────
            if (msg.Stream == 1 && msg.Function == 1)
            {
                var r = HsmsMessage.BuildDataMessage(sid, 1, 2, false,
                    msg.SystemBytes, SecsIIMessage.S1F2_OnLineData());
                Log(LogSeverity.Gem, "GEM: RX S1F1 → TX S1F2");
                TxLog(r); Send(r.ToBytes());
                return;
            }

            // ── S1F13 — Equipment-initiated Establish Comms ───
            if (msg.Stream == 1 && msg.Function == 13)
            {
                var mdlnSoftrev = SecsIIMessage.ParseMdlnSoftrev(msg.Data);
                string mdln    = mdlnSoftrev.Item1;
                string softrev = mdlnSoftrev.Item2;
                Log(LogSeverity.Gem,
                    $"GEM: RX S1F13 from equipment (MDLN='{mdln ?? ""}' SOFTREV='{softrev ?? ""}')");
                Log(LogSeverity.Gem, "GEM: TX → S1F14 COMMACK=0x00 (Accepted)");

                byte[] ackBody = SecsIIMessage.S1F14_EstablishCommsAck(
                    0x00, _profile?.HostMdln ?? "SecSimPro", _profile?.HostSoftrev ?? "2.0");
                var reply = HsmsMessage.BuildDataMessage(
                    msg.SessionId, 1, 14, false, msg.SystemBytes, ackBody);
                TxLog(reply); Send(reply.ToBytes());

                _inboundCommAck = 0x00;
                _s1f14Latch.Set();

                if (!_gemHandshakeDone && _profile != null)
                    AchieveGemOnline(_profile, "Equipment sent S1F13 → replied S1F14(COMMACK=0)");
                return;
            }

            // ── S1F14 — Reply to our S1F13 ────────────────────
            if (msg.Stream == 1 && msg.Function == 14)
            {
                byte? ack = SecsIIMessage.ParseS1F14CommAck(msg.Data);
                Log(LogSeverity.Gem,
                    $"GEM: RX S1F14 COMMACK=0x{(ack.HasValue ? ack.Value.ToString("X2") : "??")} " +
                    $"raw=[{BitConverter.ToString(msg.Data).Replace("-", " ")}]");
                _inboundCommAck = ack;
                _s1f14Latch.Set();
                return;
            }

            // ── S1F15 — Request OFF-LINE ──────────────────────
            if (msg.Stream == 1 && msg.Function == 15)
            {
                Log(LogSeverity.Warning, "GEM: RX S1F15 Request OFF-LINE from equipment.");
                var r = HsmsMessage.BuildDataMessage(sid, 1, 16, false, msg.SystemBytes, new byte[0]);
                TxLog(r); Send(r.ToBytes());

                // Drive control state to off-line
                GemState.ApplyControl(ControlTrigger.GoOffLine, "Equipment sent S1F15");
                return;
            }

            // ── S1F17 — Request ON-LINE ───────────────────────
            if (msg.Stream == 1 && msg.Function == 17)
            {
                Log(LogSeverity.Gem, "GEM: RX S1F17 Request ON-LINE from equipment.");
                byte oack = (GemState.CommState == CommState.Communicating) ? (byte)0 : (byte)1;
                var r = HsmsMessage.BuildDataMessage(sid, 1, 18, false, msg.SystemBytes,
                    SecsIIMessage.EncodeU1(oack));
                TxLog(r); Send(r.ToBytes());

                if (oack == 0)
                    GemState.ApplyControl(ControlTrigger.GoOnLine, "Equipment sent S1F17");
                return;
            }

            // ── S2F17 — Date/Time Request ─────────────────────
            if (msg.Stream == 2 && msg.Function == 17)
            {
                Log(LogSeverity.Gem, "GEM: RX S2F17 Date/Time request → TX S2F18");
                var dtBody = SecsIIMessage.S2F18_DateTimeData(DateTime.Now);
                var r = HsmsMessage.BuildDataMessage(sid, 2, 18, false, msg.SystemBytes, dtBody);
                TxLog(r); Send(r.ToBytes());
                return;
            }

            // ── S9 — SECS-II errors ───────────────────────────
            if (msg.Stream == 9)
            {
                Log(LogSeverity.Warning,
                    $"SECS-II S9F{msg.Function} {GetS9Desc(msg.Function)} from equipment.");
                return;
            }

            Log(LogSeverity.Info,
                $"Data S{msg.Stream}F{msg.Function} received ({msg.Data.Length}B — not handled).");
        }

        // ─────────────────────────────────────────────────────
        //  LINKTEST TIMER
        // ─────────────────────────────────────────────────────
        private void StartLinktestTimer(CancellationToken token)
        {
            _linktestThread = new Thread(() =>
            {
                Log(LogSeverity.Hsms,
                    $"Linktest started — interval={_linktestInterval}s T6={T6}s.");

                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        for (int i = 0; i < _linktestInterval * 10; i++)
                        {
                            if (token.IsCancellationRequested) return;
                            Thread.Sleep(100);
                        }

                        if (token.IsCancellationRequested) return;

                        _linktestLatch.Reset();
                        var req = HsmsMessage.BuildLinktestReq(NextSys());
                        TxLog(req); Send(req.ToBytes());

                        if (!_linktestLatch.Wait(TimeSpan.FromSeconds(T6)))
                        {
                            _linktestFailures++;
                            Log(LogSeverity.Warning,
                                $"Linktest timeout #{_linktestFailures}/2 (T6={T6}s).");
                            if (_linktestFailures >= 2)
                            {
                                Log(LogSeverity.Error, "2 consecutive linktest failures → lost.");
                                HandleDropped();
                                return;
                            }
                        }
                        else
                        {
                            _linktestFailures = 0;
                            Log(LogSeverity.Hsms, "Linktest ✓");
                        }
                    }
                    catch (OperationCanceledException) { return; }
                    catch { return; }
                }
            })
            { IsBackground = true, Name = "HSMS-Linktest" };
            _linktestThread.Start();
        }

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Manual GEM state overrides (for UI buttons)
        // ─────────────────────────────────────────────────────

        public void ManualGoOnLine()
        {
            if (GemState.CommState != CommState.Communicating)
            { Log(LogSeverity.Warning, "Cannot go On-Line — not in COMMUNICATING state."); return; }
            GemState.ApplyControl(ControlTrigger.GoOnLine, "Manual");
            GemState.ApplyControl(ControlTrigger.OnLineSuccess, "Manual");
        }

        public void ManualGoOffLine()
        {
            if (_stream != null)
            {
                // Send S1F15 Request OFF-LINE to equipment
                try
                {
                    var body = SecsIIMessage.S1F15_RequestOffline();
                    var msg  = HsmsMessage.BuildDataMessage(
                        CurrentConnection?.SessionId ?? 0, 1, 15, false, NextSys(), body);
                    Log(LogSeverity.Gem, "GEM: TX → S1F15 Request OFF-LINE");
                    TxLog(msg); Send(msg.ToBytes());
                }
                catch { }
            }
            GemState.ApplyControl(ControlTrigger.GoOffLine, "Manual");
        }

        public void ManualGoRemote()
        {
            GemState.ApplyControl(ControlTrigger.GoRemote, "Manual");
        }

        public void ManualGoLocal()
        {
            GemState.ApplyControl(ControlTrigger.GoLocal, "Manual");
        }

        public void ManualStartProcessing()
        {
            GemState.ApplyProc(ProcTrigger.Start, "Manual");
        }

        public void ManualPauseProcessing()
        {
            GemState.ApplyProc(ProcTrigger.Pause, "Manual");
        }

        public void ManualResumeProcessing()
        {
            GemState.ApplyProc(ProcTrigger.Resume, "Manual");
        }

        public void ManualStopProcessing()
        {
            GemState.ApplyProc(ProcTrigger.Stop, "Manual");
        }

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Disconnect
        // ─────────────────────────────────────────────────────
        public void Disconnect()
        {
            try
            {
                string ip   = CurrentConnection?.IpAddress ?? "";
                int    port = CurrentConnection?.Port ?? 0;

                if (_stream != null && (CurrentStatus == ConnectionStatus.Selected ||
                                        CurrentStatus == ConnectionStatus.GemOnline))
                {
                    try
                    {
                        var sep = HsmsMessage.BuildSeparateReq(
                            CurrentConnection?.SessionId ?? 0, NextSys());
                        TxLog(sep); Send(sep.ToBytes());
                        Thread.Sleep(150);
                    }
                    catch { }
                }

                Cleanup();
                GemState.Reset("User disconnected");

                if (CurrentConnection != null)
                {
                    CurrentConnection.Status         = ConnectionStatus.Disconnected;
                    CurrentConnection.DisconnectedAt = DateTime.Now;
                }

                ChangeStatus(ConnectionStatus.Disconnected,
                    $"Disconnected from {ip}:{port}.",
                    LogSeverity.Warning, ip, port);
            }
            catch (Exception ex)
            {
                Log(LogSeverity.Error, $"Disconnect error: {ex.Message}");
            }
        }

        // ─────────────────────────────────────────────────────
        //  INTERNAL
        // ─────────────────────────────────────────────────────
        private void HandleDropped()
        {
            if (CurrentStatus == ConnectionStatus.Disconnected) return;

            string ip   = CurrentConnection?.IpAddress ?? "";
            int    port = CurrentConnection?.Port ?? 0;

            Cleanup();
            GemState.Reset("Connection dropped");

            if (CurrentConnection != null)
                CurrentConnection.Status = ConnectionStatus.Error;

            ChangeStatus(ConnectionStatus.Error,
                "Connection lost — equipment closed session or network failure.",
                LogSeverity.Error, ip, port);
        }

        private void Cleanup()
        {
            _cts?.Cancel();
            try { _stream?.Close(); } catch { }
            try { _tcp?.Close();    } catch { }
            _stream = null;
            _tcp    = null;
        }

        private byte[] ReadExact(int count, CancellationToken token)
        {
            var buf = new byte[count];
            int rx  = 0;
            while (rx < count)
            {
                if (token.IsCancellationRequested) return null;
                int n;
                try { n = _stream.Read(buf, rx, count - rx); }
                catch (IOException ex)
                    when (ex.InnerException is SocketException sx &&
                          sx.SocketErrorCode == SocketError.TimedOut) { continue; }
                if (n == 0) return null;
                rx += n;
            }
            return buf;
        }

        private void Send(byte[] data)
        {
            lock (_txLock) { _stream?.Write(data, 0, data.Length); }
        }

        private void TxLog(HsmsMessage m) => Log(LogSeverity.Hsms, $"TX → {m}");
        private uint NextSys()            => _sysCtr++;

        private void ChangeStatus(ConnectionStatus st, string msg, LogSeverity sev,
                                   string ip = "", int port = 0)
        {
            CurrentStatus = st;
            var a = new ConnectionEventArgs(st, msg, sev, ip, port);
            a.CommState       = GemState.CommState;
            a.ControlState    = GemState.ControlState;
            a.ProcessingState = GemState.ProcessingState;
            ConnectionStatusChanged?.Invoke(this, a);
        }

        private void Log(LogSeverity sev, string msg)
        {
            var a = new ConnectionEventArgs(CurrentStatus, msg, sev);
            a.CommState       = GemState.CommState;
            a.ControlState    = GemState.ControlState;
            a.ProcessingState = GemState.ProcessingState;
            LogMessage?.Invoke(this, a);
        }

        private void Fail(string msg, ConnectionProfile p)
        {
            Cleanup();
            GemState.Reset("Connection failed");
            if (CurrentConnection != null)
                CurrentConnection.Status = ConnectionStatus.Error;
            ChangeStatus(ConnectionStatus.Error, msg,
                LogSeverity.Error, p?.IpAddress ?? "", p?.Port ?? 0);
        }

        private static string SockMsg(SocketError e)
        {
            switch (e)
            {
                case SocketError.ConnectionRefused:  return "Refused.";
                case SocketError.HostUnreachable:
                case SocketError.HostNotFound:       return "Host not found.";
                case SocketError.NetworkUnreachable: return "Network unreachable.";
                case SocketError.TimedOut:           return "Timed out.";
                default:                              return e.ToString();
            }
        }

        private static string GetS9Desc(byte f)
        {
            switch (f)
            {
                case 1:  return "(Unrecognised Device ID)";
                case 3:  return "(Unrecognised Stream)";
                case 5:  return "(Unrecognised Function)";
                case 7:  return "(Illegal Data)";
                case 9:  return "(Transaction Timer Timeout)";
                case 11: return "(Data Too Long)";
                case 13: return "(Conversation Timeout)";
                default: return "";
            }
        }

        public void Dispose()
        {
            if (!_disposed) { Cleanup(); _disposed = true; }
        }
    }
}
