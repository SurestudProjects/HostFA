using System;
using System.Collections.Generic;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  GEM Communication State  (SEMI E30 §7.1)
    //
    //  DISABLED ──(Enable)──────────────────► ENABLED
    //  ENABLED  ──(S1F13/S1F14 exchange)───► COMMUNICATING
    //  COMMUNICATING ──(Comms fail / T3)──► ENABLED
    //  Any ──(Disable)──────────────────────► DISABLED
    // ─────────────────────────────────────────────────────────────────────────
    public enum CommState
    {
        Disabled,
        Enabled,
        Communicating
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GEM Control State  (SEMI E30 §7.3)
    //
    //  OFF_LINE ──(GoOnline)──► ATTEMPT_ONLINE ──(success)──► ON_LINE_LOCAL
    //                                            └──(fail)──► OFF_LINE
    //  ON_LINE_LOCAL  ──(RemoteCmd S2F41)──► ON_LINE_REMOTE
    //  ON_LINE_REMOTE ──(LocalCmd)──────────► ON_LINE_LOCAL
    //  Any online ──(GoOffline)─────────────► OFF_LINE
    // ─────────────────────────────────────────────────────────────────────────
    public enum ControlState
    {
        OffLine,
        AttemptOnLine,
        OnLineLocal,
        OnLineRemote
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GEM Processing State  (SEMI E30 §7.4 — simplified host model)
    //
    //  IDLE ──(Start)──► EXECUTING ──(Pause)──► PAUSED ──(Resume)──► EXECUTING
    //  EXECUTING ──(Stop/Complete)──► IDLE
    //  PAUSED    ──(Stop)──────────► IDLE
    // ─────────────────────────────────────────────────────────────────────────
    public enum ProcessingState
    {
        Idle,
        Executing,
        Paused
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  State transition triggers
    // ─────────────────────────────────────────────────────────────────────────
    public enum CommTrigger    { Enable, Disable, CommSuccess, CommFail }
    public enum ControlTrigger { GoOnLine, GoOffLine, OnLineSuccess, OnLineFail, GoRemote, GoLocal }
    public enum ProcTrigger    { Start, Pause, Resume, Stop, Complete }

    // ─────────────────────────────────────────────────────────────────────────
    //  State change event args
    // ─────────────────────────────────────────────────────────────────────────
    public class GemStateChangedEventArgs : EventArgs
    {
        public string     StateMachine { get; }  // "Comm" | "Control" | "Processing"
        public string     FromState    { get; }
        public string     ToState      { get; }
        public string     Trigger      { get; }
        public string     Reason       { get; }
        public DateTime   Timestamp    { get; }

        public GemStateChangedEventArgs(string machine, string from, string to,
                                         string trigger, string reason = "")
        {
            StateMachine = machine;
            FromState    = from;
            ToState      = to;
            Trigger      = trigger;
            Reason       = reason;
            Timestamp    = DateTime.Now;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GemStateEngine — manages all three GEM state machines together
    // ─────────────────────────────────────────────────────────────────────────
    public class GemStateEngine
    {
        // ── Current states ────────────────────────────────────
        public CommState       CommState       { get; private set; } = CommState.Disabled;
        public ControlState    ControlState    { get; private set; } = ControlState.OffLine;
        public ProcessingState ProcessingState { get; private set; } = ProcessingState.Idle;

        // ── State history ─────────────────────────────────────
        private readonly List<GemStateChangedEventArgs> _history
            = new List<GemStateChangedEventArgs>();
        public IReadOnlyList<GemStateChangedEventArgs> History => _history.AsReadOnly();

        // ── Events ────────────────────────────────────────────
        public event EventHandler<GemStateChangedEventArgs> StateChanged;

        // ─────────────────────────────────────────────────────
        //  COMMUNICATION STATE MACHINE
        // ─────────────────────────────────────────────────────
        public bool ApplyComm(CommTrigger trigger, string reason = "")
        {
            var from = CommState;
            CommState next;

            switch (CommState)
            {
                case CommState.Disabled:
                    if (trigger == CommTrigger.Enable)        { next = CommState.Enabled; break; }
                    return InvalidTransition("Comm", from, trigger.ToString());

                case CommState.Enabled:
                    if (trigger == CommTrigger.Disable)       { next = CommState.Disabled; break; }
                    if (trigger == CommTrigger.CommSuccess)   { next = CommState.Communicating; break; }
                    return InvalidTransition("Comm", from, trigger.ToString());

                case CommState.Communicating:
                    if (trigger == CommTrigger.Disable)       { next = CommState.Disabled; break; }
                    if (trigger == CommTrigger.CommFail)      { next = CommState.Enabled; break; }
                    return InvalidTransition("Comm", from, trigger.ToString());

                default: return false;
            }

            CommState = next;
            Fire("Comm", from.ToString(), next.ToString(), trigger.ToString(), reason);

            // Auto side-effects:
            // When comms lost → reset control to offline, processing to idle
            if (next == CommState.Enabled || next == CommState.Disabled)
            {
                if (ControlState != ControlState.OffLine)
                    ApplyControl(ControlTrigger.GoOffLine, "Communication lost");
                if (ProcessingState != ProcessingState.Idle)
                    ApplyProc(ProcTrigger.Stop, "Communication lost");
            }

            return true;
        }

        // ─────────────────────────────────────────────────────
        //  CONTROL STATE MACHINE
        // ─────────────────────────────────────────────────────
        public bool ApplyControl(ControlTrigger trigger, string reason = "")
        {
            // Control state only meaningful when COMMUNICATING
            if (CommState != CommState.Communicating &&
                trigger != ControlTrigger.GoOffLine)
            {
                Fire("Control", ControlState.ToString(), ControlState.ToString(),
                     trigger.ToString(),
                     "Ignored — must be in COMMUNICATING state first.");
                return false;
            }

            var from = ControlState;
            ControlState next;

            switch (ControlState)
            {
                case ControlState.OffLine:
                    if (trigger == ControlTrigger.GoOnLine)
                    {
                        next = ControlState.AttemptOnLine;
                        ControlState = next;
                        Fire("Control", from.ToString(), next.ToString(), trigger.ToString(), reason);
                        return true;
                    }
                    return InvalidTransition("Control", from, trigger.ToString());

                case ControlState.AttemptOnLine:
                    if (trigger == ControlTrigger.OnLineSuccess) { next = ControlState.OnLineLocal;  break; }
                    if (trigger == ControlTrigger.OnLineFail)    { next = ControlState.OffLine;      break; }
                    if (trigger == ControlTrigger.GoOffLine)     { next = ControlState.OffLine;      break; }
                    return InvalidTransition("Control", from, trigger.ToString());

                case ControlState.OnLineLocal:
                    if (trigger == ControlTrigger.GoOffLine)  { next = ControlState.OffLine;      break; }
                    if (trigger == ControlTrigger.GoRemote)   { next = ControlState.OnLineRemote; break; }
                    return InvalidTransition("Control", from, trigger.ToString());

                case ControlState.OnLineRemote:
                    if (trigger == ControlTrigger.GoOffLine)  { next = ControlState.OffLine;      break; }
                    if (trigger == ControlTrigger.GoLocal)    { next = ControlState.OnLineLocal;  break; }
                    return InvalidTransition("Control", from, trigger.ToString());

                default: return false;
            }

            ControlState = next;
            Fire("Control", from.ToString(), next.ToString(), trigger.ToString(), reason);
            return true;
        }

        // ─────────────────────────────────────────────────────
        //  PROCESSING STATE MACHINE
        // ─────────────────────────────────────────────────────
        public bool ApplyProc(ProcTrigger trigger, string reason = "")
        {
            var from = ProcessingState;
            ProcessingState next;

            switch (ProcessingState)
            {
                case ProcessingState.Idle:
                    if (trigger == ProcTrigger.Start)    { next = ProcessingState.Executing; break; }
                    return InvalidTransition("Processing", from, trigger.ToString());

                case ProcessingState.Executing:
                    if (trigger == ProcTrigger.Pause)    { next = ProcessingState.Paused;   break; }
                    if (trigger == ProcTrigger.Stop)     { next = ProcessingState.Idle;     break; }
                    if (trigger == ProcTrigger.Complete) { next = ProcessingState.Idle;     break; }
                    return InvalidTransition("Processing", from, trigger.ToString());

                case ProcessingState.Paused:
                    if (trigger == ProcTrigger.Resume)   { next = ProcessingState.Executing; break; }
                    if (trigger == ProcTrigger.Stop)     { next = ProcessingState.Idle;      break; }
                    return InvalidTransition("Processing", from, trigger.ToString());

                default: return false;
            }

            ProcessingState = next;
            Fire("Processing", from.ToString(), next.ToString(), trigger.ToString(), reason);
            return true;
        }

        // ─────────────────────────────────────────────────────
        //  Reset — called on disconnect
        // ─────────────────────────────────────────────────────
        public void Reset(string reason = "Disconnected")
        {
            if (ProcessingState != ProcessingState.Idle)
                ApplyProc(ProcTrigger.Stop, reason);
            if (ControlState != ControlState.OffLine)
                ApplyControl(ControlTrigger.GoOffLine, reason);
            if (CommState != CommState.Disabled)
                ApplyComm(CommTrigger.Disable, reason);
        }

        // ─────────────────────────────────────────────────────
        //  Helpers
        // ─────────────────────────────────────────────────────
        private bool InvalidTransition(string machine, object from, string trigger)
        {
            var e = new GemStateChangedEventArgs(machine, from.ToString(), from.ToString(),
                trigger, $"Invalid transition ignored ({from} + {trigger})");
            _history.Add(e);
            StateChanged?.Invoke(this, e);
            return false;
        }

        private void Fire(string machine, string from, string to, string trigger, string reason)
        {
            var e = new GemStateChangedEventArgs(machine, from, to, trigger, reason);
            _history.Add(e);
            StateChanged?.Invoke(this, e);
        }

        // ─────────────────────────────────────────────────────
        //  Display helpers
        // ─────────────────────────────────────────────────────
        public string CommStateDisplay
        {
            get
            {
                switch (CommState)
                {
                    case CommState.Disabled:      return "DISABLED";
                    case CommState.Enabled:       return "ENABLED";
                    case CommState.Communicating: return "COMMUNICATING";
                    default:                      return "UNKNOWN";
                }
            }
        }

        public string ControlStateDisplay
        {
            get
            {
                switch (ControlState)
                {
                    case ControlState.OffLine:       return "OFF-LINE";
                    case ControlState.AttemptOnLine: return "ATTEMPT ON-LINE";
                    case ControlState.OnLineLocal:   return "ON-LINE LOCAL";
                    case ControlState.OnLineRemote:  return "ON-LINE REMOTE";
                    default:                         return "UNKNOWN";
                }
            }
        }

        public string ProcessingStateDisplay
        {
            get
            {
                switch (ProcessingState)
                {
                    case ProcessingState.Idle:      return "IDLE";
                    case ProcessingState.Executing: return "EXECUTING";
                    case ProcessingState.Paused:    return "PAUSED";
                    default:                        return "UNKNOWN";
                }
            }
        }
    }
}
