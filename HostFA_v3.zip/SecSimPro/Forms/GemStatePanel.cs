using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using SecSimPro.Services;

namespace SecSimPro.Forms
{
    // ─────────────────────────────────────────────────────────────────────────
    //  GemStatePanel — dockable/floating panel showing:
    //    • Live state diagram for all 3 GEM state machines
    //    • Manual override buttons
    //    • State transition history grid
    // ─────────────────────────────────────────────────────────────────────────
    public class GemStatePanel : Form
    {
        private readonly TcpConnectionService _svc;

        // ── Controls ──────────────────────────────────────────
        private StateDiagramPanel pnlCommDiagram;
        private StateDiagramPanel pnlControlDiagram;
        private StateDiagramPanel pnlProcDiagram;

        private DataGridView dgvHistory;
        private Label        lblCommState;
        private Label        lblControlState;
        private Label        lblProcState;

        // Comm buttons
        private Button btnEnable, btnDisable;
        // Control buttons
        private Button btnGoOnLine, btnGoOffLine, btnGoRemote, btnGoLocal;
        // Processing buttons
        private Button btnStart, btnPause, btnResume, btnStop;

        private Timer _refreshTimer;

        // ── Colours ───────────────────────────────────────────
        private static readonly Color ColActive    = Color.FromArgb(0, 180, 90);
        private static readonly Color ColInactive  = Color.FromArgb(60, 70, 95);
        private static readonly Color ColError     = Color.FromArgb(200, 50, 50);
        private static readonly Color ColTransit   = Color.FromArgb(230, 150, 0);
        private static readonly Color ColBg        = Color.FromArgb(22, 28, 44);
        private static readonly Color ColPanel     = Color.FromArgb(30, 38, 58);
        private static readonly Color ColGroupHdr  = Color.FromArgb(0, 130, 200);

        public GemStatePanel(TcpConnectionService svc)
        {
            _svc = svc;
            BuildUI();

            _svc.GemState.StateChanged += OnStateChanged;

            _refreshTimer = new Timer { Interval = 500 };
            _refreshTimer.Tick += (s, e) => RefreshStates();
            _refreshTimer.Start();

            RefreshStates();
            UpdateButtonStates();
        }

        // ─────────────────────────────────────────────────────
        //  UI Construction
        // ─────────────────────────────────────────────────────
        private void BuildUI()
        {
            this.Text             = "GEM State Monitor  (SEMI E30)";
            this.Size             = new Size(1020, 700);
            this.MinimumSize      = new Size(900, 600);
            this.BackColor        = ColBg;
            this.ForeColor        = Color.White;
            this.Font             = new Font("Segoe UI", 8.5f);
            this.StartPosition    = FormStartPosition.Manual;
            this.FormBorderStyle  = FormBorderStyle.SizableToolWindow;
            this.ShowInTaskbar    = false;

            // ── Top: three state diagram panels ───────────────
            var pnlDiagrams = new Panel
            {
                Dock        = DockStyle.Top,
                Height      = 220,
                BackColor   = ColBg,
                Padding     = new Padding(6, 6, 6, 0)
            };

            pnlCommDiagram    = MakeDiagram("Communication State",    BuildCommNodes());
            pnlControlDiagram = MakeDiagram("Control State",          BuildControlNodes());
            pnlProcDiagram    = MakeDiagram("Processing State",       BuildProcNodes());

            pnlCommDiagram.Dock    = DockStyle.Left;
            pnlCommDiagram.Width   = 310;
            pnlControlDiagram.Dock = DockStyle.Left;
            pnlControlDiagram.Width = 360;
            pnlProcDiagram.Dock    = DockStyle.Fill;

            pnlDiagrams.Controls.Add(pnlProcDiagram);
            pnlDiagrams.Controls.Add(pnlControlDiagram);
            pnlDiagrams.Controls.Add(pnlCommDiagram);

            // ── Middle: current state labels + manual buttons ──
            var pnlControls = new Panel
            {
                Dock      = DockStyle.Top,
                Height    = 180,
                BackColor = ColPanel,
                Padding   = new Padding(8, 6, 8, 6)
            };
            BuildControlsPanel(pnlControls);

            // ── Bottom: history grid ───────────────────────────
            var grpHistory = new GroupBox
            {
                Dock      = DockStyle.Fill,
                Text      = "  State Transition History",
                ForeColor = ColGroupHdr,
                BackColor = ColBg,
                Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
                Padding   = new Padding(6)
            };

            dgvHistory = new DataGridView
            {
                Dock                  = DockStyle.Fill,
                BackgroundColor       = Color.FromArgb(18, 24, 38),
                ForeColor             = Color.FromArgb(210, 220, 235),
                GridColor             = Color.FromArgb(40, 50, 70),
                BorderStyle           = BorderStyle.None,
                ReadOnly              = true,
                AllowUserToAddRows    = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible     = false,
                SelectionMode         = DataGridViewSelectionMode.FullRowSelect,
                Font                  = new Font("Consolas", 8.5f),
                ColumnHeadersHeight   = 26,
                RowTemplate           = { Height = 20 }
            };
            dgvHistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 40, 65);
            dgvHistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(140, 175, 220);
            dgvHistory.ColumnHeadersDefaultCellStyle.Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            dgvHistory.DefaultCellStyle.BackColor = Color.FromArgb(18, 24, 38);
            dgvHistory.DefaultCellStyle.ForeColor = Color.FromArgb(210, 220, 235);
            dgvHistory.DefaultCellStyle.SelectionBackColor = Color.FromArgb(40, 60, 100);
            dgvHistory.EnableHeadersVisualStyles = false;

            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn
                { Name = "Time",    HeaderText = "Time",         Width = 90,  ReadOnly = true });
            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn
                { Name = "Machine", HeaderText = "State Machine",Width = 110, ReadOnly = true });
            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn
                { Name = "From",    HeaderText = "From",         Width = 140, ReadOnly = true });
            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn
                { Name = "To",      HeaderText = "To",           Width = 160, ReadOnly = true });
            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn
                { Name = "Trigger", HeaderText = "Trigger",      Width = 130, ReadOnly = true });
            dgvHistory.Columns["Time"].DefaultCellStyle.ForeColor    = Color.FromArgb(100, 140, 200);
            dgvHistory.Columns["Machine"].DefaultCellStyle.ForeColor = Color.FromArgb(160, 110, 220);

            var lastCol = new DataGridViewTextBoxColumn
                { Name = "Reason", HeaderText = "Reason", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, ReadOnly = true };
            dgvHistory.Columns.Add(lastCol);

            grpHistory.Controls.Add(dgvHistory);

            this.Controls.Add(grpHistory);
            this.Controls.Add(pnlControls);
            this.Controls.Add(pnlDiagrams);
        }

        private void BuildControlsPanel(Panel p)
        {
            int cx = 12, cy = 8, bw = 110, bh = 28, gap = 6;

            // ── Comm state ────────────────────────────────────
            var lComm = SectionLabel("Communication", cx, cy);
            lblCommState = StateValueLabel("DISABLED", cx, cy + 20);
            btnEnable    = MakeBtn("Enable",   cx,      cy + 44, ColActive);
            btnDisable   = MakeBtn("Disable",  cx+bw+gap, cy + 44, ColError);
            btnEnable.Click  += (s, e) => { _svc.GemState.ApplyComm(CommTrigger.Enable,  "Manual"); UpdateButtonStates(); };
            btnDisable.Click += (s, e) => { _svc.GemState.ApplyComm(CommTrigger.Disable, "Manual"); UpdateButtonStates(); };

            // ── Control state ─────────────────────────────────
            int cx2 = 290;
            var lCtrl    = SectionLabel("Control", cx2, cy);
            lblControlState = StateValueLabel("OFF-LINE", cx2, cy + 20);
            btnGoOnLine  = MakeBtn("Go On-Line",  cx2,           cy + 44, ColActive);
            btnGoOffLine = MakeBtn("Go Off-Line",  cx2+bw+gap,   cy + 44, Color.FromArgb(140, 50, 50));
            btnGoRemote  = MakeBtn("Go Remote",    cx2,           cy + 80, Color.FromArgb(0, 100, 180));
            btnGoLocal   = MakeBtn("Go Local",     cx2+bw+gap,   cy + 80, Color.FromArgb(60, 80, 150));
            btnGoOnLine.Click  += (s, e) => { _svc.ManualGoOnLine();  UpdateButtonStates(); };
            btnGoOffLine.Click += (s, e) => { _svc.ManualGoOffLine(); UpdateButtonStates(); };
            btnGoRemote.Click  += (s, e) => { _svc.ManualGoRemote();  UpdateButtonStates(); };
            btnGoLocal.Click   += (s, e) => { _svc.ManualGoLocal();   UpdateButtonStates(); };

            // ── Processing state ──────────────────────────────
            int cx3 = 570;
            var lProc   = SectionLabel("Processing", cx3, cy);
            lblProcState = StateValueLabel("IDLE", cx3, cy + 20);
            btnStart     = MakeBtn("Start",   cx3,          cy + 44, ColActive);
            btnPause     = MakeBtn("Pause",   cx3+bw+gap,   cy + 44, ColTransit);
            btnResume    = MakeBtn("Resume",  cx3,           cy + 80, Color.FromArgb(0, 140, 100));
            btnStop      = MakeBtn("Stop",    cx3+bw+gap,   cy + 80, ColError);
            btnStart.Click   += (s, e) => { _svc.ManualStartProcessing();  UpdateButtonStates(); };
            btnPause.Click   += (s, e) => { _svc.ManualPauseProcessing();  UpdateButtonStates(); };
            btnResume.Click  += (s, e) => { _svc.ManualResumeProcessing(); UpdateButtonStates(); };
            btnStop.Click    += (s, e) => { _svc.ManualStopProcessing();   UpdateButtonStates(); };

            // Legend
            var legend = new Label
            {
                Text      = "SEMI E30 state machines — auto-driven by HSMS/GEM handshake. Manual overrides available while connected.",
                AutoSize  = false, Size = new Size(380, 36),
                Location  = new Point(820, cy + 20),
                ForeColor = Color.FromArgb(100, 130, 180),
                Font      = new Font("Segoe UI", 8f)
            };

            p.Controls.AddRange(new Control[]
            {
                lComm, lblCommState, btnEnable, btnDisable,
                lCtrl, lblControlState, btnGoOnLine, btnGoOffLine, btnGoRemote, btnGoLocal,
                lProc, lblProcState, btnStart, btnPause, btnResume, btnStop,
                legend
            });
        }

        // ─────────────────────────────────────────────────────
        //  State change handler
        // ─────────────────────────────────────────────────────
        private void OnStateChanged(object sender, GemStateChangedEventArgs e)
        {
            if (InvokeRequired) { Invoke(new Action(() => OnStateChanged(sender, e))); return; }

            // Add to history grid
            int row = dgvHistory.Rows.Add(
                e.Timestamp.ToString("HH:mm:ss.fff"),
                e.StateMachine,
                e.FromState,
                e.ToState,
                e.Trigger,
                e.Reason);

            // Colour-code row
            bool same = e.FromState == e.ToState;
            dgvHistory.Rows[row].DefaultCellStyle.ForeColor =
                same ? Color.FromArgb(120, 120, 120) : Color.FromArgb(210, 220, 235);
            dgvHistory.Rows[row].DefaultCellStyle.BackColor =
                same ? Color.FromArgb(18, 24, 38)
                     : e.ToState.Contains("COMMUNICATING") || e.ToState.Contains("ON-LINE")
                         ? Color.FromArgb(20, 40, 30)
                         : Color.FromArgb(18, 24, 38);

            // Scroll to bottom
            if (dgvHistory.Rows.Count > 0)
                dgvHistory.FirstDisplayedScrollingRowIndex = dgvHistory.Rows.Count - 1;

            RefreshStates();
            UpdateButtonStates();
            pnlCommDiagram.Invalidate();
            pnlControlDiagram.Invalidate();
            pnlProcDiagram.Invalidate();
        }

        // ─────────────────────────────────────────────────────
        //  Refresh labels
        // ─────────────────────────────────────────────────────
        private void RefreshStates()
        {
            if (InvokeRequired) { Invoke(new Action(RefreshStates)); return; }

            var g = _svc.GemState;
            lblCommState.Text    = g.CommStateDisplay;
            lblControlState.Text = g.ControlStateDisplay;
            lblProcState.Text    = g.ProcessingStateDisplay;

            lblCommState.ForeColor    = CommColor(g.CommState);
            lblControlState.ForeColor = CtrlColor(g.ControlState);
            lblProcState.ForeColor    = ProcColor(g.ProcessingState);

            pnlCommDiagram.ActiveState    = g.CommStateDisplay;
            pnlControlDiagram.ActiveState = g.ControlStateDisplay;
            pnlProcDiagram.ActiveState    = g.ProcessingStateDisplay;

            pnlCommDiagram.Invalidate();
            pnlControlDiagram.Invalidate();
            pnlProcDiagram.Invalidate();
        }

        private void UpdateButtonStates()
        {
            if (InvokeRequired) { Invoke(new Action(UpdateButtonStates)); return; }

            var g       = _svc.GemState;
            bool online = _svc.IsConnected;

            // Comm
            btnEnable.Enabled  = online && g.CommState == CommState.Disabled;
            btnDisable.Enabled = online && g.CommState != CommState.Disabled;

            // Control
            bool comm = g.CommState == CommState.Communicating;
            btnGoOnLine.Enabled  = online && comm && g.ControlState == ControlState.OffLine;
            btnGoOffLine.Enabled = online && comm && g.ControlState != ControlState.OffLine;
            btnGoRemote.Enabled  = online && comm && g.ControlState == ControlState.OnLineLocal;
            btnGoLocal.Enabled   = online && comm && g.ControlState == ControlState.OnLineRemote;

            // Processing
            btnStart.Enabled  = online && g.ProcessingState == ProcessingState.Idle;
            btnPause.Enabled  = online && g.ProcessingState == ProcessingState.Executing;
            btnResume.Enabled = online && g.ProcessingState == ProcessingState.Paused;
            btnStop.Enabled   = online && (g.ProcessingState == ProcessingState.Executing ||
                                            g.ProcessingState == ProcessingState.Paused);
        }

        // ─────────────────────────────────────────────────────
        //  State diagram nodes
        // ─────────────────────────────────────────────────────
        private List<StateNode> BuildCommNodes()
        {
            return new List<StateNode>
            {
                new StateNode("DISABLED",      10,  50, "Initial state — no comms"),
                new StateNode("ENABLED",        10, 130, "TCP up, awaiting handshake"),
                new StateNode("COMMUNICATING", 10, 210, "S1F13/S1F14 exchanged ✓"),
            };
        }

        private List<StateNode> BuildControlNodes()
        {
            return new List<StateNode>
            {
                new StateNode("OFF-LINE",        10,  50, "Not on-line"),
                new StateNode("ATTEMPT ON-LINE", 10, 120, "Attempting..."),
                new StateNode("ON-LINE LOCAL",   10, 190, "Local control"),
                new StateNode("ON-LINE REMOTE",  10, 260, "Remote control"),
            };
        }

        private List<StateNode> BuildProcNodes()
        {
            return new List<StateNode>
            {
                new StateNode("IDLE",      10,  50, "No process running"),
                new StateNode("EXECUTING", 10, 140, "Process active"),
                new StateNode("PAUSED",    10, 230, "Process paused"),
            };
        }

        // ─────────────────────────────────────────────────────
        //  Factory helpers
        // ─────────────────────────────────────────────────────
        private StateDiagramPanel MakeDiagram(string title, List<StateNode> nodes)
        {
            var p = new StateDiagramPanel(title, nodes)
            {
                BackColor = ColPanel,
                Margin    = new Padding(4)
            };
            return p;
        }

        private Button MakeBtn(string text, int x, int y, Color back)
        {
            return new Button
            {
                Text      = text,
                Location  = new Point(x, y),
                Size      = new Size(110, 28),
                BackColor = back,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                Cursor    = Cursors.Hand
            };
        }

        private Label SectionLabel(string text, int x, int y)
        {
            return new Label
            {
                Text      = text,
                Location  = new Point(x, y),
                AutoSize  = true,
                Font      = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = ColGroupHdr
            };
        }

        private Label StateValueLabel(string text, int x, int y)
        {
            return new Label
            {
                Text      = text,
                Location  = new Point(x, y),
                Size      = new Size(240, 20),
                Font      = new Font("Segoe UI Semibold", 11f),
                ForeColor = Color.White
            };
        }

        private static Color CommColor(CommState s)
        {
            switch (s)
            {
                case CommState.Communicating: return Color.FromArgb(0, 200, 100);
                case CommState.Enabled:       return Color.FromArgb(230, 160, 0);
                default:                      return Color.FromArgb(140, 140, 160);
            }
        }
        private static Color CtrlColor(ControlState s)
        {
            switch (s)
            {
                case ControlState.OnLineLocal:   return Color.FromArgb(0, 190, 90);
                case ControlState.OnLineRemote:  return Color.FromArgb(0, 140, 220);
                case ControlState.AttemptOnLine: return Color.FromArgb(230, 160, 0);
                default:                         return Color.FromArgb(140, 140, 160);
            }
        }
        private static Color ProcColor(ProcessingState s)
        {
            switch (s)
            {
                case ProcessingState.Executing: return Color.FromArgb(0, 200, 100);
                case ProcessingState.Paused:    return Color.FromArgb(230, 160, 0);
                default:                        return Color.FromArgb(140, 140, 160);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            // Don't destroy — just hide
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                return;
            }
            _refreshTimer?.Stop();
            base.OnFormClosing(e);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  StateNode — data for a node in the diagram
    // ─────────────────────────────────────────────────────────────────────────
    internal class StateNode
    {
        public string Name    { get; }
        public int    X       { get; }
        public int    Y       { get; }
        public string Tooltip { get; }
        public StateNode(string name, int x, int y, string tooltip = "")
        { Name = name; X = x; Y = y; Tooltip = tooltip; }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  StateDiagramPanel — custom-drawn state diagram (owner-draw panel)
    // ─────────────────────────────────────────────────────────────────────────
    internal class StateDiagramPanel : Panel
    {
        public string           ActiveState { get; set; } = "";

        private readonly string           _title;
        private readonly List<StateNode>  _nodes;

        private static readonly Color ColNodeActive   = Color.FromArgb(0, 170, 80);
        private static readonly Color ColNodeInactive = Color.FromArgb(45, 58, 85);
        private static readonly Color ColNodeBorder   = Color.FromArgb(80, 110, 160);
        private static readonly Color ColNodeText     = Color.White;
        private static readonly Color ColArrow        = Color.FromArgb(90, 110, 150);
        private static readonly Color ColTitle        = Color.FromArgb(0, 130, 200);

        public StateDiagramPanel(string title, List<StateNode> nodes)
        {
            _title  = title;
            _nodes  = nodes;
            SetStyle(ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.UserPaint |
                     ControlStyles.OptimizedDoubleBuffer, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode      = SmoothingMode.AntiAlias;
            g.TextRenderingHint  = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            g.Clear(BackColor);

            // Title
            using (var f = new Font("Segoe UI", 8.5f, FontStyle.Bold))
                g.DrawString(_title, f, new SolidBrush(ColTitle), 8, 6);

            int nodeW = Width - 20;
            int nodeH = 32;

            // Draw arrows between nodes
            using (var pen = new Pen(ColArrow, 1.5f)
                { CustomEndCap = new AdjustableArrowCap(4, 4) })
            {
                for (int i = 0; i < _nodes.Count - 1; i++)
                {
                    int x = 10 + nodeW / 2;
                    int y1 = _nodes[i].Y + nodeH;
                    int y2 = _nodes[i + 1].Y;
                    g.DrawLine(pen, x, y1, x, y2);
                }
            }

            // Draw nodes
            for (int i = 0; i < _nodes.Count; i++)
            {
                var node    = _nodes[i];
                bool active = string.Equals(node.Name, ActiveState,
                                            StringComparison.OrdinalIgnoreCase);

                var rect = new Rectangle(10, node.Y, nodeW, nodeH);

                // Shadow
                using (var br = new SolidBrush(Color.FromArgb(30, 0, 0, 0)))
                    g.FillRoundedRectangle(br, rect.X + 2, rect.Y + 2, rect.Width, rect.Height, 6);

                // Fill
                Color fill = active ? ColNodeActive : ColNodeInactive;
                using (var br = new SolidBrush(fill))
                    g.FillRoundedRectangle(br, rect.X, rect.Y, rect.Width, rect.Height, 6);

                // Border
                Color border = active ? Color.FromArgb(0, 220, 120) : ColNodeBorder;
                float bw2    = active ? 2f : 1f;
                using (var pen = new Pen(border, bw2))
                    g.DrawRoundedRectangle(pen, rect.X, rect.Y, rect.Width, rect.Height, 6);

                // Active glow
                if (active)
                {
                    using (var glow = new Pen(Color.FromArgb(60, 0, 220, 120), 6))
                        g.DrawRoundedRectangle(glow, rect.X - 1, rect.Y - 1,
                            rect.Width + 2, rect.Height + 2, 7);
                }

                // Label
                using (var f = new Font("Segoe UI", active ? 9f : 8.5f,
                    active ? FontStyle.Bold : FontStyle.Regular))
                using (var sf = new StringFormat
                    { Alignment = StringAlignment.Center,
                      LineAlignment = StringAlignment.Center })
                    g.DrawString(node.Name, f, new SolidBrush(ColNodeText), rect, sf);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Graphics extension helpers — rounded rectangles
    // ─────────────────────────────────────────────────────────────────────────
    internal static class GraphicsEx
    {
        public static void FillRoundedRectangle(this Graphics g, Brush b,
            int x, int y, int w, int h, int r)
        {
            using (var path = RoundedPath(x, y, w, h, r))
                g.FillPath(b, path);
        }

        public static void DrawRoundedRectangle(this Graphics g, Pen p,
            int x, int y, int w, int h, int r)
        {
            using (var path = RoundedPath(x, y, w, h, r))
                g.DrawPath(p, path);
        }

        private static GraphicsPath RoundedPath(int x, int y, int w, int h, int r)
        {
            var path = new GraphicsPath();
            path.AddArc(x,         y,         r * 2, r * 2, 180, 90);
            path.AddArc(x + w - r*2, y,       r * 2, r * 2,  270, 90);
            path.AddArc(x + w - r*2, y + h - r*2, r*2, r*2,   0, 90);
            path.AddArc(x,         y + h - r*2, r*2, r*2,     90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
