namespace SecSimPro.Forms
{
    partial class ConnectionForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            // ── Declare controls ──────────────────────────────
            this.grpSaved             = new System.Windows.Forms.GroupBox();
            this.lblSavedProfiles     = new System.Windows.Forms.Label();
            this.cmbSavedProfiles     = new System.Windows.Forms.ComboBox();
            this.btnDeleteProfile     = new System.Windows.Forms.Button();

            this.grpConnection        = new System.Windows.Forms.GroupBox();
            this.lblIpAddress         = new System.Windows.Forms.Label();
            this.txtIpAddress         = new System.Windows.Forms.TextBox();
            this.lblPort              = new System.Windows.Forms.Label();
            this.numPort              = new System.Windows.Forms.NumericUpDown();
            this.lblDescription       = new System.Windows.Forms.Label();
            this.txtDescription       = new System.Windows.Forms.TextBox();
            this.lblProfileName       = new System.Windows.Forms.Label();
            this.txtProfileName       = new System.Windows.Forms.TextBox();

            this.grpHsms              = new System.Windows.Forms.GroupBox();
            this.lblSessionId         = new System.Windows.Forms.Label();
            this.numSessionId         = new System.Windows.Forms.NumericUpDown();
            this.lblSessionIdHint     = new System.Windows.Forms.Label();
            this.lblLinktestInterval  = new System.Windows.Forms.Label();
            this.numLinktestInterval  = new System.Windows.Forms.NumericUpDown();
            this.lblLinktestUnit      = new System.Windows.Forms.Label();

            this.grpGem               = new System.Windows.Forms.GroupBox();
            this.chkUseGem            = new System.Windows.Forms.CheckBox();
            this.chkSendDateTime      = new System.Windows.Forms.CheckBox();

            this.grpAdvanced          = new System.Windows.Forms.GroupBox();
            this.lblTimeout           = new System.Windows.Forms.Label();
            this.numTimeout           = new System.Windows.Forms.NumericUpDown();
            this.lblTimeoutUnit       = new System.Windows.Forms.Label();
            this.chkAutoReconnect     = new System.Windows.Forms.CheckBox();

            this.pnlButtons           = new System.Windows.Forms.Panel();
            this.btnConnect           = new System.Windows.Forms.Button();
            this.btnCancel            = new System.Windows.Forms.Button();

            // NumericUpDown init
            ((System.ComponentModel.ISupportInitialize)(this.numPort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSessionId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLinktestInterval)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTimeout)).BeginInit();

            this.grpSaved.SuspendLayout();
            this.grpConnection.SuspendLayout();
            this.grpHsms.SuspendLayout();
            this.grpGem.SuspendLayout();
            this.grpAdvanced.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            this.SuspendLayout();

            // ── Colours / font ────────────────────────────────
            var accent       = System.Drawing.Color.FromArgb(0, 100, 160);
            var labelGray    = System.Drawing.Color.FromArgb(70, 70, 70);
            var hintGray     = System.Drawing.Color.FromArgb(120, 120, 120);
            var groupFont    = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Bold);
            var normalFont   = new System.Drawing.Font("Segoe UI", 8.5f);
            var monoFont     = new System.Drawing.Font("Consolas", 9.5f);

            int lx = 12, cx = 135, w = 295, rw = 160, row = 28, y0 = 22;

            // ═══════════════════════════════════════════════
            //  grpSaved
            // ═══════════════════════════════════════════════
            this.grpSaved.Text      = "Saved Profiles";
            this.grpSaved.Font      = groupFont;
            this.grpSaved.ForeColor = accent;
            this.grpSaved.Location  = new System.Drawing.Point(10, 8);
            this.grpSaved.Size      = new System.Drawing.Size(w + lx + 18, 56);
            this.grpSaved.Controls.AddRange(new System.Windows.Forms.Control[]
                { this.lblSavedProfiles, this.cmbSavedProfiles, this.btnDeleteProfile });

            this.lblSavedProfiles.Text      = "Load Profile:";
            this.lblSavedProfiles.Font      = normalFont;
            this.lblSavedProfiles.ForeColor = labelGray;
            this.lblSavedProfiles.AutoSize  = true;
            this.lblSavedProfiles.Location  = new System.Drawing.Point(lx, 24);

            this.cmbSavedProfiles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSavedProfiles.Font          = normalFont;
            this.cmbSavedProfiles.Location      = new System.Drawing.Point(cx - 20, 21);
            this.cmbSavedProfiles.Size          = new System.Drawing.Size(210, 21);
            this.cmbSavedProfiles.SelectedIndexChanged += new System.EventHandler(this.cmbSavedProfiles_SelectedIndexChanged);

            this.btnDeleteProfile.Text     = "Delete";
            this.btnDeleteProfile.Font     = normalFont;
            this.btnDeleteProfile.Location = new System.Drawing.Point(cx + 195, 20);
            this.btnDeleteProfile.Size     = new System.Drawing.Size(60, 24);
            this.btnDeleteProfile.UseVisualStyleBackColor = true;
            this.btnDeleteProfile.Click += new System.EventHandler(this.btnDeleteProfile_Click);

            // ═══════════════════════════════════════════════
            //  grpConnection
            // ═══════════════════════════════════════════════
            this.grpConnection.Text      = "Connection";
            this.grpConnection.Font      = groupFont;
            this.grpConnection.ForeColor = accent;
            this.grpConnection.Location  = new System.Drawing.Point(10, 72);
            this.grpConnection.Size      = new System.Drawing.Size(w + lx + 18, 4 * row + 14);
            this.grpConnection.Controls.AddRange(new System.Windows.Forms.Control[]
            {
                this.lblIpAddress, this.txtIpAddress,
                this.lblPort, this.numPort,
                this.lblDescription, this.txtDescription,
                this.lblProfileName, this.txtProfileName
            });

            MakeLabel(this.lblIpAddress,   "IP Address *:", lx, y0,           labelGray, normalFont);
            MakeLabel(this.lblPort,        "Port *:",       lx, y0 + row,     labelGray, normalFont);
            MakeLabel(this.lblDescription, "Description:",  lx, y0 + row * 2, labelGray, normalFont);
            MakeLabel(this.lblProfileName, "Save as:",      lx, y0 + row * 3, labelGray, normalFont);

            this.txtIpAddress.Font     = monoFont;
            this.txtIpAddress.Location = new System.Drawing.Point(cx, y0 - 2);
            this.txtIpAddress.Size     = new System.Drawing.Size(rw, 21);
            this.txtIpAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIpAddress_KeyPress);

            this.numPort.Font    = monoFont;
            this.numPort.Location = new System.Drawing.Point(cx, y0 + row - 2);
            this.numPort.Size    = new System.Drawing.Size(90, 21);
            this.numPort.Minimum = 1; this.numPort.Maximum = 65535; this.numPort.Value = 5000;

            this.txtDescription.Font     = normalFont;
            this.txtDescription.Location = new System.Drawing.Point(cx, y0 + row * 2 - 2);
            this.txtDescription.Size     = new System.Drawing.Size(rw + 90, 21);

            this.txtProfileName.Font     = normalFont;
            this.txtProfileName.Location = new System.Drawing.Point(cx, y0 + row * 3 - 2);
            this.txtProfileName.Size     = new System.Drawing.Size(rw + 90, 21);

            // ═══════════════════════════════════════════════
            //  grpHsms
            // ═══════════════════════════════════════════════
            int top2 = 72 + 4 * row + 22;
            this.grpHsms.Text      = "HSMS Settings  (SEMI E37)";
            this.grpHsms.Font      = groupFont;
            this.grpHsms.ForeColor = accent;
            this.grpHsms.Location  = new System.Drawing.Point(10, top2);
            this.grpHsms.Size      = new System.Drawing.Size(w + lx + 18, 3 * row - 2);
            this.grpHsms.Controls.AddRange(new System.Windows.Forms.Control[]
            {
                this.lblSessionId, this.numSessionId, this.lblSessionIdHint,
                this.lblLinktestInterval, this.numLinktestInterval, this.lblLinktestUnit
            });

            MakeLabel(this.lblSessionId,        "Session ID:",       lx, y0,           labelGray, normalFont);
            MakeLabel(this.lblSessionIdHint,    "(Device ID 0–65535)", cx + 65, y0 + 2, hintGray,  new System.Drawing.Font("Segoe UI", 7.5f));
            MakeLabel(this.lblLinktestInterval, "Linktest Interval:", lx, y0 + row,    labelGray, normalFont);
            MakeLabel(this.lblLinktestUnit,     "seconds",    cx + 65, y0 + row + 2,   hintGray,  normalFont);

            this.numSessionId.Font    = monoFont;
            this.numSessionId.Location = new System.Drawing.Point(cx, y0 - 2);
            this.numSessionId.Size    = new System.Drawing.Size(60, 21);
            this.numSessionId.Minimum = 0; this.numSessionId.Maximum = 65535; this.numSessionId.Value = 0;

            this.numLinktestInterval.Font    = monoFont;
            this.numLinktestInterval.Location = new System.Drawing.Point(cx, y0 + row - 2);
            this.numLinktestInterval.Size    = new System.Drawing.Size(60, 21);
            this.numLinktestInterval.Minimum = 5; this.numLinktestInterval.Maximum = 120; this.numLinktestInterval.Value = 15;

            // ═══════════════════════════════════════════════
            //  grpGem
            // ═══════════════════════════════════════════════
            int top3 = top2 + 3 * row - 2 + 10;
            this.grpGem.Text      = "GEM Settings  (SEMI E30)";
            this.grpGem.Font      = groupFont;
            this.grpGem.ForeColor = accent;
            this.grpGem.Location  = new System.Drawing.Point(10, top3);
            this.grpGem.Size      = new System.Drawing.Size(w + lx + 18, 2 * row + 4);
            this.grpGem.Controls.AddRange(new System.Windows.Forms.Control[]
                { this.chkUseGem, this.chkSendDateTime });

            this.chkUseGem.Text     = "Send S1F13 Establish Communications after HSMS Select";
            this.chkUseGem.Font     = normalFont;
            this.chkUseGem.Location = new System.Drawing.Point(lx, y0 - 2);
            this.chkUseGem.AutoSize = true;
            this.chkUseGem.Checked  = true;
            this.chkUseGem.CheckedChanged += new System.EventHandler(this.chkUseGem_CheckedChanged);

            this.chkSendDateTime.Text     = "Send S2F17 Date/Time Set after GEM Online";
            this.chkSendDateTime.Font     = normalFont;
            this.chkSendDateTime.Location = new System.Drawing.Point(lx, y0 + row - 4);
            this.chkSendDateTime.AutoSize = true;
            this.chkSendDateTime.Checked  = false;

            // ═══════════════════════════════════════════════
            //  grpAdvanced
            // ═══════════════════════════════════════════════
            int top4 = top3 + 2 * row + 18;
            this.grpAdvanced.Text      = "Advanced";
            this.grpAdvanced.Font      = groupFont;
            this.grpAdvanced.ForeColor = accent;
            this.grpAdvanced.Location  = new System.Drawing.Point(10, top4);
            this.grpAdvanced.Size      = new System.Drawing.Size(w + lx + 18, row + 24);
            this.grpAdvanced.Controls.AddRange(new System.Windows.Forms.Control[]
                { this.lblTimeout, this.numTimeout, this.lblTimeoutUnit, this.chkAutoReconnect });

            MakeLabel(this.lblTimeout,     "TCP Timeout:", lx, y0,     labelGray, normalFont);
            MakeLabel(this.lblTimeoutUnit, "seconds",      cx + 65, y0 + 2, hintGray, normalFont);

            this.numTimeout.Font    = monoFont;
            this.numTimeout.Location = new System.Drawing.Point(cx, y0 - 2);
            this.numTimeout.Size    = new System.Drawing.Size(60, 21);
            this.numTimeout.Minimum = 1; this.numTimeout.Maximum = 120; this.numTimeout.Value = 10;

            this.chkAutoReconnect.Text     = "Auto-reconnect on loss";
            this.chkAutoReconnect.Font     = normalFont;
            this.chkAutoReconnect.Location = new System.Drawing.Point(cx + 130, y0 - 2);
            this.chkAutoReconnect.AutoSize = true;

            // ═══════════════════════════════════════════════
            //  pnlButtons
            // ═══════════════════════════════════════════════
            this.pnlButtons.BackColor = System.Drawing.Color.FromArgb(238, 242, 248);
            this.pnlButtons.Dock      = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtons.Height    = 50;
            this.pnlButtons.Controls.AddRange(new System.Windows.Forms.Control[]
                { this.btnConnect, this.btnCancel });

            this.btnConnect.BackColor  = System.Drawing.Color.FromArgb(0, 110, 170);
            this.btnConnect.ForeColor  = System.Drawing.Color.White;
            this.btnConnect.FlatStyle  = System.Windows.Forms.FlatStyle.Flat;
            this.btnConnect.FlatAppearance.BorderSize = 0;
            this.btnConnect.Font       = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.btnConnect.Text       = "Connect";
            this.btnConnect.Size       = new System.Drawing.Size(105, 32);
            this.btnConnect.Location   = new System.Drawing.Point(220, 9);
            this.btnConnect.Cursor     = System.Windows.Forms.Cursors.Hand;
            this.btnConnect.Click     += new System.EventHandler(this.btnConnect_Click);

            this.btnCancel.FlatStyle   = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font        = normalFont;
            this.btnCancel.Text        = "Cancel";
            this.btnCancel.Size        = new System.Drawing.Size(82, 32);
            this.btnCancel.Location    = new System.Drawing.Point(334, 9);
            this.btnCancel.Click      += new System.EventHandler(this.btnCancel_Click);

            // ═══════════════════════════════════════════════
            //  Form
            // ═══════════════════════════════════════════════
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            int formH = top4 + row + 26 + 50 + 16;
            this.ClientSize          = new System.Drawing.Size(w + lx + 38, formH);
            this.FormBorderStyle     = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox         = false;
            this.MinimizeBox         = false;
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text                = "Connect to Equipment";
            this.Font                = normalFont;
            this.Controls.AddRange(new System.Windows.Forms.Control[]
            {
                this.grpSaved, this.grpConnection,
                this.grpHsms, this.grpGem,
                this.grpAdvanced, this.pnlButtons
            });

            ((System.ComponentModel.ISupportInitialize)(this.numPort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSessionId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLinktestInterval)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTimeout)).EndInit();

            this.grpSaved.ResumeLayout(false); this.grpSaved.PerformLayout();
            this.grpConnection.ResumeLayout(false); this.grpConnection.PerformLayout();
            this.grpHsms.ResumeLayout(false); this.grpHsms.PerformLayout();
            this.grpGem.ResumeLayout(false); this.grpGem.PerformLayout();
            this.grpAdvanced.ResumeLayout(false); this.grpAdvanced.PerformLayout();
            this.pnlButtons.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private void MakeLabel(System.Windows.Forms.Label lbl, string text,
                               int x, int y,
                               System.Drawing.Color color,
                               System.Drawing.Font font)
        {
            lbl.Text      = text;
            lbl.Font      = font;
            lbl.ForeColor = color;
            lbl.AutoSize  = true;
            lbl.Location  = new System.Drawing.Point(x, y + 3);
        }

        #endregion

        private System.Windows.Forms.GroupBox         grpSaved;
        private System.Windows.Forms.Label            lblSavedProfiles;
        private System.Windows.Forms.ComboBox         cmbSavedProfiles;
        private System.Windows.Forms.Button           btnDeleteProfile;
        private System.Windows.Forms.GroupBox         grpConnection;
        private System.Windows.Forms.Label            lblIpAddress;
        private System.Windows.Forms.TextBox          txtIpAddress;
        private System.Windows.Forms.Label            lblPort;
        private System.Windows.Forms.NumericUpDown    numPort;
        private System.Windows.Forms.Label            lblDescription;
        private System.Windows.Forms.TextBox          txtDescription;
        private System.Windows.Forms.Label            lblProfileName;
        private System.Windows.Forms.TextBox          txtProfileName;
        private System.Windows.Forms.GroupBox         grpHsms;
        private System.Windows.Forms.Label            lblSessionId;
        private System.Windows.Forms.NumericUpDown    numSessionId;
        private System.Windows.Forms.Label            lblSessionIdHint;
        private System.Windows.Forms.Label            lblLinktestInterval;
        private System.Windows.Forms.NumericUpDown    numLinktestInterval;
        private System.Windows.Forms.Label            lblLinktestUnit;
        private System.Windows.Forms.GroupBox         grpGem;
        private System.Windows.Forms.CheckBox         chkUseGem;
        private System.Windows.Forms.CheckBox         chkSendDateTime;
        private System.Windows.Forms.GroupBox         grpAdvanced;
        private System.Windows.Forms.Label            lblTimeout;
        private System.Windows.Forms.NumericUpDown    numTimeout;
        private System.Windows.Forms.Label            lblTimeoutUnit;
        private System.Windows.Forms.CheckBox         chkAutoReconnect;
        private System.Windows.Forms.Panel            pnlButtons;
        private System.Windows.Forms.Button           btnConnect;
        private System.Windows.Forms.Button           btnCancel;
    }
}
