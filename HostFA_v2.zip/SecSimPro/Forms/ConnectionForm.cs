using System;
using System.Net;
using System.Windows.Forms;
using SecSimPro.Models;

namespace SecSimPro.Forms
{
    public partial class ConnectionForm : Form
    {
        public ConnectionProfile ResultProfile { get; private set; }

        private ConnectionProfileList _profileList;

        public ConnectionForm(ConnectionProfile existingProfile = null)
        {
            InitializeComponent();
            _profileList = ConnectionProfileList.Load();
            LoadProfiles();

            if (existingProfile != null)
            {
                PopulateFromProfile(existingProfile);
                this.Text = "Edit Connection";
                btnConnect.Text = "Update & Connect";
            }
        }

        private void LoadProfiles()
        {
            cmbSavedProfiles.Items.Clear();
            cmbSavedProfiles.Items.Add("-- New Connection --");
            foreach (var p in _profileList.Profiles)
                cmbSavedProfiles.Items.Add(p.ProfileName);
            cmbSavedProfiles.SelectedIndex = 0;
        }

        private void PopulateFromProfile(ConnectionProfile p)
        {
            txtProfileName.Text      = p.ProfileName;
            txtIpAddress.Text        = p.IpAddress;
            numPort.Value            = p.Port;
            txtDescription.Text      = p.Description;
            numTimeout.Value         = p.TimeoutSeconds;
            chkAutoReconnect.Checked = p.AutoReconnect;

            // HSMS
            numSessionId.Value         = p.SessionId;
            numLinktestInterval.Value  = Math.Max(numLinktestInterval.Minimum,
                                         Math.Min(numLinktestInterval.Maximum, p.LinktestIntervalSec));

            // GEM
            chkUseGem.Checked              = p.UseGem;
            chkSendDateTime.Checked        = p.SendDateTimeOnConnect;
            UpdateGemControls();
        }

        private void cmbSavedProfiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = cmbSavedProfiles.SelectedIndex;
            if (idx <= 0) return;
            PopulateFromProfile(_profileList.Profiles[idx - 1]);
        }

        private void chkUseGem_CheckedChanged(object sender, EventArgs e) => UpdateGemControls();

        private void UpdateGemControls()
        {
            chkSendDateTime.Enabled = chkUseGem.Checked;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;
            ResultProfile = BuildProfile();

            // Save profile if name provided
            if (!string.IsNullOrWhiteSpace(txtProfileName.Text))
            {
                var existing = _profileList.Profiles.Find(
                    p => p.ProfileName.Equals(txtProfileName.Text.Trim(), StringComparison.OrdinalIgnoreCase));
                if (existing != null) _profileList.Profiles.Remove(existing);
                _profileList.Profiles.Add(ResultProfile);
                _profileList.Save();
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void btnDeleteProfile_Click(object sender, EventArgs e)
        {
            int idx = cmbSavedProfiles.SelectedIndex;
            if (idx <= 0)
            {
                MessageBox.Show("Please select a saved profile to delete.",
                    "No Profile Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var profile = _profileList.Profiles[idx - 1];
            if (MessageBox.Show($"Delete profile '{profile.ProfileName}'?", "Confirm Delete",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _profileList.Profiles.RemoveAt(idx - 1);
                _profileList.Save();
                LoadProfiles();
                ClearFields();
            }
        }

        private void ClearFields()
        {
            txtProfileName.Clear();
            txtIpAddress.Clear();
            numPort.Value           = 5000;
            txtDescription.Clear();
            numTimeout.Value        = 10;
            chkAutoReconnect.Checked = false;
            numSessionId.Value      = 0;
            numLinktestInterval.Value = 15;
            chkUseGem.Checked       = true;
            chkSendDateTime.Checked = false;
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtIpAddress.Text))
            { ShowError("IP Address is required.", txtIpAddress); return false; }

            if (!IsValidIpOrHost(txtIpAddress.Text.Trim()))
            { ShowError("Enter a valid IP address or hostname.", txtIpAddress); return false; }

            if (numPort.Value < 1 || numPort.Value > 65535)
            { ShowError("Port must be 1–65535.", numPort); return false; }

            if (numSessionId.Value < 0 || numSessionId.Value > 65535)
            { ShowError("Session ID must be 0–65535.", numSessionId); return false; }

            return true;
        }

        private bool IsValidIpOrHost(string v)
        {
            IPAddress a;
            if (IPAddress.TryParse(v, out a)) return true;
            return v.Length > 0 && v.Length <= 255;
        }

        private void ShowError(string msg, Control ctrl)
        {
            MessageBox.Show(msg, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            ctrl.Focus();
        }

        private ConnectionProfile BuildProfile()
        {
            return new ConnectionProfile
            {
                ProfileName          = string.IsNullOrWhiteSpace(txtProfileName.Text)
                                        ? $"{txtIpAddress.Text.Trim()}:{(int)numPort.Value}"
                                        : txtProfileName.Text.Trim(),
                IpAddress            = txtIpAddress.Text.Trim(),
                Port                 = (int)numPort.Value,
                Description          = txtDescription.Text.Trim(),
                TimeoutSeconds       = (int)numTimeout.Value,
                AutoReconnect        = chkAutoReconnect.Checked,
                SessionId            = (ushort)numSessionId.Value,
                LinktestIntervalSec  = (int)numLinktestInterval.Value,
                UseGem               = chkUseGem.Checked,
                SendDateTimeOnConnect = chkSendDateTime.Checked
            };
        }

        private void txtIpAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetterOrDigit(e.KeyChar)
                && e.KeyChar != '.' && e.KeyChar != '-')
                e.Handled = true;
        }
    }
}
