using System;
using System.Text;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  SECS-II item format codes  (SEMI E5)
    // ─────────────────────────────────────────────────────────────────────────
    public enum SecsFormat : byte
    {
        List    = 0x00,
        Binary  = 0x08,
        Boolean = 0x09,
        ASCII   = 0x10,
        JIS8    = 0x11,
        I8      = 0x60,
        I1      = 0x62,
        I2      = 0x64,
        I4      = 0x68,
        F8      = 0x80,
        F4      = 0x90,
        U8      = 0xA0,
        U1      = 0xA4,
        U2      = 0xA8,
        U4      = 0xB0
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SecsIIMessage — builds SECS-II encoded byte bodies for common GEM msgs
    // ─────────────────────────────────────────────────────────────────────────
    public static class SecsIIMessage
    {
        // ── S1F1 — Are You There (header-only, no body) ───────
        public static byte[] S1F1_AreYouThere() => new byte[0];

        // ── S1F13 — Establish Communications Request (ECR) ───
        // Body: <L 0>   (empty list — host model)
        public static byte[] S1F13_EstablishCommsReq()
        {
            // L[0]  = empty list
            return new byte[] { EncodeFmtLen(SecsFormat.List, 0) };
        }

        // ── S2F17 — Date and Time Request ────────────────────
        // Body: empty (header-only request)
        public static byte[] S2F17_DateTimeReq() => new byte[0];

        // ── S2F17 — Date and Time Set ────────────────────────
        // Body: <A[16]> yyyyMMddHHmmsscc   (cc = centiseconds)
        public static byte[] S2F17_DateTimeSet(DateTime dt)
        {
            string ts = dt.ToString("yyyyMMddHHmmss") + (dt.Millisecond / 10).ToString("D2");
            return EncodeASCII(ts);
        }

        // ── S1F15 — Request OFF-LINE (GEM) ───────────────────
        public static byte[] S1F15_RequestOffline() => new byte[0];

        // ── S1F17 — Request ON-LINE (GEM) ────────────────────
        public static byte[] S1F17_RequestOnline() => new byte[0];

        // ─────────────────────────────────────────────────────
        //  Parse helpers (for inbound messages)
        // ─────────────────────────────────────────────────────

        /// <summary>
        /// Try to extract a single ASCII item from a SECS-II body.
        /// Returns null if not an ASCII item.
        /// </summary>
        public static string DecodeASCIIItem(byte[] body, int offset = 0)
        {
            if (body == null || body.Length <= offset) return null;
            byte fmt = (byte)(body[offset] & 0xFC);
            if (fmt != (byte)SecsFormat.ASCII) return null;

            int lenBytes = body[offset] & 0x03;
            if (lenBytes == 0) return string.Empty;

            int len = 0;
            for (int i = 1; i <= lenBytes && offset + i < body.Length; i++)
                len = (len << 8) | body[offset + i];

            int dataStart = offset + 1 + lenBytes;
            if (dataStart + len > body.Length) return null;

            return Encoding.ASCII.GetString(body, dataStart, len);
        }

        /// <summary>
        /// Return the S1F13 (Establish Communications) response COMMACK code.
        /// 0 = accepted, 1..n = rejected.
        /// </summary>
        public static byte? ParseS1F14CommAck(byte[] body)
        {
            // S1F14 body: <L 2 <B COMMACK> <L n [MDLN SOFTREV]>>
            // We just want byte at index 2 (after L header and B header)
            if (body == null || body.Length < 3) return null;
            // body[0] = L fmt+len, body[1] = B fmt+1, body[2] = COMMACK value
            if ((body[0] & 0xFC) == (byte)SecsFormat.List &&
                (body[1] & 0xFC) == (byte)SecsFormat.Binary)
                return body[2];
            return null;
        }

        // ─────────────────────────────────────────────────────
        //  Encoding primitives
        // ─────────────────────────────────────────────────────

        private static byte EncodeFmtLen(SecsFormat fmt, int len)
        {
            // For len 0..63 : 1-byte length (lenBytes=1 in lower 2 bits of format byte)
            // We always use 1-byte length for simplicity here
            return (byte)((byte)fmt | 0x01 | (len << 0));
            // NOTE: proper encoding needs separate length bytes; use helper below
        }

        public static byte[] EncodeItem(SecsFormat fmt, byte[] data)
        {
            int len = data?.Length ?? 0;

            // Determine number of length bytes needed (1, 2, or 3)
            byte lenBytes;
            if      (len <= 0xFF)   lenBytes = 1;
            else if (len <= 0xFFFF) lenBytes = 2;
            else                     lenBytes = 3;

            byte[] result = new byte[1 + lenBytes + len];
            result[0] = (byte)((byte)fmt | lenBytes);

            for (int i = lenBytes; i >= 1; i--)
            {
                result[i] = (byte)(len & 0xFF);
                len >>= 8;
            }

            if (data != null && data.Length > 0)
                Array.Copy(data, 0, result, 1 + lenBytes, data.Length);

            return result;
        }

        public static byte[] EncodeASCII(string s)
        {
            byte[] raw = Encoding.ASCII.GetBytes(s ?? string.Empty);
            return EncodeItem(SecsFormat.ASCII, raw);
        }

        public static byte[] EncodeU4(uint value)
        {
            return EncodeItem(SecsFormat.U4, new byte[]
            {
                (byte)(value >> 24), (byte)(value >> 16),
                (byte)(value >> 8),  (byte)(value)
            });
        }

        public static byte[] EncodeList(params byte[][] items)
        {
            int totalLen = 0;
            foreach (var item in items) totalLen += item?.Length ?? 0;

            byte[] listHeader = new byte[] { (byte)((byte)SecsFormat.List | 0x01), (byte)items.Length };
            byte[] result = new byte[listHeader.Length + totalLen];
            Array.Copy(listHeader, result, listHeader.Length);

            int pos = listHeader.Length;
            foreach (var item in items)
            {
                if (item != null)
                {
                    Array.Copy(item, 0, result, pos, item.Length);
                    pos += item.Length;
                }
            }
            return result;
        }
    }
}
