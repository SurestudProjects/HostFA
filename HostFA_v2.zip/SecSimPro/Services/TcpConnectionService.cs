using System;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using SecSimPro.Models;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  TcpConnectionService
    //
    //  Implements the full HSMS (SEMI E37) + GEM (SEMI E30) connection stack:
    //
    //  Stage 1 — TCP Connect
    //    Connect TCP socket to equipment IP:Port.
    //
    //  Stage 2 — HSMS Select  (SEMI E37 §8.5)
    //    Send Select.req → wait for Select.rsp within T6.
    //    On success → enter SELECTED state; start receive loop + linktest timer.
    //
    //  Stage 3 — GEM Establish Communications  (SEMI E30 §6.3 / S1F13)
    //    Send S1F13 → wait for S1F14 response within T3.
    //    COMMACK=0 → GEM Online.  Any other → log warning (still SELECTED).
    //
    //  Keep-alive:
    //    Linktest.req every T7LinkTestInterval seconds; expect Linktest.rsp
    //    within T6.  Two consecutive failures → reconnect (if auto-reconnect).
    //
    //  Disconnect:
    //    Send Separate.req → close socket.
    // ─────────────────────────────────────────────────────────────────────────
    public class TcpConnectionService : IDisposable
    {
        // ── HSMS timers (seconds, SEMI E37 defaults) ─────────
        private const int T3_ReplyTimeout    = 45;  // max wait for primary-msg reply
        private const int T6_ControlTimeout  = 5;   // max wait for control-msg reply (Select/Linktest)
        private const int T7_NotSelectedTimeout = 10; // max time in TCP-connected-not-selected
        private const int T8_NetworkTimeout  = 5;   // per-read network timeout

        // ── Configurable ─────────────────────────────────────
        private int _linktestIntervalSec = 15;       // send Linktest.req every N seconds

        // ── State ─────────────────────────────────────────────
        private TcpClient     _tcpClient;
        private NetworkStream _stream;
        private CancellationTokenSource _cts;
        private Thread        _receiveThread;
        private Thread        _linktestThread;

        private uint _systemCounter = 1;    // monotonic transaction-ID counter
        private object _writeLock = new object();

        // Latches for synchronous waits across threads
        private ManualResetEventSlim _selectLatch  = new ManualResetEventSlim(false);
        private ManualResetEventSlim _s1f14Latch   = new ManualResetEventSlim(false);
        private ManualResetEventSlim _linktestLatch = new ManualResetEventSlim(false);

        private HsmsSelectStatus _selectStatus;
        private byte?            _commAck;
        private int              _linktestFailures;
        private bool             _disposed;

        // ── Public API ────────────────────────────────────────
        public ConnectionStatus     CurrentStatus     { get; private set; } = ConnectionStatus.Disconnected;
        public EquipmentConnection  CurrentConnection { get; private set; }
        public bool IsConnected => CurrentStatus == ConnectionStatus.Selected
                                || CurrentStatus == ConnectionStatus.GemOnline;

        public event EventHandler<ConnectionEventArgs> ConnectionStatusChanged;
        public event EventHandler<ConnectionEventArgs> LogMessage;

        // ─────────────────────────────────────────────────────
        //  Public: Connect
        // ─────────────────────────────────────────────────────
        public void Connect(ConnectionProfile profile)
        {
            if (CurrentStatus != ConnectionStatus.Disconnected &&
                CurrentStatus != ConnectionStatus.Error)
            {
                Log(LogSeverity.Warning, "Already connected or connecting. Disconnect first.");
                return;
            }

            _linktestIntervalSec = profile.LinktestIntervalSec > 0
                ? profile.LinktestIntervalSec : 15;

            CurrentConnection = new EquipmentConnection
            {
                IpAddress   = profile.IpAddress,
                Port        = profile.Port,
                Description = profile.Description,
                SessionId   = profile.SessionId,
                Status      = ConnectionStatus.Connecting
            };

            ChangeStatus(ConnectionStatus.Connecting,
                $"Connecting to {profile.IpAddress}:{profile.Port}...",
                LogSeverity.Info, profile.IpAddress, profile.Port);

            Task.Run(() => DoConnect(profile));
        }

        // ─────────────────────────────────────────────────────
        //  Stage 1 — TCP Connect
        // ─────────────────────────────────────────────────────
        private void DoConnect(ConnectionProfile profile)
        {
            try
            {
                _tcpClient = new TcpClient();
                _tcpClient.NoDelay = true;    // disable Nagle — critical for HSMS latency

                var connectTask = _tcpClient.ConnectAsync(profile.IpAddress, profile.Port);
                if (!connectTask.Wait(TimeSpan.FromSeconds(profile.TimeoutSeconds)))
                {
                    Fail($"TCP connect timed out after {profile.TimeoutSeconds}s.", profile);
                    return;
                }

                if (!_tcpClient.Connected)
                {
                    Fail("TCP connect failed — host refused connection.", profile);
                    return;
                }

                _stream = _tcpClient.GetStream();
                _stream.ReadTimeout  = T8_NetworkTimeout * 1000;
                _stream.WriteTimeout = T8_NetworkTimeout * 1000;

                Log(LogSeverity.Info, $"TCP connected to {profile.IpAddress}:{profile.Port}");
                ChangeStatus(ConnectionStatus.TcpConnected,
                    $"TCP connected. Sending HSMS Select.req (Session 0x{profile.SessionId:X4})...",
                    LogSeverity.Hsms, profile.IpAddress, profile.Port);

                _cts = new CancellationTokenSource();
                StartReceiveLoop(_cts.Token);

                DoHsmsSelect(profile);
            }
            catch (SocketException ex)
            {
                Fail($"Socket error: {SocketMsg(ex.SocketErrorCode)}", profile);
            }
            catch (Exception ex)
            {
                Fail($"Connect error: {ex.Message}", profile);
            }
        }

        // ─────────────────────────────────────────────────────
        //  Stage 2 — HSMS Select
        // ─────────────────────────────────────────────────────
        private void DoHsmsSelect(ConnectionProfile profile)
        {
            try
            {
                _selectLatch.Reset();
                uint sysBytes = NextSysBytes();
                var req = HsmsMessage.BuildSelectReq(profile.SessionId, sysBytes);

                Log(LogSeverity.Hsms, $"TX → {req}");
                SendRaw(req.ToBytes());

                // Wait up to T7 for Select.rsp (receive loop will signal latch)
                bool rspReceived = _selectLatch.Wait(TimeSpan.FromSeconds(T7_NotSelectedTimeout));

                if (!rspReceived)
                {
                    Fail($"HSMS Select.rsp not received within T7={T7_NotSelectedTimeout}s. " +
                         "Equipment did not respond. Check Session ID.", profile);
                    return;
                }

                if (_selectStatus != HsmsSelectStatus.Success)
                {
                    Fail($"HSMS Select rejected by equipment — status: {_selectStatus} ({(byte)_selectStatus}). " +
                         "Verify Session ID matches equipment configuration.", profile);
                    return;
                }

                CurrentConnection.Status    = ConnectionStatus.Selected;
                CurrentConnection.SessionId = profile.SessionId;

                ChangeStatus(ConnectionStatus.Selected,
                    $"HSMS Selected (Session 0x{profile.SessionId:X4}). Session active.",
                    LogSeverity.Hsms, profile.IpAddress, profile.Port);

                StartLinktestTimer(_cts.Token);

                // Stage 3 — GEM only if enabled
                if (profile.UseGem)
                    DoGemEstablishComms(profile);
                else
                    FinalizeConnected(profile);
            }
            catch (Exception ex)
            {
                Fail($"HSMS Select error: {ex.Message}", profile);
            }
        }

        // ─────────────────────────────────────────────────────
        //  Stage 3 — GEM Establish Communications (S1F13/S1F14)
        // ─────────────────────────────────────────────────────
        private void DoGemEstablishComms(ConnectionProfile profile)
        {
            try
            {
                Log(LogSeverity.Gem, "GEM: Sending S1F13 Establish Communications Request...");

                _s1f14Latch.Reset();
                _commAck = null;
                uint sysBytes = NextSysBytes();
                var body = SecsIIMessage.S1F13_EstablishCommsReq();
                var msg  = HsmsMessage.BuildDataMessage(profile.SessionId, 1, 13, true, sysBytes, body);

                Log(LogSeverity.Gem, $"TX → {msg}");
                SendRaw(msg.ToBytes());

                bool rspReceived = _s1f14Latch.Wait(TimeSpan.FromSeconds(T3_ReplyTimeout));

                if (!rspReceived)
                {
                    Log(LogSeverity.Warning,
                        $"GEM: S1F14 not received within T3={T3_ReplyTimeout}s. " +
                        "Remaining in SELECTED state. Equipment may not support GEM S1F13.");
                    FinalizeConnected(profile);
                    return;
                }

                if (_commAck.HasValue && _commAck.Value == 0)
                {
                    CurrentConnection.Status = ConnectionStatus.GemOnline;
                    ChangeStatus(ConnectionStatus.GemOnline,
                        "GEM Online — S1F14 COMMACK=0 (Accepted). Equipment communications established.",
                        LogSeverity.Gem, profile.IpAddress, profile.Port);
                }
                else
                {
                    byte ack = _commAck ?? 0xFF;
                    Log(LogSeverity.Warning,
                        $"GEM: S1F14 COMMACK={ack} — equipment not ready for GEM comms. " +
                        "Remaining in SELECTED state.");
                    FinalizeConnected(profile);
                }
            }
            catch (Exception ex)
            {
                Log(LogSeverity.Warning, $"GEM establish comms error: {ex.Message}. Staying SELECTED.");
                FinalizeConnected(profile);
            }
        }

        private void FinalizeConnected(ConnectionProfile profile)
        {
            // If GEM was skipped or failed, mark as Selected (still usable)
            if (CurrentStatus == ConnectionStatus.TcpConnected ||
                CurrentStatus == ConnectionStatus.Selected)
            {
                ChangeStatus(ConnectionStatus.Selected,
                    $"Connected and HSMS Selected. Ready for communication.",
                    LogSeverity.Success, profile.IpAddress, profile.Port);
            }
            CurrentConnection.ConnectedAt = DateTime.Now;
        }

        // ─────────────────────────────────────────────────────
        //  Receive Loop — runs on dedicated thread
        // ─────────────────────────────────────────────────────
        private void StartReceiveLoop(CancellationToken token)
        {
            _receiveThread = new Thread(() =>
            {
                Log(LogSeverity.Info, "Receive thread started.");
                try
                {
                    while (!token.IsCancellationRequested && _stream != null)
                    {
                        // Read 4-byte length prefix
                        byte[] lenBuf = ReadExact(4, token);
                        if (lenBuf == null) break;

                        uint msgLen = (uint)((lenBuf[0] << 24) | (lenBuf[1] << 16)
                                           | (lenBuf[2] << 8)  |  lenBuf[3]);

                        if (msgLen < HsmsMessage.HeaderLength || msgLen > 1024 * 1024)
                        {
                            Log(LogSeverity.Error, $"RX: Invalid message length {msgLen}. Closing.");
                            break;
                        }

                        // Read header (10 bytes) + data
                        byte[] header = ReadExact(HsmsMessage.HeaderLength, token);
                        if (header == null) break;

                        int dataLen = (int)msgLen - HsmsMessage.HeaderLength;
                        byte[] data = dataLen > 0 ? ReadExact(dataLen, token) : new byte[0];
                        if (dataLen > 0 && data == null) break;

                        var msg = HsmsMessage.FromHeader(header, data);
                        ProcessIncoming(msg);
                    }
                }
                catch (OperationCanceledException) { /* normal shutdown */ }
                catch (IOException)                { /* socket closed */   }
                catch (Exception ex)
                {
                    if (!token.IsCancellationRequested)
                        Log(LogSeverity.Error, $"Receive error: {ex.Message}");
                }
                finally
                {
                    if (!token.IsCancellationRequested)
                    {
                        Log(LogSeverity.Warning, "Receive loop ended — connection lost.");
                        HandleUnexpectedDisconnect();
                    }
                    Log(LogSeverity.Info, "Receive thread exiting.");
                }
            })
            { IsBackground = true, Name = "HSMS-Receive" };

            _receiveThread.Start();
        }

        private void ProcessIncoming(HsmsMessage msg)
        {
            Log(LogSeverity.Hsms, $"RX ← {msg}");

            if (msg.IsControlMessage)
            {
                switch (msg.SType)
                {
                    case HsmsSType.SelectRsp:
                        _selectStatus = msg.SelectStatus;
                        _selectLatch.Set();
                        break;

                    case HsmsSType.LinktestReq:
                        // Echo back a Linktest.rsp with same system bytes
                        var rsp = HsmsMessage.BuildLinktestRsp(msg.SystemBytes);
                        Log(LogSeverity.Hsms, $"TX → {rsp}");
                        SendRaw(rsp.ToBytes());
                        break;

                    case HsmsSType.LinktestRsp:
                        _linktestFailures = 0;
                        _linktestLatch.Set();
                        break;

                    case HsmsSType.SeparateReq:
                        Log(LogSeverity.Warning, "Equipment sent Separate.req — it is closing the session.");
                        HandleUnexpectedDisconnect();
                        break;

                    case HsmsSType.SelectReq:
                        // Equipment is acting as active — send SelectRsp accepted
                        var srsp = HsmsMessage.BuildSelectRsp(msg.SessionId, msg.SystemBytes, HsmsSelectStatus.Success);
                        Log(LogSeverity.Hsms, $"TX → {srsp} (responding to equipment Select.req)");
                        SendRaw(srsp.ToBytes());
                        break;

                    default:
                        Log(LogSeverity.Hsms, $"Unhandled control SType: {msg.SType}");
                        break;
                }
            }
            else // Data (SECS-II) message
            {
                HandleDataMessage(msg);
            }
        }

        private void HandleDataMessage(HsmsMessage msg)
        {
            // S1F14 — Establish Communications Response (GEM)
            if (msg.Stream == 1 && msg.Function == 14)
            {
                _commAck = SecsIIMessage.ParseS1F14CommAck(msg.Data);
                Log(LogSeverity.Gem,
                    $"GEM: S1F14 received — COMMACK={(_commAck.HasValue ? _commAck.Value.ToString() : "?")}");
                _s1f14Latch.Set();
                return;
            }

            // S1F2 — On-Line Data (reply to S1F1 AYT)
            if (msg.Stream == 1 && msg.Function == 2)
            {
                Log(LogSeverity.Gem, "GEM: S1F2 (On-Line Data) received — equipment is online.");
                return;
            }

            // S1F1 — Are You There (equipment polling us)
            if (msg.Stream == 1 && msg.Function == 1)
            {
                // Reply S1F2 with empty body
                var reply = HsmsMessage.BuildDataMessage(
                    CurrentConnection.SessionId, 1, 2, false, msg.SystemBytes, new byte[0]);
                Log(LogSeverity.Gem, $"TX → {reply} (S1F2 reply to equipment S1F1)");
                SendRaw(reply.ToBytes());
                return;
            }

            // S9 — SECS-II error messages
            if (msg.Stream == 9)
            {
                Log(LogSeverity.Warning,
                    $"SECS-II S9F{msg.Function} received — message error from equipment.");
                return;
            }

            Log(LogSeverity.Info,
                $"Data message S{msg.Stream}F{msg.Function} received (not handled yet).");
        }

        // ─────────────────────────────────────────────────────
        //  Linktest Timer
        // ─────────────────────────────────────────────────────
        private void StartLinktestTimer(CancellationToken token)
        {
            _linktestThread = new Thread(() =>
            {
                Log(LogSeverity.Hsms, $"Linktest started (interval={_linktestIntervalSec}s, timeout=T6={T6_ControlTimeout}s).");
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        // Wait for interval
                        for (int i = 0; i < _linktestIntervalSec * 10 && !token.IsCancellationRequested; i++)
                            Thread.Sleep(100);

                        if (token.IsCancellationRequested) break;

                        _linktestLatch.Reset();
                        var req = HsmsMessage.BuildLinktestReq(NextSysBytes());
                        Log(LogSeverity.Hsms, $"TX → {req}");
                        SendRaw(req.ToBytes());

                        bool ok = _linktestLatch.Wait(TimeSpan.FromSeconds(T6_ControlTimeout));
                        if (!ok)
                        {
                            _linktestFailures++;
                            Log(LogSeverity.Warning,
                                $"Linktest.rsp not received within T6={T6_ControlTimeout}s " +
                                $"(failure #{_linktestFailures}/2).");

                            if (_linktestFailures >= 2 && !token.IsCancellationRequested)
                            {
                                Log(LogSeverity.Error, "Two consecutive linktest failures — connection lost.");
                                HandleUnexpectedDisconnect();
                                break;
                            }
                        }
                        else
                        {
                            _linktestFailures = 0;
                            Log(LogSeverity.Hsms, "Linktest OK.");
                        }
                    }
                    catch (OperationCanceledException) { break; }
                    catch { break; }
                }
                Log(LogSeverity.Info, "Linktest thread exiting.");
            })
            { IsBackground = true, Name = "HSMS-Linktest" };

            _linktestThread.Start();
        }

        // ─────────────────────────────────────────────────────
        //  Public: Disconnect
        // ─────────────────────────────────────────────────────
        public void Disconnect()
        {
            try
            {
                string ip   = CurrentConnection?.IpAddress ?? "";
                int    port = CurrentConnection?.Port ?? 0;

                // Send Separate.req gracefully
                if (_stream != null && (CurrentStatus == ConnectionStatus.Selected
                                     || CurrentStatus == ConnectionStatus.GemOnline))
                {
                    try
                    {
                        var sep = HsmsMessage.BuildSeparateReq(CurrentConnection.SessionId, NextSysBytes());
                        Log(LogSeverity.Hsms, $"TX → {sep}");
                        SendRaw(sep.ToBytes());
                        Thread.Sleep(200); // give equipment time to process
                    }
                    catch { /* best-effort */ }
                }

                CleanupSocket();

                if (CurrentConnection != null)
                {
                    CurrentConnection.Status        = ConnectionStatus.Disconnected;
                    CurrentConnection.DisconnectedAt = DateTime.Now;
                }

                ChangeStatus(ConnectionStatus.Disconnected,
                    $"Disconnected from {ip}:{port}.",
                    LogSeverity.Warning, ip, port);
            }
            catch (Exception ex)
            {
                Log(LogSeverity.Error, $"Disconnect error: {ex.Message}");
            }
        }

        // ─────────────────────────────────────────────────────
        //  Internal helpers
        // ─────────────────────────────────────────────────────

        private void HandleUnexpectedDisconnect()
        {
            if (CurrentStatus == ConnectionStatus.Disconnected) return;

            string ip   = CurrentConnection?.IpAddress ?? "";
            int    port = CurrentConnection?.Port ?? 0;

            CleanupSocket();

            if (CurrentConnection != null)
                CurrentConnection.Status = ConnectionStatus.Error;

            ChangeStatus(ConnectionStatus.Error,
                "Connection lost unexpectedly. Equipment may have closed the session.",
                LogSeverity.Error, ip, port);
        }

        private void CleanupSocket()
        {
            _cts?.Cancel();
            try { _stream?.Close(); }  catch { }
            try { _tcpClient?.Close(); } catch { }
            _stream    = null;
            _tcpClient = null;
        }

        /// <summary>Read exactly <paramref name="count"/> bytes from stream, or return null if closed/cancelled.</summary>
        private byte[] ReadExact(int count, CancellationToken token)
        {
            var buf = new byte[count];
            int received = 0;

            while (received < count)
            {
                if (token.IsCancellationRequested) return null;

                int n;
                try
                {
                    n = _stream.Read(buf, received, count - received);
                }
                catch (IOException ex) when (ex.InnerException is SocketException sx
                                             && sx.SocketErrorCode == SocketError.TimedOut)
                {
                    // Read timeout — check cancel and retry
                    continue;
                }

                if (n == 0) return null; // stream closed
                received += n;
            }
            return buf;
        }

        private void SendRaw(byte[] data)
        {
            lock (_writeLock)
            {
                _stream?.Write(data, 0, data.Length);
            }
        }

        private uint NextSysBytes() => _systemCounter++;

        private void ChangeStatus(ConnectionStatus status, string message,
                                  LogSeverity severity, string ip = "", int port = 0)
        {
            CurrentStatus = status;
            var args = new ConnectionEventArgs(status, message, severity, ip, port);
            ConnectionStatusChanged?.Invoke(this, args);
        }

        private void Log(LogSeverity severity, string message)
        {
            var args = new ConnectionEventArgs(CurrentStatus, message, severity);
            LogMessage?.Invoke(this, args);
        }

        private void Fail(string message, ConnectionProfile profile)
        {
            CleanupSocket();
            if (CurrentConnection != null)
                CurrentConnection.Status = ConnectionStatus.Error;

            ChangeStatus(ConnectionStatus.Error, message,
                LogSeverity.Error, profile?.IpAddress ?? "", profile?.Port ?? 0);
        }

        private static string SocketMsg(SocketError err)
        {
            switch (err)
            {
                case SocketError.ConnectionRefused:  return "Connection refused — check IP and port.";
                case SocketError.HostUnreachable:
                case SocketError.HostNotFound:       return "Host not found / unreachable.";
                case SocketError.NetworkUnreachable: return "Network unreachable.";
                case SocketError.TimedOut:           return "Connection timed out — equipment may be offline.";
                default:                              return err.ToString();
            }
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                CleanupSocket();
                _disposed = true;
            }
        }
    }
}
