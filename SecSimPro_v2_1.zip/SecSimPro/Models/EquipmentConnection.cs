using System;
using SecSimPro.Services;

namespace SecSimPro.Models
{
    public class EquipmentConnection
    {
        public string           IpAddress      { get; set; }
        public int              Port           { get; set; }
        public ushort           SessionId      { get; set; }
        public string           Description    { get; set; }
        public ConnectionStatus Status         { get; set; }
        public DateTime?        ConnectedAt    { get; set; }
        public DateTime?        DisconnectedAt { get; set; }

        public string DisplayName =>
            string.IsNullOrWhiteSpace(Description)
                ? $"{IpAddress}:{Port}"
                : $"{Description} ({IpAddress}:{Port})";

        public string StatusText
        {
            get
            {
                switch (Status)
                {
                    case ConnectionStatus.GemOnline:
                        return ConnectedAt.HasValue
                            ? $"GEM Online since {ConnectedAt.Value:HH:mm:ss}"
                            : "GEM Online";
                    case ConnectionStatus.Selected:
                        return ConnectedAt.HasValue
                            ? $"HSMS Selected since {ConnectedAt.Value:HH:mm:ss}"
                            : "HSMS Selected";
                    case ConnectionStatus.TcpConnected:
                        return "TCP Connected (not selected)";
                    case ConnectionStatus.Connecting:
                        return "Connecting...";
                    case ConnectionStatus.Disconnected:
                        return "Disconnected";
                    case ConnectionStatus.Error:
                        return "Connection Error";
                    default:
                        return "Unknown";
                }
            }
        }

        public EquipmentConnection()
        {
            Status = ConnectionStatus.Disconnected;
        }
    }
}
