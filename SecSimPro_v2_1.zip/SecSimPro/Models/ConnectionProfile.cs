using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace SecSimPro.Models
{
    [Serializable]
    public class ConnectionProfile
    {
        // ── Basic ─────────────────────────────────────────────
        public string ProfileName   { get; set; }
        public string IpAddress     { get; set; }
        public int    Port          { get; set; }
        public string Description   { get; set; }
        public int    TimeoutSeconds { get; set; }
        public bool   AutoReconnect { get; set; }
        public DateTime CreatedAt   { get; set; }

        // ── HSMS ─────────────────────────────────────────────
        /// <summary>HSMS Session ID (Device ID). Typically 0 or as configured in equipment. Default 0.</summary>
        public ushort SessionId           { get; set; }

        /// <summary>How often to send Linktest.req (seconds). SEMI E37 T8 equivalent. Default 15s.</summary>
        public int    LinktestIntervalSec { get; set; }

        // ── GEM ──────────────────────────────────────────────
        /// <summary>Send S1F13 Establish Communications after HSMS Select succeeds.</summary>
        public bool   UseGem              { get; set; }

        /// <summary>Send S2F31 Date/Time Set after GEM online. Optional.</summary>
        public bool   SendDateTimeOnConnect { get; set; }

        /// <summary>Model name sent in S1F13/S1F14 MDLN field (host identity).</summary>
        public string HostMdln            { get; set; }

        /// <summary>Software revision sent in S1F13/S1F14 SOFTREV field.</summary>
        public string HostSoftrev         { get; set; }

        public ConnectionProfile()
        {
            TimeoutSeconds       = 10;
            AutoReconnect        = false;
            SessionId            = 0;
            LinktestIntervalSec  = 15;
            UseGem               = true;
            SendDateTimeOnConnect = false;
            HostMdln             = "SecSimPro";
            HostSoftrev          = "2.0";
            CreatedAt            = DateTime.Now;
            Port                 = 5000;
        }

        public ConnectionProfile(string name, string ip, int port, string description = "") : this()
        {
            ProfileName = name;
            IpAddress   = ip;
            Port        = port;
            Description = description;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Persisted profile list (XML to %AppData%\SecSimPro\profiles.xml)
    // ─────────────────────────────────────────────────────────────────────────
    [Serializable]
    [XmlRoot("ConnectionProfiles")]
    public class ConnectionProfileList
    {
        [XmlElement("Profile")]
        public List<ConnectionProfile> Profiles { get; set; } = new List<ConnectionProfile>();

        private static readonly string ProfilesPath =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                         "SecSimPro", "profiles.xml");

        public static ConnectionProfileList Load()
        {
            try
            {
                if (File.Exists(ProfilesPath))
                {
                    var xs = new XmlSerializer(typeof(ConnectionProfileList));
                    using (var r = new StreamReader(ProfilesPath))
                        return (ConnectionProfileList)xs.Deserialize(r);
                }
            }
            catch { }
            return new ConnectionProfileList();
        }

        public void Save()
        {
            try
            {
                var dir = Path.GetDirectoryName(ProfilesPath);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);

                var xs = new XmlSerializer(typeof(ConnectionProfileList));
                using (var w = new StreamWriter(ProfilesPath))
                    xs.Serialize(w, this);
            }
            catch { }
        }
    }
}
