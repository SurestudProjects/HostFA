using System;
using System.Drawing;
using System.Windows.Forms;
using SecSimPro.Models;
using SecSimPro.Services;

namespace SecSimPro.Forms
{
    public partial class MainForm : Form
    {
        private TcpConnectionService _svc;
        private ConnectionProfile    _currentProfile;

        public MainForm()
        {
            InitializeComponent();
            _svc = new TcpConnectionService();
            _svc.ConnectionStatusChanged += OnStatusChanged;
            _svc.LogMessage              += OnLogMessage;

            ApplyUiState(ConnectionStatus.Disconnected, "", 0);
            AppendLog(LogSeverity.Info, "SecSimPro started. Ready for HSMS/GEM connection.");
            AppendLog(LogSeverity.Info, "Use File → Connect (Ctrl+N) to connect to equipment.");
        }

        // ─────────────────────────────────────────────────
        //  Actions
        // ─────────────────────────────────────────────────

        private void ShowConnectDialog()
        {
            using (var dlg = new ConnectionForm(_currentProfile))
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                _currentProfile = dlg.ResultProfile;
                AppendLog(LogSeverity.Info,
                    $"Connecting → {_currentProfile.IpAddress}:{_currentProfile.Port} " +
                    $"Session=0x{_currentProfile.SessionId:X4} GEM={_currentProfile.UseGem}");
                _svc.Connect(_currentProfile);
            }
        }

        private void ConfirmDisconnect()
        {
            var conn   = _svc.CurrentConnection;
            string tgt = conn != null ? $" from {conn.DisplayName}" : "";
            if (MessageBox.Show($"Disconnect{tgt}?", "Confirm Disconnect",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                AppendLog(LogSeverity.Warning, $"User disconnecting{tgt}...");
                _svc.Disconnect();
            }
        }

        // ─────────────────────────────────────────────────
        //  Events from service (cross-thread)
        // ─────────────────────────────────────────────────

        private void OnStatusChanged(object sender, ConnectionEventArgs e)
        {
            if (InvokeRequired) { Invoke(new Action(() => OnStatusChanged(sender, e))); return; }
            AppendLog(e.Severity, e.Message);
            ApplyUiState(e.Status, e.IpAddress, e.Port);
        }

        private void OnLogMessage(object sender, ConnectionEventArgs e)
        {
            if (InvokeRequired) { Invoke(new Action(() => OnLogMessage(sender, e))); return; }
            AppendLog(e.Severity, e.Message);
        }

        // ─────────────────────────────────────────────────
        //  UI state machine
        // ─────────────────────────────────────────────────

        private void ApplyUiState(ConnectionStatus status, string ip, int port)
        {
            bool canConnect    = status == ConnectionStatus.Disconnected || status == ConnectionStatus.Error;
            bool canDisconnect = status == ConnectionStatus.Selected
                              || status == ConnectionStatus.GemOnline
                              || status == ConnectionStatus.TcpConnected;

            btnConnect.Enabled    = canConnect;
            btnDisconnect.Enabled = canDisconnect;
            menuConnect.Enabled   = canConnect;
            menuDisconnect.Enabled = canDisconnect;
            btnConnectLarge.Enabled    = canConnect;
            btnDisconnectLarge.Enabled = canDisconnect;

            // Status label + indicator colour
            string statusText;
            Color  dotColor, stripColor, textColor;

            switch (status)
            {
                case ConnectionStatus.GemOnline:
                    statusText = "GEM Online";
                    dotColor   = Color.FromArgb(0, 190, 100);
                    stripColor = Color.FromArgb(215, 255, 235);
                    textColor  = Color.FromArgb(0, 130, 60);
                    break;
                case ConnectionStatus.Selected:
                    statusText = "HSMS Selected";
                    dotColor   = Color.FromArgb(0, 160, 80);
                    stripColor = Color.FromArgb(220, 255, 235);
                    textColor  = Color.FromArgb(0, 130, 60);
                    break;
                case ConnectionStatus.TcpConnected:
                    statusText = "TCP Connected";
                    dotColor   = Color.FromArgb(80, 160, 220);
                    stripColor = Color.FromArgb(220, 240, 255);
                    textColor  = Color.FromArgb(0, 80, 160);
                    break;
                case ConnectionStatus.Connecting:
                    statusText = "Connecting...";
                    dotColor   = Color.FromArgb(240, 160, 0);
                    stripColor = Color.FromArgb(255, 248, 220);
                    textColor  = Color.FromArgb(160, 100, 0);
                    break;
                case ConnectionStatus.Error:
                    statusText = "Error";
                    dotColor   = Color.FromArgb(200, 40, 40);
                    stripColor = Color.FromArgb(255, 235, 235);
                    textColor  = Color.DarkRed;
                    break;
                default:
                    statusText = "Disconnected";
                    dotColor   = Color.FromArgb(170, 170, 170);
                    stripColor = SystemColors.Control;
                    textColor  = Color.FromArgb(110, 110, 110);
                    break;
            }

            lblStatusValue.Text      = statusText;
            lblStatusValue.ForeColor = textColor;
            picStatus.BackColor      = dotColor;
            statusStrip1.BackColor   = stripColor;
            toolStripStatusLabel.Text = GetStripText(status, ip, port);

            // Right-panel equipment info
            var conn = _svc.CurrentConnection;
            if (conn != null && status != ConnectionStatus.Disconnected && status != ConnectionStatus.Error)
            {
                lblEquipmentValue.Text = conn.DisplayName;
                lblSessionValue.Text   = $"0x{conn.SessionId:X4}";
            }
            else
            {
                lblEquipmentValue.Text = "---";
                lblSessionValue.Text   = "---";
            }

            // Timer
            if (status == ConnectionStatus.Selected || status == ConnectionStatus.GemOnline)
            {
                if (conn != null && conn.ConnectedAt.HasValue)
                {
                    tmrConnected.Tag = conn.ConnectedAt.Value;
                    lblConnectedAtValue.Text = conn.ConnectedAt.Value.ToString("HH:mm:ss");
                }
                else
                {
                    tmrConnected.Tag = DateTime.Now;
                    lblConnectedAtValue.Text = DateTime.Now.ToString("HH:mm:ss");
                }
                tmrConnected.Start();
            }
            else
            {
                tmrConnected.Stop();
                tmrConnected.Tag     = null;
                lblConnectedAtValue.Text = "---";
                lblDurationValue.Text    = "---";
            }

            // Title bar
            switch (status)
            {
                case ConnectionStatus.GemOnline:
                    this.Text = $"SecSimPro — GEM Online [{ip}:{port}]"; break;
                case ConnectionStatus.Selected:
                    this.Text = $"SecSimPro — HSMS Selected [{ip}:{port}]"; break;
                case ConnectionStatus.Connecting:
                case ConnectionStatus.TcpConnected:
                    this.Text = "SecSimPro — Connecting..."; break;
                case ConnectionStatus.Error:
                    this.Text = "SecSimPro — Connection Error"; break;
                default:
                    this.Text = "SecSimPro — Equipment Manager"; break;
            }
        }

        private string GetStripText(ConnectionStatus s, string ip, int port)
        {
            switch (s)
            {
                case ConnectionStatus.GemOnline:    return $"GEM Online — {ip}:{port}";
                case ConnectionStatus.Selected:     return $"HSMS Selected — {ip}:{port}";
                case ConnectionStatus.TcpConnected: return $"TCP Connected — awaiting HSMS Select — {ip}:{port}";
                case ConnectionStatus.Connecting:   return $"Connecting to {ip}:{port}...";
                case ConnectionStatus.Error:        return "Connection failed — check log for details";
                default:                            return "Not connected";
            }
        }

        // ─────────────────────────────────────────────────
        //  Timer
        // ─────────────────────────────────────────────────

        private void tmrConnected_Tick(object sender, EventArgs e)
        {
            if (tmrConnected.Tag is DateTime t)
                lblDurationValue.Text = (DateTime.Now - t).ToString(@"hh\:mm\:ss");
        }

        // ─────────────────────────────────────────────────
        //  Activity log
        // ─────────────────────────────────────────────────

        private void AppendLog(LogSeverity sev, string message)
        {
            string ts     = DateTime.Now.ToString("HH:mm:ss.fff");
            string prefix;
            Color  prefixColor;

            switch (sev)
            {
                case LogSeverity.Success: prefix = "[ OK ]"; prefixColor = Color.FromArgb(0, 170, 80);   break;
                case LogSeverity.Warning: prefix = "[WARN]"; prefixColor = Color.FromArgb(200, 130, 0);  break;
                case LogSeverity.Error:   prefix = "[ERR ]"; prefixColor = Color.FromArgb(210, 40, 40);  break;
                case LogSeverity.Hsms:    prefix = "[HSMS]"; prefixColor = Color.FromArgb(80, 160, 220); break;
                case LogSeverity.Gem:     prefix = "[ GEM]"; prefixColor = Color.FromArgb(160, 110, 220);break;
                default:                  prefix = "[INFO]"; prefixColor = Color.FromArgb(130, 160, 200);break;
            }

            rtbLog.SelectionStart  = rtbLog.TextLength;
            rtbLog.SelectionLength = 0;

            rtbLog.SelectionColor = Color.FromArgb(80, 90, 110);
            rtbLog.AppendText($"{ts} ");

            rtbLog.SelectionColor = prefixColor;
            rtbLog.AppendText($"{prefix} ");

            rtbLog.SelectionColor = Color.FromArgb(210, 215, 225);
            rtbLog.AppendText($"{message}{Environment.NewLine}");

            rtbLog.SelectionStart = rtbLog.TextLength;
            rtbLog.ScrollToCaret();
        }

        // ─────────────────────────────────────────────────
        //  Menu / button handlers
        // ─────────────────────────────────────────────────

        private void menuConnect_Click   (object s, EventArgs e) => ShowConnectDialog();
        private void btnConnect_Click    (object s, EventArgs e) => ShowConnectDialog();
        private void menuDisconnect_Click(object s, EventArgs e) => ConfirmDisconnect();
        private void btnDisconnect_Click (object s, EventArgs e) => ConfirmDisconnect();

        private void menuClearLog_Click(object s, EventArgs e)
        {
            rtbLog.Clear();
            AppendLog(LogSeverity.Info, "Log cleared.");
        }

        private void menuAbout_Click(object s, EventArgs e)
        {
            MessageBox.Show(
                "SecSimPro Equipment Manager  v2.0\n\n" +
                "Transport layer : HSMS  (SEMI E37)\n" +
                "Application layer: GEM  (SEMI E30)\n\n" +
                "Supports Select/Linktest/Separate handshakes\n" +
                "and GEM S1F13/S1F14 Establish Communications.",
                "About SecSimPro", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void menuExit_Click(object s, EventArgs e)
        {
            if (_svc.IsConnected)
            {
                if (MessageBox.Show("Disconnect and exit?", "Confirm Exit",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                _svc.Disconnect();
            }
            Application.Exit();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_svc.IsConnected)
            {
                if (MessageBox.Show("Still connected. Disconnect and exit?", "Confirm Exit",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                        MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                { e.Cancel = true; return; }
                _svc.Disconnect();
            }
            _svc?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
