namespace SecSimPro.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            // ── Declare all controls ──────────────────────────
            this.menuStrip1          = new System.Windows.Forms.MenuStrip();
            this.menuFile            = new System.Windows.Forms.ToolStripMenuItem();
            this.menuConnect         = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDisconnect      = new System.Windows.Forms.ToolStripMenuItem();
            this.sep1                = new System.Windows.Forms.ToolStripSeparator();
            this.menuClearLog        = new System.Windows.Forms.ToolStripMenuItem();
            this.sep2                = new System.Windows.Forms.ToolStripSeparator();
            this.menuExit            = new System.Windows.Forms.ToolStripMenuItem();
            this.menuHelp            = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAbout           = new System.Windows.Forms.ToolStripMenuItem();

            this.toolStrip1          = new System.Windows.Forms.ToolStrip();
            this.btnConnect          = new System.Windows.Forms.ToolStripButton();
            this.btnDisconnect       = new System.Windows.Forms.ToolStripButton();
            this.toolSep1            = new System.Windows.Forms.ToolStripSeparator();

            this.pnlHeader           = new System.Windows.Forms.Panel();
            this.lblTitle            = new System.Windows.Forms.Label();
            this.lblSubtitle         = new System.Windows.Forms.Label();
            this.picLogo             = new System.Windows.Forms.PictureBox();

            this.splitMain           = new System.Windows.Forms.SplitContainer();

            // Left panel
            this.pnlLeft             = new System.Windows.Forms.Panel();
            this.grpStatus           = new System.Windows.Forms.GroupBox();
            this.tblStatus           = new System.Windows.Forms.TableLayoutPanel();
            this.lblStatusLbl        = new System.Windows.Forms.Label();
            this.lblStatusValue      = new System.Windows.Forms.Label();
            this.lblEquipmentLbl     = new System.Windows.Forms.Label();
            this.lblEquipmentValue   = new System.Windows.Forms.Label();
            this.lblSessionLbl       = new System.Windows.Forms.Label();
            this.lblSessionValue     = new System.Windows.Forms.Label();
            this.lblConnectedAtLbl   = new System.Windows.Forms.Label();
            this.lblConnectedAtValue = new System.Windows.Forms.Label();
            this.lblDurationLbl      = new System.Windows.Forms.Label();
            this.lblDurationValue    = new System.Windows.Forms.Label();
            this.picStatus           = new System.Windows.Forms.PictureBox();

            this.pnlActionBtns       = new System.Windows.Forms.Panel();
            this.btnConnectLarge     = new System.Windows.Forms.Button();
            this.btnDisconnectLarge  = new System.Windows.Forms.Button();

            this.grpProtocol         = new System.Windows.Forms.GroupBox();
            this.tblProtocol         = new System.Windows.Forms.TableLayoutPanel();
            this.lblHsmsLbl          = new System.Windows.Forms.Label();
            this.lblHsmsValue        = new System.Windows.Forms.Label();
            this.lblGemLbl           = new System.Windows.Forms.Label();
            this.lblGemValue         = new System.Windows.Forms.Label();
            this.lblLinktestLbl      = new System.Windows.Forms.Label();
            this.lblLinktestValue    = new System.Windows.Forms.Label();

            // Right panel
            this.grpLog              = new System.Windows.Forms.GroupBox();
            this.rtbLog              = new System.Windows.Forms.RichTextBox();

            this.statusStrip1        = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripVersion    = new System.Windows.Forms.ToolStripStatusLabel();

            this.tmrConnected        = new System.Windows.Forms.Timer(this.components);

            // ── Suspend ───────────────────────────────────────
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitMain)).BeginInit();
            this.splitMain.Panel1.SuspendLayout();
            this.splitMain.Panel2.SuspendLayout();
            this.splitMain.SuspendLayout();
            this.pnlLeft.SuspendLayout();
            this.grpStatus.SuspendLayout();
            this.tblStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStatus)).BeginInit();
            this.pnlActionBtns.SuspendLayout();
            this.grpProtocol.SuspendLayout();
            this.tblProtocol.SuspendLayout();
            this.grpLog.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();

            // ═══════════════════════════════════════════════════
            //  MENU STRIP
            // ═══════════════════════════════════════════════════
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(22, 32, 52);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.menuFile, this.menuHelp });
            this.menuStrip1.Renderer = new DarkMenuRenderer();

            this.menuFile.ForeColor = System.Drawing.Color.White;
            this.menuFile.Text      = "&File";
            this.menuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.menuConnect, this.menuDisconnect,
                this.sep1, this.menuClearLog,
                this.sep2, this.menuExit });

            SetupMenuItem(this.menuConnect,    "&Connect to Equipment...",
                "Ctrl+N", System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N,
                DotIcon(System.Drawing.Color.FromArgb(0, 200, 100), 12),
                this.menuConnect_Click);
            SetupMenuItem(this.menuDisconnect, "&Disconnect",
                "Ctrl+D", System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D,
                DotIcon(System.Drawing.Color.FromArgb(200, 60, 60), 12),
                this.menuDisconnect_Click);
            this.menuDisconnect.Enabled = false;

            this.menuClearLog.Text   = "C&lear Log";
            this.menuClearLog.Click += new System.EventHandler(this.menuClearLog_Click);

            this.menuExit.Text   = "E&xit";
            this.menuExit.Click += new System.EventHandler(this.menuExit_Click);

            this.menuHelp.ForeColor = System.Drawing.Color.White;
            this.menuHelp.Text      = "&Help";
            this.menuHelp.DropDownItems.Add(this.menuAbout);
            this.menuAbout.Text    = "&About SecSimPro";
            this.menuAbout.Click  += new System.EventHandler(this.menuAbout_Click);

            // ═══════════════════════════════════════════════════
            //  TOOL STRIP
            // ═══════════════════════════════════════════════════
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(36, 50, 76);
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Padding   = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.toolStrip1.Renderer  = new DarkToolStripRenderer();
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.btnConnect, this.btnDisconnect, this.toolSep1 });

            SetupToolBtn(this.btnConnect,    "  Connect",
                DotIcon(System.Drawing.Color.FromArgb(0, 210, 110), 14), this.btnConnect_Click);
            SetupToolBtn(this.btnDisconnect, "  Disconnect",
                DotIcon(System.Drawing.Color.FromArgb(220, 60, 60), 14),  this.btnDisconnect_Click);
            this.btnDisconnect.Enabled = false;

            // ═══════════════════════════════════════════════════
            //  HEADER PANEL
            // ═══════════════════════════════════════════════════
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(16, 24, 42);
            this.pnlHeader.Dock      = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Height    = 66;
            this.pnlHeader.Controls.AddRange(new System.Windows.Forms.Control[]
                { this.picLogo, this.lblTitle, this.lblSubtitle });

            this.picLogo.Size     = new System.Drawing.Size(46, 46);
            this.picLogo.Location = new System.Drawing.Point(14, 10);
            this.picLogo.Image    = MakeLogoImage();
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;

            this.lblTitle.AutoSize  = true;
            this.lblTitle.Font      = new System.Drawing.Font("Segoe UI", 17f, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location  = new System.Drawing.Point(70, 7);
            this.lblTitle.Text      = "SecSimPro";

            this.lblSubtitle.AutoSize  = true;
            this.lblSubtitle.Font      = new System.Drawing.Font("Segoe UI", 8.5f);
            this.lblSubtitle.ForeColor = System.Drawing.Color.FromArgb(120, 160, 210);
            this.lblSubtitle.Location  = new System.Drawing.Point(72, 40);
            this.lblSubtitle.Text      = "HSMS / GEM Equipment Connection Manager  (SEMI E37 · E30)";

            // ═══════════════════════════════════════════════════
            //  SPLIT CONTAINER
            // ═══════════════════════════════════════════════════
            this.splitMain.Dock             = System.Windows.Forms.DockStyle.Fill;
            this.splitMain.SplitterDistance = 290;
            this.splitMain.SplitterWidth    = 5;
            this.splitMain.Panel1MinSize    = 260;
            this.splitMain.Panel2MinSize    = 340;

            // ── LEFT PANEL ──────────────────────────────────────
            this.splitMain.Panel1.BackColor = System.Drawing.Color.FromArgb(244, 246, 250);
            this.splitMain.Panel1.Controls.Add(this.pnlLeft);

            this.pnlLeft.Dock    = System.Windows.Forms.DockStyle.Fill;
            this.pnlLeft.Padding = new System.Windows.Forms.Padding(10, 8, 10, 8);
            this.pnlLeft.Controls.Add(this.grpStatus);
            this.pnlLeft.Controls.Add(this.pnlActionBtns);
            this.pnlLeft.Controls.Add(this.grpProtocol);

            // ── grpStatus ─────────────────────────────────────
            this.picStatus.Size     = new System.Drawing.Size(18, 18);
            this.picStatus.Location = new System.Drawing.Point(210, 20);
            this.picStatus.BackColor = System.Drawing.Color.FromArgb(170, 170, 170);
            this.picStatus.Paint   += (s, e2) => {
                e2.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                e2.Graphics.FillEllipse(new System.Drawing.SolidBrush(this.picStatus.BackColor),
                    0, 0, this.picStatus.Width - 1, this.picStatus.Height - 1);
            };
            this.picStatus.BackColorChanged += (s, e2) => this.picStatus.Invalidate();

            this.grpStatus.Text      = "Connection Status";
            this.grpStatus.Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.grpStatus.ForeColor = System.Drawing.Color.FromArgb(20, 60, 120);
            this.grpStatus.Dock      = System.Windows.Forms.DockStyle.Top;
            this.grpStatus.Height    = 168;
            this.grpStatus.Padding   = new System.Windows.Forms.Padding(6);
            this.grpStatus.Controls.Add(this.tblStatus);
            this.grpStatus.Controls.Add(this.picStatus);

            this.tblStatus.Dock         = System.Windows.Forms.DockStyle.Fill;
            this.tblStatus.ColumnCount  = 2;
            this.tblStatus.RowCount     = 5;
            this.tblStatus.Padding      = new System.Windows.Forms.Padding(4, 20, 4, 4);
            this.tblStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108f));
            this.tblStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100f));
            for (int r = 0; r < 5; r++)
                this.tblStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20f));

            AddStatusRow(this.tblStatus, 0, "Status:",       out this.lblStatusLbl,      out this.lblStatusValue);
            AddStatusRow(this.tblStatus, 1, "Equipment:",    out this.lblEquipmentLbl,    out this.lblEquipmentValue);
            AddStatusRow(this.tblStatus, 2, "Session ID:",   out this.lblSessionLbl,      out this.lblSessionValue);
            AddStatusRow(this.tblStatus, 3, "Connected At:", out this.lblConnectedAtLbl,  out this.lblConnectedAtValue);
            AddStatusRow(this.tblStatus, 4, "Duration:",     out this.lblDurationLbl,     out this.lblDurationValue);

            this.lblStatusValue.ForeColor = System.Drawing.Color.FromArgb(110, 110, 110);

            // ── pnlActionBtns ──────────────────────────────────
            this.pnlActionBtns.Dock    = System.Windows.Forms.DockStyle.Top;
            this.pnlActionBtns.Height  = 52;
            this.pnlActionBtns.Padding = new System.Windows.Forms.Padding(0, 8, 0, 0);
            this.pnlActionBtns.Controls.Add(this.btnConnectLarge);
            this.pnlActionBtns.Controls.Add(this.btnDisconnectLarge);

            StyleLargeBtn(this.btnConnectLarge, "⚡  Connect",
                System.Drawing.Color.FromArgb(0, 110, 175),
                new System.Drawing.Point(0, 8), new System.Drawing.Size(118, 36));
            this.btnConnectLarge.Click += new System.EventHandler(this.btnConnect_Click);

            StyleLargeBtn(this.btnDisconnectLarge, "✕  Disconnect",
                System.Drawing.Color.FromArgb(170, 35, 35),
                new System.Drawing.Point(126, 8), new System.Drawing.Size(130, 36));
            this.btnDisconnectLarge.Enabled = false;
            this.btnDisconnectLarge.Click  += new System.EventHandler(this.btnDisconnect_Click);

            // Sync toolbar enable/disable → large buttons colour
            this.btnConnect.EnabledChanged += (s, e) => {
                this.btnConnectLarge.Enabled   = this.btnConnect.Enabled;
                this.btnConnectLarge.BackColor = this.btnConnect.Enabled
                    ? System.Drawing.Color.FromArgb(0, 110, 175)
                    : System.Drawing.Color.FromArgb(150, 180, 200);
            };
            this.btnDisconnect.EnabledChanged += (s, e) => {
                this.btnDisconnectLarge.Enabled   = this.btnDisconnect.Enabled;
                this.btnDisconnectLarge.BackColor = this.btnDisconnect.Enabled
                    ? System.Drawing.Color.FromArgb(170, 35, 35)
                    : System.Drawing.Color.FromArgb(200, 155, 155);
            };

            // ── grpProtocol ────────────────────────────────────
            this.grpProtocol.Text      = "Protocol Info";
            this.grpProtocol.Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.grpProtocol.ForeColor = System.Drawing.Color.FromArgb(20, 60, 120);
            this.grpProtocol.Dock      = System.Windows.Forms.DockStyle.Top;
            this.grpProtocol.Height    = 100;
            this.grpProtocol.Padding   = new System.Windows.Forms.Padding(6);
            this.grpProtocol.Controls.Add(this.tblProtocol);

            this.tblProtocol.Dock         = System.Windows.Forms.DockStyle.Fill;
            this.tblProtocol.ColumnCount  = 2;
            this.tblProtocol.RowCount     = 3;
            this.tblProtocol.Padding      = new System.Windows.Forms.Padding(4, 14, 4, 4);
            this.tblProtocol.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108f));
            this.tblProtocol.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100f));
            for (int r = 0; r < 3; r++)
                this.tblProtocol.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33f));

            AddStatusRow(this.tblProtocol, 0, "Transport:",  out this.lblHsmsLbl,      out this.lblHsmsValue);
            AddStatusRow(this.tblProtocol, 1, "Application:", out this.lblGemLbl,       out this.lblGemValue);
            AddStatusRow(this.tblProtocol, 2, "Linktest:",   out this.lblLinktestLbl,   out this.lblLinktestValue);

            this.lblHsmsValue.Text      = "HSMS  (SEMI E37)";
            this.lblGemValue.Text       = "GEM   (SEMI E30)";
            this.lblLinktestValue.Text  = "Auto (T8)";
            this.lblHsmsValue.ForeColor = System.Drawing.Color.FromArgb(0, 100, 170);
            this.lblGemValue.ForeColor  = System.Drawing.Color.FromArgb(120, 60, 180);

            // Stack: protocol → action → status (bottom-up in DockStyle.Top)
            this.pnlLeft.Controls.SetChildIndex(this.grpProtocol,   0);
            this.pnlLeft.Controls.SetChildIndex(this.pnlActionBtns, 1);
            this.pnlLeft.Controls.SetChildIndex(this.grpStatus,     2);

            // ── RIGHT PANEL (Log) ──────────────────────────────
            this.splitMain.Panel2.Controls.Add(this.grpLog);
            this.grpLog.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.grpLog.Text      = "Activity Log";
            this.grpLog.Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.grpLog.ForeColor = System.Drawing.Color.FromArgb(20, 60, 120);
            this.grpLog.Padding   = new System.Windows.Forms.Padding(6);
            this.grpLog.Controls.Add(this.rtbLog);

            this.rtbLog.Dock        = System.Windows.Forms.DockStyle.Fill;
            this.rtbLog.BackColor   = System.Drawing.Color.FromArgb(14, 18, 30);
            this.rtbLog.ForeColor   = System.Drawing.Color.FromArgb(200, 210, 230);
            this.rtbLog.Font        = new System.Drawing.Font("Consolas", 9f);
            this.rtbLog.ReadOnly    = true;
            this.rtbLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbLog.ScrollBars  = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbLog.WordWrap    = true;

            // ═══════════════════════════════════════════════════
            //  STATUS STRIP
            // ═══════════════════════════════════════════════════
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.toolStripStatusLabel, this.toolStripVersion });

            this.toolStripStatusLabel.Spring    = true;
            this.toolStripStatusLabel.Text      = "Not connected";
            this.toolStripStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            this.toolStripVersion.ForeColor = System.Drawing.Color.FromArgb(130, 130, 150);
            this.toolStripVersion.Text      = "SecSimPro v2.0  |  HSMS + GEM";

            // ═══════════════════════════════════════════════════
            //  TIMER
            // ═══════════════════════════════════════════════════
            this.tmrConnected.Interval = 1000;
            this.tmrConnected.Tick    += new System.EventHandler(this.tmrConnected_Tick);

            // ═══════════════════════════════════════════════════
            //  FORM
            // ═══════════════════════════════════════════════════
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(980, 620);
            this.MinimumSize         = new System.Drawing.Size(760, 500);
            this.Font                = new System.Drawing.Font("Segoe UI", 8.5f);
            this.MainMenuStrip       = this.menuStrip1;
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text                = "SecSimPro — Equipment Manager";

            this.Controls.Add(this.splitMain);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.statusStrip1);

            // ── Resume ────────────────────────────────────────
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.splitMain.Panel1.ResumeLayout(false);
            this.splitMain.Panel2.ResumeLayout(false);
            this.splitMain.ResumeLayout(false);
            this.pnlLeft.ResumeLayout(false);
            this.grpStatus.ResumeLayout(false);
            this.tblStatus.ResumeLayout(false);
            this.tblStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStatus)).EndInit();
            this.pnlActionBtns.ResumeLayout(false);
            this.grpProtocol.ResumeLayout(false);
            this.tblProtocol.ResumeLayout(false);
            this.tblProtocol.PerformLayout();
            this.grpLog.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // ─────────────────────────────────────────────────
        //  Builder helpers
        // ─────────────────────────────────────────────────

        private void AddStatusRow(System.Windows.Forms.TableLayoutPanel tbl, int row,
            string label,
            out System.Windows.Forms.Label lblCtrl,
            out System.Windows.Forms.Label valCtrl)
        {
            lblCtrl = new System.Windows.Forms.Label
            {
                Text      = label,
                Font      = new System.Drawing.Font("Segoe UI", 8.5f),
                ForeColor = System.Drawing.Color.FromArgb(100, 110, 130),
                Dock      = System.Windows.Forms.DockStyle.Fill,
                TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                Padding   = new System.Windows.Forms.Padding(0, 0, 8, 0)
            };
            valCtrl = new System.Windows.Forms.Label
            {
                Text      = "---",
                Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.FromArgb(30, 30, 40),
                Dock      = System.Windows.Forms.DockStyle.Fill,
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft
            };
            tbl.Controls.Add(lblCtrl, 0, row);
            tbl.Controls.Add(valCtrl, 1, row);
        }

        private void SetupMenuItem(System.Windows.Forms.ToolStripMenuItem item,
            string text, string shortcutText,
            System.Windows.Forms.Keys shortcut,
            System.Drawing.Image icon,
            System.EventHandler handler)
        {
            item.Text         = text;
            item.ShortcutKeys = shortcut;
            item.Image        = icon;
            item.Click       += handler;
        }

        private void SetupToolBtn(System.Windows.Forms.ToolStripButton btn,
            string text, System.Drawing.Image icon,
            System.EventHandler handler)
        {
            btn.Text                    = text;
            btn.Image                   = icon;
            btn.ForeColor               = System.Drawing.Color.White;
            btn.DisplayStyle            = System.Windows.Forms.ToolStripItemDisplayStyle.ImageAndText;
            btn.ImageTransparentColor   = System.Drawing.Color.Magenta;
            btn.Padding                 = new System.Windows.Forms.Padding(4, 0, 8, 0);
            btn.Click                  += handler;
        }

        private void StyleLargeBtn(System.Windows.Forms.Button btn, string text,
            System.Drawing.Color back, System.Drawing.Point loc, System.Drawing.Size sz)
        {
            btn.Text      = text;
            btn.BackColor = back;
            btn.ForeColor = System.Drawing.Color.White;
            btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Font      = new System.Drawing.Font("Segoe UI", 9.5f, System.Drawing.FontStyle.Bold);
            btn.Location  = loc;
            btn.Size      = sz;
            btn.Cursor    = System.Windows.Forms.Cursors.Hand;
        }

        private System.Drawing.Image DotIcon(System.Drawing.Color color, int size)
        {
            var bmp = new System.Drawing.Bitmap(size, size);
            using (var g = System.Drawing.Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(System.Drawing.Color.Transparent);
                g.FillEllipse(new System.Drawing.SolidBrush(color), 1, 1, size - 2, size - 2);
            }
            return bmp;
        }

        private System.Drawing.Image MakeLogoImage()
        {
            var bmp = new System.Drawing.Bitmap(48, 48);
            using (var g = System.Drawing.Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(System.Drawing.Color.Transparent);
                // Outer ring
                g.FillEllipse(
                    new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(0, 120, 210)),
                    0, 0, 47, 47);
                // Dark inner ring
                g.FillEllipse(
                    new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(16, 24, 42)),
                    7, 7, 33, 33);
                // Green core dot
                g.FillEllipse(
                    new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(0, 210, 120)),
                    15, 15, 17, 17);
            }
            return bmp;
        }

        #endregion

        // ─────────────────────────────────────────────────
        //  Custom renderers (dark menu / toolbar)
        // ─────────────────────────────────────────────────

        private class DarkMenuRenderer : System.Windows.Forms.ToolStripProfessionalRenderer
        {
            public DarkMenuRenderer() : base(new DarkMenuColors()) { }
        }
        private class DarkMenuColors : System.Windows.Forms.ProfessionalColorTable
        {
            public override System.Drawing.Color MenuStripGradientBegin   => System.Drawing.Color.FromArgb(22, 32, 52);
            public override System.Drawing.Color MenuStripGradientEnd     => System.Drawing.Color.FromArgb(22, 32, 52);
            public override System.Drawing.Color MenuBorder               => System.Drawing.Color.FromArgb(60, 80, 120);
            public override System.Drawing.Color MenuItemSelected         => System.Drawing.Color.FromArgb(50, 70, 115);
            public override System.Drawing.Color MenuItemBorder           => System.Drawing.Color.FromArgb(80, 120, 190);
            public override System.Drawing.Color ToolStripDropDownBackground => System.Drawing.Color.FromArgb(22, 32, 52);
            public override System.Drawing.Color ImageMarginGradientBegin => System.Drawing.Color.FromArgb(36, 50, 76);
            public override System.Drawing.Color ImageMarginGradientMiddle => System.Drawing.Color.FromArgb(36, 50, 76);
            public override System.Drawing.Color ImageMarginGradientEnd   => System.Drawing.Color.FromArgb(36, 50, 76);
        }

        private class DarkToolStripRenderer : System.Windows.Forms.ToolStripProfessionalRenderer
        {
            public DarkToolStripRenderer() : base(new DarkToolColors()) { }
            protected override void OnRenderButtonBackground(System.Windows.Forms.ToolStripItemRenderEventArgs e)
            {
                if (e.Item.Selected || e.Item.Pressed)
                {
                    var r = new System.Drawing.Rectangle(2, 2, e.Item.Width - 4, e.Item.Height - 4);
                    e.Graphics.FillRectangle(
                        new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(65, 90, 140)), r);
                }
            }
        }
        private class DarkToolColors : System.Windows.Forms.ProfessionalColorTable
        {
            public override System.Drawing.Color ToolStripGradientBegin  => System.Drawing.Color.FromArgb(36, 50, 76);
            public override System.Drawing.Color ToolStripGradientMiddle => System.Drawing.Color.FromArgb(36, 50, 76);
            public override System.Drawing.Color ToolStripGradientEnd    => System.Drawing.Color.FromArgb(36, 50, 76);
            public override System.Drawing.Color ToolStripBorder         => System.Drawing.Color.FromArgb(22, 32, 52);
        }

        // ─────────────────────────────────────────────────
        //  Field declarations
        // ─────────────────────────────────────────────────
        private System.Windows.Forms.MenuStrip              menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem      menuFile;
        private System.Windows.Forms.ToolStripMenuItem      menuConnect;
        private System.Windows.Forms.ToolStripMenuItem      menuDisconnect;
        private System.Windows.Forms.ToolStripSeparator     sep1, sep2;
        private System.Windows.Forms.ToolStripMenuItem      menuClearLog;
        private System.Windows.Forms.ToolStripMenuItem      menuExit;
        private System.Windows.Forms.ToolStripMenuItem      menuHelp;
        private System.Windows.Forms.ToolStripMenuItem      menuAbout;
        private System.Windows.Forms.ToolStrip              toolStrip1;
        private System.Windows.Forms.ToolStripButton        btnConnect;
        private System.Windows.Forms.ToolStripButton        btnDisconnect;
        private System.Windows.Forms.ToolStripSeparator     toolSep1;
        private System.Windows.Forms.Panel                  pnlHeader;
        private System.Windows.Forms.Label                  lblTitle;
        private System.Windows.Forms.Label                  lblSubtitle;
        private System.Windows.Forms.PictureBox             picLogo;
        private System.Windows.Forms.SplitContainer         splitMain;
        private System.Windows.Forms.Panel                  pnlLeft;
        private System.Windows.Forms.GroupBox               grpStatus;
        private System.Windows.Forms.TableLayoutPanel       tblStatus;
        private System.Windows.Forms.Label                  lblStatusLbl,       lblStatusValue;
        private System.Windows.Forms.Label                  lblEquipmentLbl,    lblEquipmentValue;
        private System.Windows.Forms.Label                  lblSessionLbl,      lblSessionValue;
        private System.Windows.Forms.Label                  lblConnectedAtLbl,  lblConnectedAtValue;
        private System.Windows.Forms.Label                  lblDurationLbl,     lblDurationValue;
        private System.Windows.Forms.PictureBox             picStatus;
        private System.Windows.Forms.Panel                  pnlActionBtns;
        private System.Windows.Forms.Button                 btnConnectLarge;
        private System.Windows.Forms.Button                 btnDisconnectLarge;
        private System.Windows.Forms.GroupBox               grpProtocol;
        private System.Windows.Forms.TableLayoutPanel       tblProtocol;
        private System.Windows.Forms.Label                  lblHsmsLbl,        lblHsmsValue;
        private System.Windows.Forms.Label                  lblGemLbl,         lblGemValue;
        private System.Windows.Forms.Label                  lblLinktestLbl,    lblLinktestValue;
        private System.Windows.Forms.GroupBox               grpLog;
        private System.Windows.Forms.RichTextBox            rtbLog;
        private System.Windows.Forms.StatusStrip            statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel   toolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel   toolStripVersion;
        private System.Windows.Forms.Timer                  tmrConnected;
    }
}
