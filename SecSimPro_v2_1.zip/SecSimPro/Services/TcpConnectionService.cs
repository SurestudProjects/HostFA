using System;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using SecSimPro.Models;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  TcpConnectionService  — HSMS (SEMI E37) + GEM (SEMI E30) stack
    //
    //  Connection sequence:
    //
    //   ┌──────────────────────────────────────────────────────────────────┐
    //   │  [1] TCP SYN/ACK                                                 │
    //   │  [2] HSMS Select.req  →  Select.rsp (T7 timeout)                │
    //   │  [3] ── SELECTED ── linktest timer starts                        │
    //   │  [4a] HOST→EQ:  S1F13(MDLN,SOFTREV) → wait S1F14(COMMACK)       │
    //   │  [4b] EQ→HOST:  Equipment may send its own S1F13 → we reply      │
    //   │       S1F14(COMMACK=0)  → GEM ONLINE ✓                          │
    //   └──────────────────────────────────────────────────────────────────┘
    //
    //  GEM ENABLED → COMMUNICATING requires BOTH:
    //    • Equipment receives S1F14(COMMACK=0) confirming host accepted comms
    //    • OR: Host receives equipment's S1F13 and replies S1F14(COMMACK=0)
    //  We handle BOTH paths simultaneously.
    // ─────────────────────────────────────────────────────────────────────────
    public class TcpConnectionService : IDisposable
    {
        // ── HSMS/GEM timers (seconds) ─────────────────────────
        private const int T3_ReplyTimeout        = 45;  // wait for data-msg reply
        private const int T6_ControlTimeout      = 5;   // wait for Select/Linktest rsp
        private const int T7_NotSelectedTimeout  = 10;  // max time without Select
        private const int T8_ReadTimeout         = 5;   // per-read socket timeout

        private int _linktestIntervalSec = 15;

        // ── Socket state ──────────────────────────────────────
        private TcpClient              _tcp;
        private NetworkStream          _stream;
        private CancellationTokenSource _cts;
        private Thread                 _rxThread;
        private Thread                 _linktestThread;
        private readonly object        _txLock = new object();
        private uint                   _sysCtr = 1;

        // ── Synchronisation latches ───────────────────────────
        private readonly ManualResetEventSlim _selectLatch   = new ManualResetEventSlim(false);
        private readonly ManualResetEventSlim _s1f14Latch    = new ManualResetEventSlim(false);
        private readonly ManualResetEventSlim _linktestLatch = new ManualResetEventSlim(false);

        private HsmsSelectStatus _selectStatus;
        private byte?            _inboundCommAck;     // commack received from EQ S1F14
        private bool             _gemOnlineAchieved;  // set once GEM ONLINE is reached
        private bool             _disposed;

        // ── Profile stored for use by handlers ───────────────
        private ConnectionProfile _profile;

        // ── Public ────────────────────────────────────────────
        public ConnectionStatus    CurrentStatus     { get; private set; } = ConnectionStatus.Disconnected;
        public EquipmentConnection CurrentConnection { get; private set; }
        public bool IsConnected => CurrentStatus == ConnectionStatus.Selected
                                || CurrentStatus == ConnectionStatus.GemOnline;

        public event EventHandler<ConnectionEventArgs> ConnectionStatusChanged;
        public event EventHandler<ConnectionEventArgs> LogMessage;

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Connect
        // ─────────────────────────────────────────────────────
        public void Connect(ConnectionProfile profile)
        {
            if (CurrentStatus != ConnectionStatus.Disconnected &&
                CurrentStatus != ConnectionStatus.Error)
            {
                Log(LogSeverity.Warning, "Already connected. Disconnect first.");
                return;
            }

            _profile             = profile;
            _linktestIntervalSec = profile.LinktestIntervalSec > 0 ? profile.LinktestIntervalSec : 15;
            _gemOnlineAchieved   = false;

            CurrentConnection = new EquipmentConnection
            {
                IpAddress   = profile.IpAddress,
                Port        = profile.Port,
                Description = profile.Description,
                SessionId   = profile.SessionId,
                Status      = ConnectionStatus.Connecting
            };

            ChangeStatus(ConnectionStatus.Connecting,
                $"Connecting to {profile.IpAddress}:{profile.Port}...",
                LogSeverity.Info, profile.IpAddress, profile.Port);

            Task.Run(() => RunConnect(profile));
        }

        // ─────────────────────────────────────────────────────
        //  STAGE 1 — TCP connect
        // ─────────────────────────────────────────────────────
        private void RunConnect(ConnectionProfile p)
        {
            try
            {
                _tcp         = new TcpClient();
                _tcp.NoDelay = true;

                var task = _tcp.ConnectAsync(p.IpAddress, p.Port);
                if (!task.Wait(TimeSpan.FromSeconds(p.TimeoutSeconds)))
                { Fail($"TCP timeout after {p.TimeoutSeconds}s.", p); return; }

                if (!_tcp.Connected)
                { Fail("TCP refused by host.", p); return; }

                _stream              = _tcp.GetStream();
                _stream.ReadTimeout  = T8_ReadTimeout * 1000;
                _stream.WriteTimeout = T8_ReadTimeout * 1000;

                Log(LogSeverity.Info, $"TCP connected → {p.IpAddress}:{p.Port}");
                ChangeStatus(ConnectionStatus.TcpConnected,
                    $"TCP up. Sending HSMS Select.req (Session 0x{p.SessionId:X4})...",
                    LogSeverity.Hsms, p.IpAddress, p.Port);

                _cts = new CancellationTokenSource();
                StartRxLoop(_cts.Token);
                RunHsmsSelect(p);
            }
            catch (SocketException ex) { Fail($"Socket: {SockMsg(ex.SocketErrorCode)}", p); }
            catch (Exception ex)       { Fail($"Connect error: {ex.Message}", p); }
        }

        // ─────────────────────────────────────────────────────
        //  STAGE 2 — HSMS Select
        // ─────────────────────────────────────────────────────
        private void RunHsmsSelect(ConnectionProfile p)
        {
            try
            {
                _selectLatch.Reset();
                var req = HsmsMessage.BuildSelectReq(p.SessionId, NextSys());
                TxLog(req); Send(req.ToBytes());

                if (!_selectLatch.Wait(TimeSpan.FromSeconds(T7_NotSelectedTimeout)))
                {
                    Fail($"No Select.rsp within T7={T7_NotSelectedTimeout}s. " +
                         "Check Session ID matches equipment config.", p);
                    return;
                }

                if (_selectStatus != HsmsSelectStatus.Success)
                {
                    Fail($"Select rejected — status {_selectStatus} (0x{(byte)_selectStatus:X2}). " +
                         "Verify Session ID in Connection dialog.", p);
                    return;
                }

                CurrentConnection.Status    = ConnectionStatus.Selected;
                CurrentConnection.SessionId = p.SessionId;

                ChangeStatus(ConnectionStatus.Selected,
                    $"HSMS Selected ✓  (Session 0x{p.SessionId:X4}). Starting linktest + GEM handshake...",
                    LogSeverity.Hsms, p.IpAddress, p.Port);

                StartLinktestTimer(_cts.Token);

                if (p.UseGem)
                    RunGemHandshake(p);
                else
                    FinalizeSelected(p);
            }
            catch (Exception ex) { Fail($"HSMS Select error: {ex.Message}", p); }
        }

        // ─────────────────────────────────────────────────────
        //  STAGE 3 — GEM Establish Communications
        //
        //  Two simultaneous paths:
        //    PATH A (Host-initiated):  HOST sends S1F13 → waits for EQ S1F14
        //    PATH B (EQ-initiated):    EQ sends S1F13   → HOST replies S1F14(0)
        //                              → receive loop signals _s1f14Latch with ack=0
        //
        //  Either path reaching COMMACK=0 moves us to GEM Online.
        // ─────────────────────────────────────────────────────
        private void RunGemHandshake(ConnectionProfile p)
        {
            Log(LogSeverity.Gem,
                "GEM: Starting Establish Communications handshake (S1F13/S1F14)...");
            Log(LogSeverity.Gem,
                "GEM: Will send S1F13 AND listen for equipment-initiated S1F13 simultaneously.");

            _s1f14Latch.Reset();
            _inboundCommAck = null;

            // Build S1F13 body with proper L[2] <A MDLN> <A SOFTREV> structure
            byte[] body = SecsIIMessage.S1F13_EstablishCommsReq(
                p.HostMdln    ?? "SecSimPro",
                p.HostSoftrev ?? "2.0");

            var msg = HsmsMessage.BuildDataMessage(
                p.SessionId, 1, 13, true, NextSys(), body);

            Log(LogSeverity.Gem,
                $"GEM: TX → S1F13  body={BitConverter.ToString(body).Replace("-", " ")}");
            TxLog(msg);
            Send(msg.ToBytes());

            // Wait for S1F14 — may be triggered by:
            //   • EQ replying to OUR S1F13 (rx loop sets latch on S1F14)
            //   • EQ sending its OWN S1F13 → we reply S1F14(0) → rx loop sets latch
            bool received = _s1f14Latch.Wait(TimeSpan.FromSeconds(T3_ReplyTimeout));

            if (!received)
            {
                // No S1F14 within T3 — some equipment never sends it but still goes COMMUNICATING
                // when it receives our S1F14 reply to their S1F13.
                // Stay SELECTED and warn rather than failing hard.
                Log(LogSeverity.Warning,
                    $"GEM: No S1F14 received within T3={T3_ReplyTimeout}s. " +
                    "Equipment may not support GEM S1F13/S1F14. " +
                    "Staying in HSMS SELECTED state — functional but not GEM Online.");
                FinalizeSelected(p);
                return;
            }

            byte ack = _inboundCommAck ?? 0xFF;

            if (ack == 0x00)
            {
                _gemOnlineAchieved             = true;
                CurrentConnection.Status       = ConnectionStatus.GemOnline;
                CurrentConnection.ConnectedAt  = DateTime.Now;

                ChangeStatus(ConnectionStatus.GemOnline,
                    "GEM Online ✓  Equipment is in COMMUNICATING state.",
                    LogSeverity.Gem, p.IpAddress, p.Port);

                // Optional: sync clock
                if (p.SendDateTimeOnConnect)
                    SendDateTimeSet(p);
            }
            else
            {
                Log(LogSeverity.Warning,
                    $"GEM: S1F14 COMMACK=0x{ack:X2} — equipment not ready (possibly still initialising). " +
                    "Staying HSMS SELECTED.");
                FinalizeSelected(p);
            }
        }

        private void FinalizeSelected(ConnectionProfile p)
        {
            if (CurrentStatus == ConnectionStatus.Selected ||
                CurrentStatus == ConnectionStatus.TcpConnected)
            {
                CurrentConnection.ConnectedAt = DateTime.Now;
                ChangeStatus(ConnectionStatus.Selected,
                    "HSMS Selected. Communication ready.",
                    LogSeverity.Success, p.IpAddress, p.Port);
            }
        }

        private void SendDateTimeSet(ConnectionProfile p)
        {
            try
            {
                var dt   = DateTime.Now;
                var body = SecsIIMessage.S2F31_DateTimeSet(dt);
                var msg  = HsmsMessage.BuildDataMessage(p.SessionId, 2, 31, true, NextSys(), body);
                Log(LogSeverity.Gem, $"GEM: TX → S2F31 Date/Time Set: {dt:yyyy-MM-dd HH:mm:ss}");
                TxLog(msg);
                Send(msg.ToBytes());
            }
            catch (Exception ex)
            {
                Log(LogSeverity.Warning, $"GEM: S2F31 Date/Time Set failed: {ex.Message}");
            }
        }

        // ─────────────────────────────────────────────────────
        //  RECEIVE LOOP — dedicated background thread
        // ─────────────────────────────────────────────────────
        private void StartRxLoop(CancellationToken token)
        {
            _rxThread = new Thread(() =>
            {
                Log(LogSeverity.Info, "RX thread started.");
                try
                {
                    while (!token.IsCancellationRequested)
                    {
                        // ── Read 4-byte length prefix ─────────
                        byte[] lenBuf = ReadExact(4, token);
                        if (lenBuf == null) break;

                        uint msgLen = (uint)((lenBuf[0] << 24) | (lenBuf[1] << 16)
                                           | (lenBuf[2] << 8)  |  lenBuf[3]);

                        if (msgLen < HsmsMessage.HeaderLength || msgLen > 8 * 1024 * 1024)
                        {
                            Log(LogSeverity.Error,
                                $"RX: Invalid length field {msgLen} — closing connection.");
                            break;
                        }

                        // ── Read 10-byte header + optional data ─
                        byte[] header = ReadExact(HsmsMessage.HeaderLength, token);
                        if (header == null) break;

                        int dataLen = (int)msgLen - HsmsMessage.HeaderLength;
                        byte[] data = dataLen > 0 ? ReadExact(dataLen, token) : new byte[0];
                        if (dataLen > 0 && data == null) break;

                        var msg = HsmsMessage.FromHeader(header, data);
                        Dispatch(msg);
                    }
                }
                catch (OperationCanceledException) { /* clean shutdown */ }
                catch (IOException)                { /* socket closed */ }
                catch (Exception ex)
                {
                    if (!token.IsCancellationRequested)
                        Log(LogSeverity.Error, $"RX error: {ex.Message}");
                }
                finally
                {
                    if (!token.IsCancellationRequested)
                    {
                        Log(LogSeverity.Warning, "RX loop ended — connection dropped.");
                        HandleDropped();
                    }
                    Log(LogSeverity.Info, "RX thread exiting.");
                }
            })
            { IsBackground = true, Name = "HSMS-RX" };

            _rxThread.Start();
        }

        // ─────────────────────────────────────────────────────
        //  MESSAGE DISPATCH
        // ─────────────────────────────────────────────────────
        private void Dispatch(HsmsMessage msg)
        {
            Log(LogSeverity.Hsms, $"RX ← {msg}");

            if (msg.IsControlMessage)
            {
                HandleControl(msg);
            }
            else
            {
                HandleData(msg);
            }
        }

        private void HandleControl(HsmsMessage msg)
        {
            switch (msg.SType)
            {
                case HsmsSType.SelectRsp:
                    _selectStatus = msg.SelectStatus;
                    _selectLatch.Set();
                    break;

                case HsmsSType.SelectReq:
                    // Equipment acting as active end — accept it
                    var srsp = HsmsMessage.BuildSelectRsp(
                        msg.SessionId, msg.SystemBytes, HsmsSelectStatus.Success);
                    Log(LogSeverity.Hsms, $"TX → {srsp}  (replying to EQ Select.req)");
                    Send(srsp.ToBytes());
                    break;

                case HsmsSType.LinktestReq:
                    var lrsp = HsmsMessage.BuildLinktestRsp(msg.SystemBytes);
                    Log(LogSeverity.Hsms, $"TX → {lrsp}");
                    Send(lrsp.ToBytes());
                    break;

                case HsmsSType.LinktestRsp:
                    _linktestFailures = 0;
                    _linktestLatch.Set();
                    break;

                case HsmsSType.SeparateReq:
                    Log(LogSeverity.Warning,
                        "Equipment sent Separate.req — it is ending the HSMS session.");
                    HandleDropped();
                    break;

                default:
                    Log(LogSeverity.Hsms, $"Unhandled control SType={msg.SType}");
                    break;
            }
        }

        private void HandleData(HsmsMessage msg)
        {
            // ── S1F1 — Are You There (EQ polling host) ────────
            if (msg.Stream == 1 && msg.Function == 1)
            {
                var reply = HsmsMessage.BuildDataMessage(
                    CurrentConnection?.SessionId ?? _profile?.SessionId ?? 0,
                    1, 2, false, msg.SystemBytes,
                    SecsIIMessage.S1F2_OnLineData());
                Log(LogSeverity.Gem, $"TX → S1F2  (replying to EQ S1F1 Are You There)");
                TxLog(reply);
                Send(reply.ToBytes());
                return;
            }

            // ── S1F13 — Equipment-initiated Establish Comms ───
            //
            // This is the KEY path for many simulators:
            // EQ sends S1F13 to host → host MUST reply S1F14(COMMACK=0)
            // This is what drives the EQ from ENABLED → COMMUNICATING.
            //
            if (msg.Stream == 1 && msg.Function == 13)
            {
                var (mdln, softrev) = SecsIIMessage.ParseMdlnSoftrev(msg.Data);
                Log(LogSeverity.Gem,
                    $"GEM: Equipment sent S1F13 Establish Comms " +
                    $"(MDLN='{mdln ?? ""}' SOFTREV='{softrev ?? ""}')");
                Log(LogSeverity.Gem,
                    "GEM: Replying S1F14 COMMACK=0 (Accepted) → EQ should enter COMMUNICATING...");

                var ackBody = SecsIIMessage.S1F14_EstablishCommsAck(
                    0x00,
                    _profile?.HostMdln    ?? "SecSimPro",
                    _profile?.HostSoftrev ?? "2.0");

                // Reply must use same SystemBytes as the request (transaction ID)
                var reply = HsmsMessage.BuildDataMessage(
                    msg.SessionId, 1, 14, false, msg.SystemBytes, ackBody);

                Log(LogSeverity.Gem,
                    $"TX → S1F14 COMMACK=0  body={BitConverter.ToString(ackBody).Replace("-", " ")}");
                TxLog(reply);
                Send(reply.ToBytes());

                // Signal the GEM handshake thread that we've achieved comms
                _inboundCommAck = 0x00;
                _s1f14Latch.Set();

                // If we're already in GEM Online from a previous path, just log
                if (!_gemOnlineAchieved)
                {
                    _gemOnlineAchieved            = true;
                    CurrentConnection.Status      = ConnectionStatus.GemOnline;
                    CurrentConnection.ConnectedAt = DateTime.Now;

                    ChangeStatus(ConnectionStatus.GemOnline,
                        "GEM Online ✓  Equipment sent S1F13 and accepted our S1F14(COMMACK=0). " +
                        "Equipment should now be in COMMUNICATING state.",
                        LogSeverity.Gem,
                        CurrentConnection.IpAddress, CurrentConnection.Port);

                    if (_profile?.SendDateTimeOnConnect == true)
                        SendDateTimeSet(_profile);
                }
                return;
            }

            // ── S1F14 — Equipment's reply to our S1F13 ────────
            if (msg.Stream == 1 && msg.Function == 14)
            {
                byte? ack = SecsIIMessage.ParseS1F14CommAck(msg.Data);
                Log(LogSeverity.Gem,
                    $"GEM: Received S1F14 — COMMACK=0x{(ack.HasValue ? ack.Value.ToString("X2") : "??")}  " +
                    $"raw={BitConverter.ToString(msg.Data).Replace("-", " ")}");

                _inboundCommAck = ack;
                _s1f14Latch.Set();
                return;
            }

            // ── S1F2 — On-Line Data (reply to our S1F1) ───────
            if (msg.Stream == 1 && msg.Function == 2)
            {
                Log(LogSeverity.Gem, "GEM: S1F2 On-Line Data received — equipment online.");
                return;
            }

            // ── S1F15 / S1F16 — Off-Line Request / Ack ────────
            if (msg.Stream == 1 && msg.Function == 15)
            {
                Log(LogSeverity.Warning,
                    "GEM: Equipment sent S1F15 Request OFF-LINE. Acknowledging.");
                var ack = HsmsMessage.BuildDataMessage(
                    msg.SessionId, 1, 16, false, msg.SystemBytes, new byte[0]);
                Send(ack.ToBytes());
                return;
            }

            // ── S2F17 — Date/Time Request from equipment ──────
            if (msg.Stream == 2 && msg.Function == 17)
            {
                Log(LogSeverity.Gem, "GEM: Equipment requested date/time (S2F17). Sending S2F18...");
                var dtBody = SecsIIMessage.S2F18_DateTimeData(DateTime.Now);
                var dtMsg  = HsmsMessage.BuildDataMessage(
                    msg.SessionId, 2, 18, false, msg.SystemBytes, dtBody);
                TxLog(dtMsg);
                Send(dtMsg.ToBytes());
                return;
            }

            // ── S9 — SECS-II error stream ──────────────────────
            if (msg.Stream == 9)
            {
                string errName = GetS9Description(msg.Function);
                Log(LogSeverity.Warning,
                    $"SECS-II Error: S9F{msg.Function} {errName} received from equipment.");
                return;
            }

            // ── Unhandled — log raw bytes ──────────────────────
            Log(LogSeverity.Info,
                $"Data S{msg.Stream}F{msg.Function} received " +
                $"(not handled — {msg.Data.Length} data bytes).");
        }

        // ─────────────────────────────────────────────────────
        //  LINKTEST TIMER
        // ─────────────────────────────────────────────────────
        private int _linktestFailures;

        private void StartLinktestTimer(CancellationToken token)
        {
            _linktestThread = new Thread(() =>
            {
                Log(LogSeverity.Hsms,
                    $"Linktest timer started — interval={_linktestIntervalSec}s, T6={T6_ControlTimeout}s.");

                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        // Sleep in 100ms slices so we can respond to cancellation quickly
                        for (int i = 0; i < _linktestIntervalSec * 10; i++)
                        {
                            if (token.IsCancellationRequested) return;
                            Thread.Sleep(100);
                        }

                        if (token.IsCancellationRequested) return;

                        _linktestLatch.Reset();
                        var req = HsmsMessage.BuildLinktestReq(NextSys());
                        TxLog(req);
                        Send(req.ToBytes());

                        if (!_linktestLatch.Wait(TimeSpan.FromSeconds(T6_ControlTimeout)))
                        {
                            _linktestFailures++;
                            Log(LogSeverity.Warning,
                                $"Linktest.rsp timeout (failure {_linktestFailures}/2, T6={T6_ControlTimeout}s).");
                            if (_linktestFailures >= 2)
                            {
                                Log(LogSeverity.Error,
                                    "Two consecutive linktest failures — declaring connection lost.");
                                HandleDropped();
                                return;
                            }
                        }
                        else
                        {
                            _linktestFailures = 0;
                            Log(LogSeverity.Hsms, "Linktest ✓");
                        }
                    }
                    catch (OperationCanceledException) { return; }
                    catch                              { return; }
                }
            })
            { IsBackground = true, Name = "HSMS-Linktest" };

            _linktestThread.Start();
        }

        // ─────────────────────────────────────────────────────
        //  PUBLIC: Disconnect
        // ─────────────────────────────────────────────────────
        public void Disconnect()
        {
            try
            {
                string ip   = CurrentConnection?.IpAddress ?? "";
                int    port = CurrentConnection?.Port      ?? 0;

                // Graceful: send Separate.req
                if (_stream != null &&
                    (CurrentStatus == ConnectionStatus.Selected ||
                     CurrentStatus == ConnectionStatus.GemOnline))
                {
                    try
                    {
                        var sep = HsmsMessage.BuildSeparateReq(
                            CurrentConnection?.SessionId ?? 0, NextSys());
                        TxLog(sep);
                        Send(sep.ToBytes());
                        Thread.Sleep(150);
                    }
                    catch { /* best-effort */ }
                }

                Cleanup();

                if (CurrentConnection != null)
                {
                    CurrentConnection.Status         = ConnectionStatus.Disconnected;
                    CurrentConnection.DisconnectedAt = DateTime.Now;
                }

                ChangeStatus(ConnectionStatus.Disconnected,
                    $"Disconnected from {ip}:{port}.",
                    LogSeverity.Warning, ip, port);
            }
            catch (Exception ex)
            {
                Log(LogSeverity.Error, $"Disconnect error: {ex.Message}");
            }
        }

        // ─────────────────────────────────────────────────────
        //  INTERNAL HELPERS
        // ─────────────────────────────────────────────────────

        private void HandleDropped()
        {
            if (CurrentStatus == ConnectionStatus.Disconnected) return;

            string ip   = CurrentConnection?.IpAddress ?? "";
            int    port = CurrentConnection?.Port      ?? 0;

            Cleanup();

            if (CurrentConnection != null)
                CurrentConnection.Status = ConnectionStatus.Error;

            ChangeStatus(ConnectionStatus.Error,
                "Connection lost — equipment closed the session or network failure.",
                LogSeverity.Error, ip, port);
        }

        private void Cleanup()
        {
            _cts?.Cancel();
            try { _stream?.Close();  } catch { }
            try { _tcp?.Close();     } catch { }
            _stream = null;
            _tcp    = null;
        }

        private byte[] ReadExact(int count, CancellationToken token)
        {
            var buf      = new byte[count];
            int received = 0;

            while (received < count)
            {
                if (token.IsCancellationRequested) return null;
                int n;
                try
                {
                    n = _stream.Read(buf, received, count - received);
                }
                catch (IOException ex)
                    when (ex.InnerException is SocketException sx &&
                          sx.SocketErrorCode == SocketError.TimedOut)
                {
                    // Read timeout — loop back and check cancellation
                    continue;
                }
                if (n == 0) return null;   // graceful close
                received += n;
            }
            return buf;
        }

        private void Send(byte[] data)
        {
            lock (_txLock)
            {
                _stream?.Write(data, 0, data.Length);
            }
        }

        private void TxLog(HsmsMessage msg) =>
            Log(LogSeverity.Hsms, $"TX → {msg}");

        private uint NextSys() => _sysCtr++;

        private void ChangeStatus(ConnectionStatus st, string msg, LogSeverity sev,
                                   string ip = "", int port = 0)
        {
            CurrentStatus = st;
            ConnectionStatusChanged?.Invoke(this,
                new ConnectionEventArgs(st, msg, sev, ip, port));
        }

        private void Log(LogSeverity sev, string msg) =>
            LogMessage?.Invoke(this,
                new ConnectionEventArgs(CurrentStatus, msg, sev));

        private void Fail(string msg, ConnectionProfile p)
        {
            Cleanup();
            if (CurrentConnection != null)
                CurrentConnection.Status = ConnectionStatus.Error;
            ChangeStatus(ConnectionStatus.Error, msg,
                LogSeverity.Error, p?.IpAddress ?? "", p?.Port ?? 0);
        }

        private static string SockMsg(SocketError e)
        {
            switch (e)
            {
                case SocketError.ConnectionRefused:  return "Refused — check IP/port.";
                case SocketError.HostUnreachable:
                case SocketError.HostNotFound:       return "Host not found/unreachable.";
                case SocketError.NetworkUnreachable: return "Network unreachable.";
                case SocketError.TimedOut:           return "Timed out — equipment offline?";
                default:                              return e.ToString();
            }
        }

        private static string GetS9Description(byte func)
        {
            switch (func)
            {
                case 1:  return "(Unrecognised Device ID)";
                case 3:  return "(Unrecognised Stream)";
                case 5:  return "(Unrecognised Function)";
                case 7:  return "(Illegal Data)";
                case 9:  return "(Transaction Timer Timeout)";
                case 11: return "(Data Too Long)";
                case 13: return "(Conversation Timeout)";
                default: return "";
            }
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                Cleanup();
                _disposed = true;
            }
        }
    }
}
