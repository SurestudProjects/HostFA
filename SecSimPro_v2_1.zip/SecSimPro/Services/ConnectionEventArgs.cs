using System;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  Connection status — drives UI colour, buttons, and title bar
    // ─────────────────────────────────────────────────────────────────────────
    public enum ConnectionStatus
    {
        Disconnected,   // No TCP socket
        Connecting,     // TCP SYN sent, waiting for ACK
        TcpConnected,   // TCP up, HSMS Select not yet done
        Selected,       // HSMS Selected (session active, T8 linktest running)
        GemOnline,      // GEM S1F13 Establish-Communications accepted
        Error           // Any failure — socket dropped, timeout, reject, etc.
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Log severity — finer-grained than status for the activity log
    // ─────────────────────────────────────────────────────────────────────────
    public enum LogSeverity { Info, Success, Warning, Error, Hsms, Gem }

    // ─────────────────────────────────────────────────────────────────────────
    //  Event payload used by both ConnectionStatusChanged and LogMessage events
    // ─────────────────────────────────────────────────────────────────────────
    public class ConnectionEventArgs : EventArgs
    {
        public ConnectionStatus Status    { get; set; }
        public string           Message   { get; set; }
        public LogSeverity      Severity  { get; set; }
        public DateTime         Timestamp { get; set; }
        public string           IpAddress { get; set; }
        public int              Port      { get; set; }

        public ConnectionEventArgs(ConnectionStatus status, string message,
                                   LogSeverity severity = LogSeverity.Info,
                                   string ip = "", int port = 0)
        {
            Status    = status;
            Message   = message;
            Severity  = severity;
            Timestamp = DateTime.Now;
            IpAddress = ip;
            Port      = port;
        }
    }
}
