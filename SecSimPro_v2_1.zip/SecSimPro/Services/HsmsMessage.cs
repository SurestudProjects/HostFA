using System;

namespace SecSimPro.Services
{
    // ─────────────────────────────────────────────────────────────────────────
    //  HSMS SType  (SEMI E37 §8.3.4)
    // ─────────────────────────────────────────────────────────────────────────
    public enum HsmsSType : byte
    {
        DataMessage  = 0,
        SelectReq    = 1,
        SelectRsp    = 2,
        DeselectReq  = 3,
        DeselectRsp  = 4,
        LinktestReq  = 5,
        LinktestRsp  = 6,
        RejectReq    = 7,
        SeparateReq  = 9
    }

    public enum HsmsSelectStatus : byte
    {
        Success             = 0,
        AlreadyActive       = 1,
        ConnectionNotReady  = 2,
        EntityNotSupported  = 3
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HsmsMessage
    //
    //  Wire layout (all big-endian):
    //   [0-3]   Length prefix  (uint32) = 10 + data bytes
    //   [4-5]   Session ID     (uint16)
    //   [6]     Byte6  — data: 0x80|Stream ; control: 0x00
    //   [7]     Byte7  — data: Function    ; control rsp: status byte
    //   [8]     P-Type (always 0x00)
    //   [9]     S-Type (HsmsSType)
    //   [10-13] System Bytes   (uint32, transaction ID)
    //   [14+]   Data body (data messages only)
    // ─────────────────────────────────────────────────────────────────────────
    public class HsmsMessage
    {
        public const int HeaderLength = 10;

        public ushort    SessionId   { get; private set; }
        public byte      Byte6       { get; private set; }
        public byte      Byte7       { get; private set; }
        public byte      PType       { get; private set; }
        public HsmsSType SType       { get; private set; }
        public uint      SystemBytes { get; private set; }
        public byte[]    Data        { get; private set; }

        public bool IsControlMessage     => SType != HsmsSType.DataMessage;
        public bool IsDataMessage        => SType == HsmsSType.DataMessage;
        public HsmsSelectStatus SelectStatus => (HsmsSelectStatus)Byte7;
        public byte Stream   => (byte)(Byte6 & 0x7F);
        public byte Function => Byte7;
        public bool ReplyBit => (Byte6 & 0x80) != 0;

        private HsmsMessage() { }

        // ── Control message factories ─────────────────────────

        public static HsmsMessage BuildSelectReq(ushort sessionId, uint systemBytes)
            => Control(sessionId, 0, 0, HsmsSType.SelectReq, systemBytes);

        public static HsmsMessage BuildSelectRsp(ushort sessionId, uint systemBytes, HsmsSelectStatus status)
            => Control(sessionId, 0, (byte)status, HsmsSType.SelectRsp, systemBytes);

        public static HsmsMessage BuildLinktestReq(uint systemBytes)
            => Control(0xFFFF, 0, 0, HsmsSType.LinktestReq, systemBytes);

        public static HsmsMessage BuildLinktestRsp(uint systemBytes)
            => Control(0xFFFF, 0, 0, HsmsSType.LinktestRsp, systemBytes);

        public static HsmsMessage BuildSeparateReq(ushort sessionId, uint systemBytes)
            => Control(sessionId, 0, 0, HsmsSType.SeparateReq, systemBytes);

        private static HsmsMessage Control(ushort sid, byte b6, byte b7, HsmsSType st, uint sys)
            => new HsmsMessage { SessionId = sid, Byte6 = b6, Byte7 = b7, PType = 0,
                                 SType = st, SystemBytes = sys, Data = new byte[0] };

        // ── Data (SECS-II) message factory ────────────────────

        public static HsmsMessage BuildDataMessage(ushort sessionId, byte stream, byte func,
                                                   bool replyReq, uint systemBytes, byte[] body = null)
            => new HsmsMessage
            {
                SessionId   = sessionId,
                Byte6       = (byte)((replyReq ? 0x80 : 0x00) | (stream & 0x7F)),
                Byte7       = func,
                PType       = 0,
                SType       = HsmsSType.DataMessage,
                SystemBytes = systemBytes,
                Data        = body ?? new byte[0]
            };

        // ── Encode ────────────────────────────────────────────

        public byte[] ToBytes()
        {
            int  dataLen = Data?.Length ?? 0;
            uint msgLen  = (uint)(HeaderLength + dataLen);
            var  frame   = new byte[4 + msgLen];
            int  i       = 0;

            frame[i++] = (byte)(msgLen >> 24); frame[i++] = (byte)(msgLen >> 16);
            frame[i++] = (byte)(msgLen >> 8);  frame[i++] = (byte)(msgLen);

            frame[i++] = (byte)(SessionId >> 8); frame[i++] = (byte)SessionId;
            frame[i++] = Byte6; frame[i++] = Byte7; frame[i++] = PType; frame[i++] = (byte)SType;

            frame[i++] = (byte)(SystemBytes >> 24); frame[i++] = (byte)(SystemBytes >> 16);
            frame[i++] = (byte)(SystemBytes >> 8);  frame[i++] = (byte)SystemBytes;

            if (dataLen > 0) Array.Copy(Data, 0, frame, i, dataLen);
            return frame;
        }

        // ── Decode ────────────────────────────────────────────

        public static HsmsMessage FromHeader(byte[] header, byte[] data)
        {
            if (header == null || header.Length < HeaderLength)
                throw new ArgumentException("Header must be 10 bytes.");

            return new HsmsMessage
            {
                SessionId   = (ushort)((header[0] << 8) | header[1]),
                Byte6       = header[2],
                Byte7       = header[3],
                PType       = header[4],
                SType       = (HsmsSType)header[5],
                SystemBytes = (uint)((header[6] << 24) | (header[7] << 16)
                                   | (header[8] << 8)  |  header[9]),
                Data        = data ?? new byte[0]
            };
        }

        public override string ToString()
        {
            return IsDataMessage
                ? $"[Data] S{Stream}F{Function} R={ReplyBit} Sess=0x{SessionId:X4} Sys=0x{SystemBytes:X8} Len={Data?.Length ?? 0}"
                : $"[{SType}] Sess=0x{SessionId:X4} Sys=0x{SystemBytes:X8}";
        }
    }
}
