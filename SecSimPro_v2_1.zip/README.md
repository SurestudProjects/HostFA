# SecSimPro v2.0 — HSMS + GEM Equipment Connection Manager
### .NET 4.6 WinForms  ·  SEMI E37 (HSMS) + SEMI E30 (GEM)

## Connection Sequence

```
[1] TCP Connect
[2] HSMS Select.req → Select.rsp (must match Session ID)
[3] HSMS SELECTED   (Linktest timer starts)
[4] S1F13 → S1F14 COMMACK=0   (if UseGem enabled)
[5] GEM ONLINE ✓
```

## Connection Dialog Fields

| Field | Notes |
|-------|-------|
| IP Address | Equipment hostname or IPv4 |
| Port | Default 5000 for HSMS |
| Session ID | HSMS Device ID — must match equipment (0–65535) |
| Linktest Interval | Seconds between keepalive messages (default 15s) |
| Use GEM (S1F13) | Establish Communications after Select |

## Status Colours: Grey=Off · Orange=Connecting · Blue=TCP · DimGreen=Selected · BrightGreen=GEM · Red=Error

## Log Prefixes: [INFO] [OK] [WARN] [ERR] [HSMS] [GEM]

## Build
Open SecSimPro.sln in Visual Studio 2017/2019/2022. Press F5. No NuGet packages needed (.NET 4.6 only).
