using System;
using System.Net;
using System.Windows.Forms;
using SecSimPro.Models;

namespace SecSimPro.Forms
{
    public partial class ConnectionForm : Form
    {
        public ConnectionProfile ResultProfile { get; private set; }

        private ConnectionProfileList _profileList;
        private bool _isEditing = false;

        public ConnectionForm(ConnectionProfile existingProfile = null)
        {
            InitializeComponent();
            _profileList = ConnectionProfileList.Load();

            LoadProfiles();

            if (existingProfile != null)
            {
                _isEditing = true;
                PopulateFromProfile(existingProfile);
                this.Text = "Edit Connection";
                btnConnect.Text = "Update & Connect";
            }
        }

        private void LoadProfiles()
        {
            cmbSavedProfiles.Items.Clear();
            cmbSavedProfiles.Items.Add("-- New Connection --");
            foreach (var p in _profileList.Profiles)
                cmbSavedProfiles.Items.Add(p.ProfileName);
            cmbSavedProfiles.SelectedIndex = 0;
        }

        private void PopulateFromProfile(ConnectionProfile p)
        {
            txtProfileName.Text = p.ProfileName;
            txtIpAddress.Text = p.IpAddress;
            numPort.Value = p.Port;
            txtDescription.Text = p.Description;
            numTimeout.Value = p.TimeoutSeconds;
            chkAutoReconnect.Checked = p.AutoReconnect;
        }

        private void cmbSavedProfiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = cmbSavedProfiles.SelectedIndex;
            if (idx <= 0) return;

            var profile = _profileList.Profiles[idx - 1];
            PopulateFromProfile(profile);
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            ResultProfile = BuildProfile();

            // Save profile if name is provided
            if (!string.IsNullOrWhiteSpace(txtProfileName.Text))
            {
                var existing = _profileList.Profiles.Find(
                    p => p.ProfileName.Equals(txtProfileName.Text.Trim(), StringComparison.OrdinalIgnoreCase));

                if (existing != null)
                    _profileList.Profiles.Remove(existing);

                _profileList.Profiles.Add(ResultProfile);
                _profileList.Save();
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnDeleteProfile_Click(object sender, EventArgs e)
        {
            int idx = cmbSavedProfiles.SelectedIndex;
            if (idx <= 0)
            {
                MessageBox.Show("Please select a saved profile to delete.",
                    "No Profile Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var profile = _profileList.Profiles[idx - 1];
            var result = MessageBox.Show(
                $"Delete profile '{profile.ProfileName}'?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                _profileList.Profiles.RemoveAt(idx - 1);
                _profileList.Save();
                LoadProfiles();
                ClearFields();
            }
        }

        private void ClearFields()
        {
            txtProfileName.Clear();
            txtIpAddress.Clear();
            numPort.Value = 102;
            txtDescription.Clear();
            numTimeout.Value = 10;
            chkAutoReconnect.Checked = false;
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtIpAddress.Text))
            {
                ShowError("IP Address is required.", txtIpAddress);
                return false;
            }

            if (!IsValidIpOrHostname(txtIpAddress.Text.Trim()))
            {
                ShowError("Please enter a valid IP address or hostname.", txtIpAddress);
                return false;
            }

            if (numPort.Value < 1 || numPort.Value > 65535)
            {
                ShowError("Port must be between 1 and 65535.", numPort);
                return false;
            }

            return true;
        }

        private bool IsValidIpOrHostname(string value)
        {
            IPAddress addr;
            if (IPAddress.TryParse(value, out addr)) return true;
            // Allow hostnames too
            return value.Length > 0 && value.Length <= 255;
        }

        private void ShowError(string message, Control control)
        {
            MessageBox.Show(message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            control.Focus();
        }

        private ConnectionProfile BuildProfile()
        {
            return new ConnectionProfile
            {
                ProfileName = string.IsNullOrWhiteSpace(txtProfileName.Text)
                    ? $"{txtIpAddress.Text.Trim()}:{(int)numPort.Value}"
                    : txtProfileName.Text.Trim(),
                IpAddress = txtIpAddress.Text.Trim(),
                Port = (int)numPort.Value,
                Description = txtDescription.Text.Trim(),
                TimeoutSeconds = (int)numTimeout.Value,
                AutoReconnect = chkAutoReconnect.Checked
            };
        }

        private void txtIpAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow digits, dots, letters (for hostnames), backspace, dash
            if (!char.IsControl(e.KeyChar) && !char.IsLetterOrDigit(e.KeyChar)
                && e.KeyChar != '.' && e.KeyChar != '-')
            {
                e.Handled = true;
            }
        }
    }
}
