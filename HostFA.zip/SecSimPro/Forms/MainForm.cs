using System;
using System.Drawing;
using System.Windows.Forms;
using SecSimPro.Models;
using SecSimPro.Services;

namespace SecSimPro.Forms
{
    public partial class MainForm : Form
    {
        private TcpConnectionService _connectionService;
        private ConnectionProfile _currentProfile;

        public MainForm()
        {
            InitializeComponent();
            _connectionService = new TcpConnectionService();
            _connectionService.ConnectionStatusChanged += OnConnectionStatusChanged;
            _connectionService.LogMessage += OnLogMessage;

            SetDisconnectedState();
            AppendLog("SecSimPro Equipment Manager started.", LogLevel.Info);
            AppendLog("Ready. Use File > Connect or press Ctrl+N to connect to equipment.", LogLevel.Info);
        }

        // ─────────────────────────────────────────────────
        //  Connection Actions
        // ─────────────────────────────────────────────────

        private void ShowConnectDialog()
        {
            using (var dlg = new ConnectionForm(_currentProfile))
            {
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    _currentProfile = dlg.ResultProfile;
                    AppendLog($"Initiating connection to {_currentProfile.IpAddress}:{_currentProfile.Port}...", LogLevel.Info);
                    _connectionService.Connect(_currentProfile);
                }
            }
        }

        private void ConfirmAndDisconnect()
        {
            var conn = _connectionService.CurrentConnection;
            string target = conn != null ? $" from {conn.IpAddress}:{conn.Port}" : "";

            var result = MessageBox.Show(
                $"Are you sure you want to disconnect{target}?",
                "Confirm Disconnect",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                AppendLog($"User initiated disconnect{target}.", LogLevel.Info);
                _connectionService.Disconnect();
            }
        }

        // ─────────────────────────────────────────────────
        //  Event Handlers from Service (cross-thread safe)
        // ─────────────────────────────────────────────────

        private void OnConnectionStatusChanged(object sender, ConnectionEventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => OnConnectionStatusChanged(sender, e)));
                return;
            }

            switch (e.Status)
            {
                case ConnectionStatus.Connecting:
                    SetConnectingState(e.IpAddress, e.Port);
                    AppendLog(e.Message, LogLevel.Info);
                    break;

                case ConnectionStatus.Connected:
                    SetConnectedState(e.IpAddress, e.Port);
                    AppendLog(e.Message, LogLevel.Success);
                    break;

                case ConnectionStatus.Disconnected:
                    SetDisconnectedState();
                    AppendLog(e.Message, LogLevel.Warning);
                    break;

                case ConnectionStatus.Error:
                    SetErrorState();
                    AppendLog(e.Message, LogLevel.Error);
                    break;
            }
        }

        private void OnLogMessage(object sender, ConnectionEventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => OnLogMessage(sender, e)));
                return;
            }
            AppendLog(e.Message, e.Status == ConnectionStatus.Error ? LogLevel.Error : LogLevel.Info);
        }

        // ─────────────────────────────────────────────────
        //  UI State Management
        // ─────────────────────────────────────────────────

        private void SetConnectingState(string ip, int port)
        {
            btnConnect.Enabled = false;
            btnDisconnect.Enabled = false;
            menuConnect.Enabled = false;
            menuDisconnect.Enabled = false;

            lblStatusValue.Text = "Connecting...";
            lblStatusValue.ForeColor = Color.FromArgb(180, 120, 0);

            lblEquipmentValue.Text = $"{ip}:{port}";
            lblConnectedAtValue.Text = "--:--:--";
            lblDurationValue.Text = "---";

            picStatus.BackColor = Color.FromArgb(255, 165, 0);
            statusStrip1.BackColor = Color.FromArgb(255, 248, 220);
            toolStripStatusLabel.Text = $"Connecting to {ip}:{port}...";

            tmrConnected.Stop();
            tmrConnected.Tag = null;

            this.Text = "SecSimPro - Connecting...";
        }

        private void SetConnectedState(string ip, int port)
        {
            btnConnect.Enabled = false;
            btnDisconnect.Enabled = true;
            menuConnect.Enabled = false;
            menuDisconnect.Enabled = true;

            lblStatusValue.Text = "Connected";
            lblStatusValue.ForeColor = Color.FromArgb(0, 140, 70);

            lblEquipmentValue.Text = _connectionService.CurrentConnection?.DisplayName ?? $"{ip}:{port}";
            lblConnectedAtValue.Text = DateTime.Now.ToString("HH:mm:ss");

            picStatus.BackColor = Color.FromArgb(0, 180, 90);
            statusStrip1.BackColor = Color.FromArgb(220, 255, 235);
            toolStripStatusLabel.Text = $"Connected to {ip}:{port}";

            tmrConnected.Tag = DateTime.Now;
            tmrConnected.Start();

            this.Text = $"SecSimPro - Connected [{ip}:{port}]";
        }

        private void SetDisconnectedState()
        {
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
            menuConnect.Enabled = true;
            menuDisconnect.Enabled = false;

            lblStatusValue.Text = "Disconnected";
            lblStatusValue.ForeColor = Color.FromArgb(120, 120, 120);
            lblEquipmentValue.Text = "---";
            lblConnectedAtValue.Text = "---";
            lblDurationValue.Text = "---";

            picStatus.BackColor = Color.FromArgb(180, 180, 180);
            statusStrip1.BackColor = SystemColors.Control;
            toolStripStatusLabel.Text = "Not connected";

            tmrConnected.Stop();
            tmrConnected.Tag = null;

            this.Text = "SecSimPro - Equipment Manager";
        }

        private void SetErrorState()
        {
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
            menuConnect.Enabled = true;
            menuDisconnect.Enabled = false;

            lblStatusValue.Text = "Error";
            lblStatusValue.ForeColor = Color.FromArgb(180, 0, 0);
            lblEquipmentValue.Text = "---";
            lblConnectedAtValue.Text = "---";
            lblDurationValue.Text = "---";

            picStatus.BackColor = Color.FromArgb(200, 0, 0);
            statusStrip1.BackColor = Color.FromArgb(255, 235, 235);
            toolStripStatusLabel.Text = "Connection error";

            tmrConnected.Stop();
            tmrConnected.Tag = null;

            this.Text = "SecSimPro - Connection Error";
        }

        // ─────────────────────────────────────────────────
        //  Timer — Connected Duration
        // ─────────────────────────────────────────────────

        private void tmrConnected_Tick(object sender, EventArgs e)
        {
            if (tmrConnected.Tag is DateTime startTime)
            {
                var elapsed = DateTime.Now - startTime;
                lblDurationValue.Text = elapsed.ToString(@"hh\:mm\:ss");
            }
        }

        // ─────────────────────────────────────────────────
        //  Log Panel
        // ─────────────────────────────────────────────────

        private enum LogLevel { Info, Success, Warning, Error }

        private void AppendLog(string message, LogLevel level)
        {
            string timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
            string prefix = "";
            Color color;

            switch (level)
            {
                case LogLevel.Success:  prefix = "[ OK ]"; color = Color.FromArgb(0, 140, 60);   break;
                case LogLevel.Warning:  prefix = "[WARN]"; color = Color.FromArgb(160, 100, 0);  break;
                case LogLevel.Error:    prefix = "[ERR ]"; color = Color.DarkRed;                 break;
                default:                prefix = "[INFO]"; color = Color.FromArgb(40, 40, 80);    break;
            }

            rtbLog.SelectionStart = rtbLog.TextLength;
            rtbLog.SelectionLength = 0;

            // Timestamp
            rtbLog.SelectionColor = Color.FromArgb(120, 120, 140);
            rtbLog.AppendText($"{timestamp} ");

            // Prefix
            rtbLog.SelectionColor = color;
            rtbLog.AppendText($"{prefix} ");

            // Message
            rtbLog.SelectionColor = Color.FromArgb(30, 30, 30);
            rtbLog.AppendText($"{message}{Environment.NewLine}");

            rtbLog.SelectionStart = rtbLog.TextLength;
            rtbLog.ScrollToCaret();
        }

        // ─────────────────────────────────────────────────
        //  Menu / Button Handlers
        // ─────────────────────────────────────────────────

        private void menuConnect_Click(object sender, EventArgs e) => ShowConnectDialog();
        private void btnConnect_Click(object sender, EventArgs e) => ShowConnectDialog();
        private void menuDisconnect_Click(object sender, EventArgs e) => ConfirmAndDisconnect();
        private void btnDisconnect_Click(object sender, EventArgs e) => ConfirmAndDisconnect();

        private void menuClearLog_Click(object sender, EventArgs e)
        {
            rtbLog.Clear();
            AppendLog("Log cleared.", LogLevel.Info);
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            if (_connectionService.IsConnected)
            {
                var result = MessageBox.Show(
                    "You are currently connected to equipment.\nDisconnect and exit?",
                    "Confirm Exit",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (result != DialogResult.Yes) return;
                _connectionService.Disconnect();
            }
            Application.Exit();
        }

        private void menuAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "SecSimPro Equipment Manager\nVersion 1.0.0\n\n" +
                "A SECS/GEM-style equipment connection manager.\n" +
                "Supports TCP/IP connection to manufacturing equipment.",
                "About SecSimPro",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_connectionService.IsConnected)
            {
                var result = MessageBox.Show(
                    "You are connected to equipment. Disconnect and exit?",
                    "Confirm Exit",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2);

                if (result != DialogResult.Yes)
                {
                    e.Cancel = true;
                    return;
                }

                _connectionService.Disconnect();
            }

            _connectionService?.Dispose();
            base.OnFormClosing(e);
        }
    }
}
