namespace SecSimPro.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            // ── Controls ──────────────────────────────
            this.menuStrip1        = new System.Windows.Forms.MenuStrip();
            this.menuFile          = new System.Windows.Forms.ToolStripMenuItem();
            this.menuConnect       = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDisconnect    = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSep1     = new System.Windows.Forms.ToolStripSeparator();
            this.menuClearLog      = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSep2     = new System.Windows.Forms.ToolStripSeparator();
            this.menuExit          = new System.Windows.Forms.ToolStripMenuItem();
            this.menuHelp          = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAbout         = new System.Windows.Forms.ToolStripMenuItem();

            this.toolStrip1        = new System.Windows.Forms.ToolStrip();
            this.btnConnect        = new System.Windows.Forms.ToolStripButton();
            this.btnDisconnect     = new System.Windows.Forms.ToolStripButton();
            this.toolStripSep3     = new System.Windows.Forms.ToolStripSeparator();

            this.pnlHeader         = new System.Windows.Forms.Panel();
            this.lblTitle          = new System.Windows.Forms.Label();
            this.lblSubtitle       = new System.Windows.Forms.Label();
            this.picLogo           = new System.Windows.Forms.PictureBox();

            this.splitContainer1   = new System.Windows.Forms.SplitContainer();

            // ── Status Panel (left pane) ─────────────
            this.pnlStatusCard     = new System.Windows.Forms.Panel();
            this.grpStatus         = new System.Windows.Forms.GroupBox();
            this.tableStatus       = new System.Windows.Forms.TableLayoutPanel();
            this.lblStatusLbl      = new System.Windows.Forms.Label();
            this.lblStatusValue    = new System.Windows.Forms.Label();
            this.lblEquipmentLbl   = new System.Windows.Forms.Label();
            this.lblEquipmentValue = new System.Windows.Forms.Label();
            this.lblConnectedAtLbl = new System.Windows.Forms.Label();
            this.lblConnectedAtValue = new System.Windows.Forms.Label();
            this.lblDurationLbl    = new System.Windows.Forms.Label();
            this.lblDurationValue  = new System.Windows.Forms.Label();
            this.picStatus         = new System.Windows.Forms.PictureBox();
            this.pnlConnectBtn     = new System.Windows.Forms.Panel();
            this.btnConnectLarge   = new System.Windows.Forms.Button();
            this.btnDisconnectLarge = new System.Windows.Forms.Button();

            // ── Log Panel (right pane) ────────────────
            this.grpLog            = new System.Windows.Forms.GroupBox();
            this.rtbLog            = new System.Windows.Forms.RichTextBox();

            this.statusStrip1      = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripVersion  = new System.Windows.Forms.ToolStripStatusLabel();

            this.tmrConnected      = new System.Windows.Forms.Timer(this.components);

            // ── Suspend ───────────────────────────────
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.pnlStatusCard.SuspendLayout();
            this.grpStatus.SuspendLayout();
            this.tableStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStatus)).BeginInit();
            this.pnlConnectBtn.SuspendLayout();
            this.grpLog.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();

            // ═══════════════════════════════════════════
            //  MENU STRIP
            // ═══════════════════════════════════════════
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.menuFile, this.menuHelp });
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(900, 24);
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(30, 40, 60);
            this.menuStrip1.ForeColor = System.Drawing.Color.White;
            this.menuStrip1.Renderer = new DarkMenuRenderer();

            this.menuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.menuConnect, this.menuDisconnect,
                this.toolStripSep1, this.menuClearLog,
                this.toolStripSep2, this.menuExit });
            this.menuFile.ForeColor = System.Drawing.Color.White;
            this.menuFile.Name = "menuFile";
            this.menuFile.Text = "&File";

            this.menuConnect.Name = "menuConnect";
            this.menuConnect.Text = "&Connect to Equipment...";
            this.menuConnect.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N;
            this.menuConnect.Click += new System.EventHandler(this.menuConnect_Click);
            this.menuConnect.Image = CreateCircleIcon(System.Drawing.Color.FromArgb(0, 180, 90), 12);

            this.menuDisconnect.Name = "menuDisconnect";
            this.menuDisconnect.Text = "&Disconnect";
            this.menuDisconnect.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D;
            this.menuDisconnect.Enabled = false;
            this.menuDisconnect.Click += new System.EventHandler(this.menuDisconnect_Click);
            this.menuDisconnect.Image = CreateCircleIcon(System.Drawing.Color.FromArgb(180, 60, 60), 12);

            this.menuClearLog.Name = "menuClearLog";
            this.menuClearLog.Text = "C&lear Log";
            this.menuClearLog.Click += new System.EventHandler(this.menuClearLog_Click);

            this.menuExit.Name = "menuExit";
            this.menuExit.Text = "E&xit";
            this.menuExit.Click += new System.EventHandler(this.menuExit_Click);

            this.menuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.menuAbout });
            this.menuHelp.ForeColor = System.Drawing.Color.White;
            this.menuHelp.Name = "menuHelp";
            this.menuHelp.Text = "&Help";

            this.menuAbout.Name = "menuAbout";
            this.menuAbout.Text = "&About SecSimPro";
            this.menuAbout.Click += new System.EventHandler(this.menuAbout_Click);

            // ═══════════════════════════════════════════
            //  TOOL STRIP
            // ═══════════════════════════════════════════
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(44, 56, 82);
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.btnConnect, this.btnDisconnect, this.toolStripSep3 });
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.toolStrip1.Size = new System.Drawing.Size(900, 32);
            this.toolStrip1.Renderer = new DarkToolStripRenderer();

            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Text = "  Connect";
            this.btnConnect.ForeColor = System.Drawing.Color.White;
            this.btnConnect.Image = CreateCircleIcon(System.Drawing.Color.FromArgb(0, 200, 100), 14);
            this.btnConnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnConnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.ImageAndText;
            this.btnConnect.Padding = new System.Windows.Forms.Padding(4, 0, 8, 0);
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);

            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Text = "  Disconnect";
            this.btnDisconnect.ForeColor = System.Drawing.Color.White;
            this.btnDisconnect.Image = CreateCircleIcon(System.Drawing.Color.FromArgb(220, 60, 60), 14);
            this.btnDisconnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDisconnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.ImageAndText;
            this.btnDisconnect.Padding = new System.Windows.Forms.Padding(4, 0, 8, 0);
            this.btnDisconnect.Enabled = false;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);

            // ═══════════════════════════════════════════
            //  HEADER PANEL
            // ═══════════════════════════════════════════
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(22, 30, 50);
            this.pnlHeader.Controls.Add(this.lblTitle);
            this.pnlHeader.Controls.Add(this.lblSubtitle);
            this.pnlHeader.Controls.Add(this.picLogo);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Height = 64;
            this.pnlHeader.Name = "pnlHeader";

            this.picLogo.Size = new System.Drawing.Size(48, 48);
            this.picLogo.Location = new System.Drawing.Point(14, 8);
            this.picLogo.Image = CreateLogoImage();
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo.Name = "picLogo";

            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16f, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(72, 8);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Text = "SecSimPro";

            this.lblSubtitle.AutoSize = true;
            this.lblSubtitle.Font = new System.Drawing.Font("Segoe UI", 8.5f);
            this.lblSubtitle.ForeColor = System.Drawing.Color.FromArgb(140, 170, 210);
            this.lblSubtitle.Location = new System.Drawing.Point(74, 38);
            this.lblSubtitle.Name = "lblSubtitle";
            this.lblSubtitle.Text = "Equipment Connection Manager";

            // ═══════════════════════════════════════════
            //  SPLIT CONTAINER
            // ═══════════════════════════════════════════
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.SplitterDistance = 280;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Panel1MinSize = 250;
            this.splitContainer1.Panel2MinSize = 300;

            // ── Left Panel ──────────────────────────────
            this.splitContainer1.Panel1.Controls.Add(this.pnlStatusCard);
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);

            this.pnlStatusCard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlStatusCard.Padding = new System.Windows.Forms.Padding(10);
            this.pnlStatusCard.Name = "pnlStatusCard";
            this.pnlStatusCard.Controls.Add(this.grpStatus);
            this.pnlStatusCard.Controls.Add(this.pnlConnectBtn);

            // Status indicator dot
            this.picStatus.Size = new System.Drawing.Size(20, 20);
            this.picStatus.Location = new System.Drawing.Point(195, 22);
            this.picStatus.Name = "picStatus";
            this.picStatus.BackColor = System.Drawing.Color.Gray;
            // Make it round via Paint
            this.picStatus.Paint += (s, e2) =>
            {
                e2.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                e2.Graphics.FillEllipse(new System.Drawing.SolidBrush(this.picStatus.BackColor),
                    0, 0, this.picStatus.Width - 1, this.picStatus.Height - 1);
            };
            this.picStatus.BackColorChanged += (s, e2) => this.picStatus.Invalidate();

            // grpStatus
            this.grpStatus.Controls.Add(this.tableStatus);
            this.grpStatus.Controls.Add(this.picStatus);
            this.grpStatus.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpStatus.Height = 160;
            this.grpStatus.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.grpStatus.ForeColor = System.Drawing.Color.FromArgb(30, 60, 120);
            this.grpStatus.Name = "grpStatus";
            this.grpStatus.Text = "Connection Status";
            this.grpStatus.Padding = new System.Windows.Forms.Padding(6);

            // tableStatus (4 rows x 2 cols)
            this.tableStatus.ColumnCount = 2;
            this.tableStatus.RowCount = 4;
            this.tableStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110f));
            this.tableStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100f));
            this.tableStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25f));
            this.tableStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25f));
            this.tableStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25f));
            this.tableStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25f));
            this.tableStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableStatus.Padding = new System.Windows.Forms.Padding(4, 18, 4, 4);
            this.tableStatus.Name = "tableStatus";

            AddStatusRow(this.tableStatus, 0, "Status:", out this.lblStatusLbl, out this.lblStatusValue);
            AddStatusRow(this.tableStatus, 1, "Equipment:", out this.lblEquipmentLbl, out this.lblEquipmentValue);
            AddStatusRow(this.tableStatus, 2, "Connected At:", out this.lblConnectedAtLbl, out this.lblConnectedAtValue);
            AddStatusRow(this.tableStatus, 3, "Duration:", out this.lblDurationLbl, out this.lblDurationValue);

            this.lblStatusValue.ForeColor = System.Drawing.Color.FromArgb(120, 120, 120);

            // pnlConnectBtn
            this.pnlConnectBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlConnectBtn.Padding = new System.Windows.Forms.Padding(0, 12, 0, 0);
            this.pnlConnectBtn.Name = "pnlConnectBtn";
            this.pnlConnectBtn.Controls.Add(this.btnConnectLarge);
            this.pnlConnectBtn.Controls.Add(this.btnDisconnectLarge);

            this.btnConnectLarge.BackColor = System.Drawing.Color.FromArgb(0, 120, 180);
            this.btnConnectLarge.ForeColor = System.Drawing.Color.White;
            this.btnConnectLarge.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConnectLarge.FlatAppearance.BorderSize = 0;
            this.btnConnectLarge.Font = new System.Drawing.Font("Segoe UI", 10f, System.Drawing.FontStyle.Bold);
            this.btnConnectLarge.Location = new System.Drawing.Point(0, 12);
            this.btnConnectLarge.Name = "btnConnectLarge";
            this.btnConnectLarge.Size = new System.Drawing.Size(120, 38);
            this.btnConnectLarge.Text = "⚡  Connect";
            this.btnConnectLarge.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConnectLarge.Click += new System.EventHandler(this.btnConnect_Click);

            this.btnDisconnectLarge.BackColor = System.Drawing.Color.FromArgb(180, 40, 40);
            this.btnDisconnectLarge.ForeColor = System.Drawing.Color.White;
            this.btnDisconnectLarge.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDisconnectLarge.FlatAppearance.BorderSize = 0;
            this.btnDisconnectLarge.Font = new System.Drawing.Font("Segoe UI", 10f, System.Drawing.FontStyle.Bold);
            this.btnDisconnectLarge.Location = new System.Drawing.Point(130, 12);
            this.btnDisconnectLarge.Name = "btnDisconnectLarge";
            this.btnDisconnectLarge.Size = new System.Drawing.Size(120, 38);
            this.btnDisconnectLarge.Text = "✕  Disconnect";
            this.btnDisconnectLarge.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDisconnectLarge.Enabled = false;
            this.btnDisconnectLarge.Click += new System.EventHandler(this.btnDisconnect_Click);

            // Wire large buttons to same logic
            this.btnConnectLarge.Click += (s, e) => { };
            this.btnDisconnectLarge.Click += (s, e) => { };

            // Hook up large buttons to state-change so they stay in sync
            this.btnConnect.EnabledChanged += (s, e) =>
            {
                this.btnConnectLarge.Enabled = this.btnConnect.Enabled;
                this.btnConnectLarge.BackColor = this.btnConnect.Enabled
                    ? System.Drawing.Color.FromArgb(0, 120, 180)
                    : System.Drawing.Color.FromArgb(160, 180, 200);
            };
            this.btnDisconnect.EnabledChanged += (s, e) =>
            {
                this.btnDisconnectLarge.Enabled = this.btnDisconnect.Enabled;
                this.btnDisconnectLarge.BackColor = this.btnDisconnect.Enabled
                    ? System.Drawing.Color.FromArgb(180, 40, 40)
                    : System.Drawing.Color.FromArgb(200, 160, 160);
            };

            // ── Right Panel ─────────────────────────────
            this.splitContainer1.Panel2.Controls.Add(this.grpLog);

            this.grpLog.Controls.Add(this.rtbLog);
            this.grpLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpLog.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.grpLog.ForeColor = System.Drawing.Color.FromArgb(30, 60, 120);
            this.grpLog.Name = "grpLog";
            this.grpLog.Padding = new System.Windows.Forms.Padding(6);
            this.grpLog.Text = "Activity Log";

            this.rtbLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbLog.BackColor = System.Drawing.Color.FromArgb(18, 22, 34);
            this.rtbLog.ForeColor = System.Drawing.Color.FromArgb(200, 210, 230);
            this.rtbLog.Font = new System.Drawing.Font("Consolas", 9f);
            this.rtbLog.ReadOnly = true;
            this.rtbLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbLog.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbLog.Name = "rtbLog";
            this.rtbLog.WordWrap = true;

            // ═══════════════════════════════════════════
            //  STATUS STRIP
            // ═══════════════════════════════════════════
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.toolStripStatusLabel, this.toolStripVersion });
            this.statusStrip1.Name = "statusStrip1";

            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Text = "Not connected";
            this.toolStripStatusLabel.Spring = true;
            this.toolStripStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            this.toolStripVersion.Name = "toolStripVersion";
            this.toolStripVersion.Text = "SecSimPro v1.0";
            this.toolStripVersion.ForeColor = System.Drawing.Color.FromArgb(120, 120, 140);

            // ═══════════════════════════════════════════
            //  TIMER
            // ═══════════════════════════════════════════
            this.tmrConnected.Interval = 1000;
            this.tmrConnected.Tick += new System.EventHandler(this.tmrConnected_Tick);

            // ═══════════════════════════════════════════
            //  FORM
            // ═══════════════════════════════════════════
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 580);
            this.MinimumSize = new System.Drawing.Size(720, 480);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.5f);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SecSimPro - Equipment Manager";

            // Resume
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.pnlStatusCard.ResumeLayout(false);
            this.grpStatus.ResumeLayout(false);
            this.tableStatus.ResumeLayout(false);
            this.tableStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStatus)).EndInit();
            this.pnlConnectBtn.ResumeLayout(false);
            this.grpLog.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // ─────────────────────────────────────────────────
        //  Helpers
        // ─────────────────────────────────────────────────

        private void AddStatusRow(System.Windows.Forms.TableLayoutPanel table, int row,
            string labelText,
            out System.Windows.Forms.Label labelCtrl,
            out System.Windows.Forms.Label valueCtrl)
        {
            labelCtrl = new System.Windows.Forms.Label
            {
                Text = labelText,
                Dock = System.Windows.Forms.DockStyle.Fill,
                TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                ForeColor = System.Drawing.Color.FromArgb(90, 100, 120),
                Font = new System.Drawing.Font("Segoe UI", 8.5f),
                Padding = new System.Windows.Forms.Padding(0, 0, 8, 0)
            };

            valueCtrl = new System.Windows.Forms.Label
            {
                Text = "---",
                Dock = System.Windows.Forms.DockStyle.Fill,
                TextAlign = System.Drawing.ContentAlignment.MiddleLeft,
                ForeColor = System.Drawing.Color.FromArgb(30, 30, 30),
                Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold)
            };

            table.Controls.Add(labelCtrl, 0, row);
            table.Controls.Add(valueCtrl, 1, row);
        }

        private System.Drawing.Image CreateCircleIcon(System.Drawing.Color color, int size)
        {
            var bmp = new System.Drawing.Bitmap(size, size);
            using (var g = System.Drawing.Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(System.Drawing.Color.Transparent);
                g.FillEllipse(new System.Drawing.SolidBrush(color), 1, 1, size - 2, size - 2);
            }
            return bmp;
        }

        private System.Drawing.Image CreateLogoImage()
        {
            var bmp = new System.Drawing.Bitmap(48, 48);
            using (var g = System.Drawing.Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(System.Drawing.Color.Transparent);

                // Outer circle
                g.FillEllipse(new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(0, 120, 200)), 0, 0, 47, 47);
                // Inner circle
                g.FillEllipse(new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(22, 30, 50)), 8, 8, 31, 31);
                // Center dot
                g.FillEllipse(new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(0, 200, 120)), 16, 16, 15, 15);
            }
            return bmp;
        }

        #endregion

        // ─────────────────────────────────────────────────
        //  Custom Renderers (dark menu/toolbar)
        // ─────────────────────────────────────────────────

        private class DarkMenuRenderer : System.Windows.Forms.ToolStripProfessionalRenderer
        {
            public DarkMenuRenderer() : base(new DarkColorTable()) { }
        }

        private class DarkToolStripRenderer : System.Windows.Forms.ToolStripProfessionalRenderer
        {
            public DarkToolStripRenderer() : base(new DarkToolColorTable()) { }
            protected override void OnRenderButtonBackground(System.Windows.Forms.ToolStripItemRenderEventArgs e)
            {
                if (e.Item.Selected || e.Item.Pressed)
                {
                    var r = new System.Drawing.Rectangle(2, 2, e.Item.Width - 4, e.Item.Height - 4);
                    e.Graphics.FillRectangle(new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(70, 90, 130)), r);
                }
            }
        }

        private class DarkColorTable : System.Windows.Forms.ProfessionalColorTable
        {
            public override System.Drawing.Color MenuStripGradientBegin => System.Drawing.Color.FromArgb(30, 40, 60);
            public override System.Drawing.Color MenuStripGradientEnd   => System.Drawing.Color.FromArgb(30, 40, 60);
            public override System.Drawing.Color MenuBorder             => System.Drawing.Color.FromArgb(60, 80, 110);
            public override System.Drawing.Color MenuItemSelected        => System.Drawing.Color.FromArgb(50, 70, 110);
            public override System.Drawing.Color MenuItemBorder          => System.Drawing.Color.FromArgb(80, 120, 180);
            public override System.Drawing.Color ToolStripDropDownBackground => System.Drawing.Color.FromArgb(30, 40, 60);
            public override System.Drawing.Color ImageMarginGradientBegin => System.Drawing.Color.FromArgb(40, 55, 80);
            public override System.Drawing.Color ImageMarginGradientMiddle => System.Drawing.Color.FromArgb(40, 55, 80);
            public override System.Drawing.Color ImageMarginGradientEnd   => System.Drawing.Color.FromArgb(40, 55, 80);
        }

        private class DarkToolColorTable : System.Windows.Forms.ProfessionalColorTable
        {
            public override System.Drawing.Color ToolStripGradientBegin => System.Drawing.Color.FromArgb(44, 56, 82);
            public override System.Drawing.Color ToolStripGradientMiddle => System.Drawing.Color.FromArgb(44, 56, 82);
            public override System.Drawing.Color ToolStripGradientEnd   => System.Drawing.Color.FromArgb(44, 56, 82);
            public override System.Drawing.Color ToolStripBorder         => System.Drawing.Color.FromArgb(30, 40, 60);
        }

        // ─────────────────────────────────────────────────
        //  Fields
        // ─────────────────────────────────────────────────
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuFile;
        private System.Windows.Forms.ToolStripMenuItem menuConnect;
        private System.Windows.Forms.ToolStripMenuItem menuDisconnect;
        private System.Windows.Forms.ToolStripSeparator toolStripSep1;
        private System.Windows.Forms.ToolStripMenuItem menuClearLog;
        private System.Windows.Forms.ToolStripSeparator toolStripSep2;
        private System.Windows.Forms.ToolStripMenuItem menuExit;
        private System.Windows.Forms.ToolStripMenuItem menuHelp;
        private System.Windows.Forms.ToolStripMenuItem menuAbout;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnConnect;
        private System.Windows.Forms.ToolStripButton btnDisconnect;
        private System.Windows.Forms.ToolStripSeparator toolStripSep3;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSubtitle;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel pnlStatusCard;
        private System.Windows.Forms.GroupBox grpStatus;
        private System.Windows.Forms.TableLayoutPanel tableStatus;
        private System.Windows.Forms.Label lblStatusLbl;
        private System.Windows.Forms.Label lblStatusValue;
        private System.Windows.Forms.Label lblEquipmentLbl;
        private System.Windows.Forms.Label lblEquipmentValue;
        private System.Windows.Forms.Label lblConnectedAtLbl;
        private System.Windows.Forms.Label lblConnectedAtValue;
        private System.Windows.Forms.Label lblDurationLbl;
        private System.Windows.Forms.Label lblDurationValue;
        private System.Windows.Forms.PictureBox picStatus;
        private System.Windows.Forms.Panel pnlConnectBtn;
        private System.Windows.Forms.Button btnConnectLarge;
        private System.Windows.Forms.Button btnDisconnectLarge;
        private System.Windows.Forms.GroupBox grpLog;
        private System.Windows.Forms.RichTextBox rtbLog;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripVersion;
        private System.Windows.Forms.Timer tmrConnected;
    }
}
