namespace SecSimPro.Forms
{
    partial class ConnectionForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.grpSaved = new System.Windows.Forms.GroupBox();
            this.btnDeleteProfile = new System.Windows.Forms.Button();
            this.cmbSavedProfiles = new System.Windows.Forms.ComboBox();
            this.lblSavedProfiles = new System.Windows.Forms.Label();
            this.grpConnection = new System.Windows.Forms.GroupBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblProfileName = new System.Windows.Forms.Label();
            this.txtProfileName = new System.Windows.Forms.TextBox();
            this.lblPort = new System.Windows.Forms.Label();
            this.numPort = new System.Windows.Forms.NumericUpDown();
            this.lblIpAddress = new System.Windows.Forms.Label();
            this.txtIpAddress = new System.Windows.Forms.TextBox();
            this.grpOptions = new System.Windows.Forms.GroupBox();
            this.chkAutoReconnect = new System.Windows.Forms.CheckBox();
            this.lblTimeout = new System.Windows.Forms.Label();
            this.numTimeout = new System.Windows.Forms.NumericUpDown();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblTimeoutUnit = new System.Windows.Forms.Label();

            this.grpSaved.SuspendLayout();
            this.grpConnection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPort)).BeginInit();
            this.grpOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTimeout)).BeginInit();
            this.pnlButtons.SuspendLayout();
            this.SuspendLayout();

            // grpSaved
            this.grpSaved.Controls.Add(this.btnDeleteProfile);
            this.grpSaved.Controls.Add(this.cmbSavedProfiles);
            this.grpSaved.Controls.Add(this.lblSavedProfiles);
            this.grpSaved.Location = new System.Drawing.Point(12, 12);
            this.grpSaved.Name = "grpSaved";
            this.grpSaved.Size = new System.Drawing.Size(430, 60);
            this.grpSaved.TabIndex = 0;
            this.grpSaved.TabStop = false;
            this.grpSaved.Text = "Saved Profiles";
            this.grpSaved.ForeColor = System.Drawing.Color.FromArgb(0, 120, 180);

            this.lblSavedProfiles.AutoSize = true;
            this.lblSavedProfiles.Location = new System.Drawing.Point(8, 26);
            this.lblSavedProfiles.Name = "lblSavedProfiles";
            this.lblSavedProfiles.Text = "Load Profile:";
            this.lblSavedProfiles.ForeColor = System.Drawing.Color.FromArgb(60, 60, 60);

            this.cmbSavedProfiles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSavedProfiles.Location = new System.Drawing.Point(90, 22);
            this.cmbSavedProfiles.Name = "cmbSavedProfiles";
            this.cmbSavedProfiles.Size = new System.Drawing.Size(240, 21);
            this.cmbSavedProfiles.TabIndex = 1;
            this.cmbSavedProfiles.SelectedIndexChanged += new System.EventHandler(this.cmbSavedProfiles_SelectedIndexChanged);

            this.btnDeleteProfile.Location = new System.Drawing.Point(340, 20);
            this.btnDeleteProfile.Name = "btnDeleteProfile";
            this.btnDeleteProfile.Size = new System.Drawing.Size(75, 25);
            this.btnDeleteProfile.TabIndex = 2;
            this.btnDeleteProfile.Text = "Delete";
            this.btnDeleteProfile.UseVisualStyleBackColor = true;
            this.btnDeleteProfile.Click += new System.EventHandler(this.btnDeleteProfile_Click);

            // grpConnection
            this.grpConnection.Controls.Add(this.lblDescription);
            this.grpConnection.Controls.Add(this.txtDescription);
            this.grpConnection.Controls.Add(this.lblProfileName);
            this.grpConnection.Controls.Add(this.txtProfileName);
            this.grpConnection.Controls.Add(this.lblPort);
            this.grpConnection.Controls.Add(this.numPort);
            this.grpConnection.Controls.Add(this.lblIpAddress);
            this.grpConnection.Controls.Add(this.txtIpAddress);
            this.grpConnection.Location = new System.Drawing.Point(12, 82);
            this.grpConnection.Name = "grpConnection";
            this.grpConnection.Size = new System.Drawing.Size(430, 145);
            this.grpConnection.TabIndex = 1;
            this.grpConnection.TabStop = false;
            this.grpConnection.Text = "Connection Settings";
            this.grpConnection.ForeColor = System.Drawing.Color.FromArgb(0, 120, 180);

            int labelX = 12, ctrlX = 130, rowH = 28;

            this.lblIpAddress.AutoSize = true;
            this.lblIpAddress.Location = new System.Drawing.Point(labelX, 26);
            this.lblIpAddress.Text = "IP Address *:";
            this.lblIpAddress.ForeColor = System.Drawing.Color.FromArgb(60, 60, 60);

            this.txtIpAddress.Location = new System.Drawing.Point(ctrlX, 23);
            this.txtIpAddress.Name = "txtIpAddress";
            this.txtIpAddress.Size = new System.Drawing.Size(180, 20);
            this.txtIpAddress.TabIndex = 1;
            this.txtIpAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIpAddress_KeyPress);
            this.txtIpAddress.Font = new System.Drawing.Font("Consolas", 9.5f);

            this.lblPort.AutoSize = true;
            this.lblPort.Location = new System.Drawing.Point(labelX, 26 + rowH);
            this.lblPort.Text = "Port *:";
            this.lblPort.ForeColor = System.Drawing.Color.FromArgb(60, 60, 60);

            this.numPort.Location = new System.Drawing.Point(ctrlX, 23 + rowH);
            this.numPort.Maximum = 65535;
            this.numPort.Minimum = 1;
            this.numPort.Name = "numPort";
            this.numPort.Size = new System.Drawing.Size(90, 20);
            this.numPort.TabIndex = 2;
            this.numPort.Value = 102;
            this.numPort.Font = new System.Drawing.Font("Consolas", 9.5f);

            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(labelX, 26 + rowH * 2);
            this.lblDescription.Text = "Description:";
            this.lblDescription.ForeColor = System.Drawing.Color.FromArgb(60, 60, 60);

            this.txtDescription.Location = new System.Drawing.Point(ctrlX, 23 + rowH * 2);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(285, 20);
            this.txtDescription.TabIndex = 3;
            this.txtDescription.PlaceholderText = "Optional equipment description";

            this.lblProfileName.AutoSize = true;
            this.lblProfileName.Location = new System.Drawing.Point(labelX, 26 + rowH * 3);
            this.lblProfileName.Text = "Save As Profile:";
            this.lblProfileName.ForeColor = System.Drawing.Color.FromArgb(60, 60, 60);

            this.txtProfileName.Location = new System.Drawing.Point(ctrlX, 23 + rowH * 3);
            this.txtProfileName.Name = "txtProfileName";
            this.txtProfileName.Size = new System.Drawing.Size(285, 20);
            this.txtProfileName.TabIndex = 4;
            this.txtProfileName.PlaceholderText = "Profile name (leave blank to not save)";

            // grpOptions
            this.grpOptions.Controls.Add(this.lblTimeoutUnit);
            this.grpOptions.Controls.Add(this.chkAutoReconnect);
            this.grpOptions.Controls.Add(this.lblTimeout);
            this.grpOptions.Controls.Add(this.numTimeout);
            this.grpOptions.Location = new System.Drawing.Point(12, 237);
            this.grpOptions.Name = "grpOptions";
            this.grpOptions.Size = new System.Drawing.Size(430, 65);
            this.grpOptions.TabIndex = 2;
            this.grpOptions.TabStop = false;
            this.grpOptions.Text = "Advanced Options";
            this.grpOptions.ForeColor = System.Drawing.Color.FromArgb(0, 120, 180);

            this.lblTimeout.AutoSize = true;
            this.lblTimeout.Location = new System.Drawing.Point(12, 26);
            this.lblTimeout.Text = "Timeout:";
            this.lblTimeout.ForeColor = System.Drawing.Color.FromArgb(60, 60, 60);

            this.numTimeout.Location = new System.Drawing.Point(80, 23);
            this.numTimeout.Maximum = 120;
            this.numTimeout.Minimum = 1;
            this.numTimeout.Name = "numTimeout";
            this.numTimeout.Size = new System.Drawing.Size(60, 20);
            this.numTimeout.TabIndex = 1;
            this.numTimeout.Value = 10;

            this.lblTimeoutUnit.AutoSize = true;
            this.lblTimeoutUnit.Location = new System.Drawing.Point(146, 26);
            this.lblTimeoutUnit.Text = "seconds";
            this.lblTimeoutUnit.ForeColor = System.Drawing.Color.FromArgb(100, 100, 100);

            this.chkAutoReconnect.AutoSize = true;
            this.chkAutoReconnect.Location = new System.Drawing.Point(240, 25);
            this.chkAutoReconnect.Name = "chkAutoReconnect";
            this.chkAutoReconnect.TabIndex = 2;
            this.chkAutoReconnect.Text = "Auto-reconnect on loss";

            // pnlButtons
            this.pnlButtons.BackColor = System.Drawing.Color.FromArgb(240, 240, 240);
            this.pnlButtons.Controls.Add(this.btnConnect);
            this.pnlButtons.Controls.Add(this.btnCancel);
            this.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlButtons.Location = new System.Drawing.Point(0, 316);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(454, 48);
            this.pnlButtons.TabIndex = 3;

            this.btnConnect.BackColor = System.Drawing.Color.FromArgb(0, 120, 180);
            this.btnConnect.ForeColor = System.Drawing.Color.White;
            this.btnConnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConnect.FlatAppearance.BorderSize = 0;
            this.btnConnect.Font = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold);
            this.btnConnect.Location = new System.Drawing.Point(248, 10);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(100, 30);
            this.btnConnect.TabIndex = 0;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);

            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(358, 10);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(80, 30);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);

            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 364);
            this.Controls.Add(this.grpSaved);
            this.Controls.Add(this.grpConnection);
            this.Controls.Add(this.grpOptions);
            this.Controls.Add(this.pnlButtons);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ConnectionForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Connect to Equipment";
            this.Font = new System.Drawing.Font("Segoe UI", 8.5f);

            this.grpSaved.ResumeLayout(false);
            this.grpSaved.PerformLayout();
            this.grpConnection.ResumeLayout(false);
            this.grpConnection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPort)).EndInit();
            this.grpOptions.ResumeLayout(false);
            this.grpOptions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTimeout)).EndInit();
            this.pnlButtons.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox grpSaved;
        private System.Windows.Forms.Button btnDeleteProfile;
        private System.Windows.Forms.ComboBox cmbSavedProfiles;
        private System.Windows.Forms.Label lblSavedProfiles;
        private System.Windows.Forms.GroupBox grpConnection;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblProfileName;
        private System.Windows.Forms.TextBox txtProfileName;
        private System.Windows.Forms.Label lblPort;
        private System.Windows.Forms.NumericUpDown numPort;
        private System.Windows.Forms.Label lblIpAddress;
        private System.Windows.Forms.TextBox txtIpAddress;
        private System.Windows.Forms.GroupBox grpOptions;
        private System.Windows.Forms.CheckBox chkAutoReconnect;
        private System.Windows.Forms.Label lblTimeout;
        private System.Windows.Forms.NumericUpDown numTimeout;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblTimeoutUnit;
    }
}
