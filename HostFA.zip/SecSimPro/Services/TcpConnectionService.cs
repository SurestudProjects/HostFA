using System;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using SecSimPro.Models;

namespace SecSimPro.Services
{
    public class TcpConnectionService : IDisposable
    {
        private TcpClient _tcpClient;
        private CancellationTokenSource _cts;
        private Thread _keepAliveThread;
        private bool _disposed = false;

        public event EventHandler<ConnectionEventArgs> ConnectionStatusChanged;
        public event EventHandler<ConnectionEventArgs> LogMessage;

        public bool IsConnected => _tcpClient != null && _tcpClient.Connected;
        public EquipmentConnection CurrentConnection { get; private set; }

        public void Connect(ConnectionProfile profile)
        {
            if (IsConnected)
            {
                RaiseLog(ConnectionStatus.Error, "Already connected. Disconnect first.");
                return;
            }

            CurrentConnection = new EquipmentConnection
            {
                IpAddress = profile.IpAddress,
                Port = profile.Port,
                Description = profile.Description,
                Status = ConnectionStatus.Connecting
            };

            RaiseStatusChanged(ConnectionStatus.Connecting,
                $"Connecting to {profile.IpAddress}:{profile.Port}...",
                profile.IpAddress, profile.Port);

            Task.Run(() => DoConnect(profile));
        }

        private void DoConnect(ConnectionProfile profile)
        {
            try
            {
                _tcpClient = new TcpClient();
                _tcpClient.SendTimeout = profile.TimeoutSeconds * 1000;
                _tcpClient.ReceiveTimeout = profile.TimeoutSeconds * 1000;

                var connectTask = _tcpClient.ConnectAsync(profile.IpAddress, profile.Port);
                if (!connectTask.Wait(TimeSpan.FromSeconds(profile.TimeoutSeconds)))
                {
                    _tcpClient.Close();
                    _tcpClient = null;
                    CurrentConnection.Status = ConnectionStatus.Error;
                    RaiseStatusChanged(ConnectionStatus.Error,
                        $"Connection timed out after {profile.TimeoutSeconds} seconds.",
                        profile.IpAddress, profile.Port);
                    return;
                }

                if (_tcpClient.Connected)
                {
                    CurrentConnection.Status = ConnectionStatus.Connected;
                    CurrentConnection.ConnectedAt = DateTime.Now;
                    RaiseStatusChanged(ConnectionStatus.Connected,
                        $"Successfully connected to {profile.IpAddress}:{profile.Port}",
                        profile.IpAddress, profile.Port);

                    _cts = new CancellationTokenSource();
                    StartKeepAliveMonitor(_cts.Token);
                }
                else
                {
                    CurrentConnection.Status = ConnectionStatus.Error;
                    RaiseStatusChanged(ConnectionStatus.Error,
                        "Connection failed. Host refused the connection.",
                        profile.IpAddress, profile.Port);
                }
            }
            catch (SocketException ex)
            {
                if (CurrentConnection != null)
                    CurrentConnection.Status = ConnectionStatus.Error;

                string userMsg = GetSocketErrorMessage(ex.SocketErrorCode);
                RaiseStatusChanged(ConnectionStatus.Error,
                    $"Connection failed: {userMsg}",
                    profile.IpAddress, profile.Port);
            }
            catch (Exception ex)
            {
                if (CurrentConnection != null)
                    CurrentConnection.Status = ConnectionStatus.Error;

                RaiseStatusChanged(ConnectionStatus.Error,
                    $"Unexpected error: {ex.Message}",
                    profile.IpAddress, profile.Port);
            }
        }

        private void StartKeepAliveMonitor(CancellationToken token)
        {
            _keepAliveThread = new Thread(() =>
            {
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        Thread.Sleep(5000);

                        if (_tcpClient == null || !_tcpClient.Connected)
                        {
                            if (!token.IsCancellationRequested)
                            {
                                if (CurrentConnection != null)
                                    CurrentConnection.Status = ConnectionStatus.Error;

                                RaiseStatusChanged(ConnectionStatus.Error,
                                    "Connection lost unexpectedly.",
                                    CurrentConnection?.IpAddress ?? "",
                                    CurrentConnection?.Port ?? 0);
                            }
                            break;
                        }

                        // Check if socket is still alive
                        bool isAlive = !(_tcpClient.Client.Poll(1, SelectMode.SelectRead)
                                         && _tcpClient.Client.Available == 0);

                        if (!isAlive && !token.IsCancellationRequested)
                        {
                            if (CurrentConnection != null)
                                CurrentConnection.Status = ConnectionStatus.Error;

                            RaiseStatusChanged(ConnectionStatus.Error,
                                "Connection to equipment was lost.",
                                CurrentConnection?.IpAddress ?? "",
                                CurrentConnection?.Port ?? 0);
                            break;
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch
                    {
                        break;
                    }
                }
            })
            {
                IsBackground = true,
                Name = "KeepAliveMonitor"
            };

            _keepAliveThread.Start();
        }

        public void Disconnect()
        {
            try
            {
                _cts?.Cancel();

                string ip = CurrentConnection?.IpAddress ?? "";
                int port = CurrentConnection?.Port ?? 0;

                if (_tcpClient != null)
                {
                    _tcpClient.Close();
                    _tcpClient = null;
                }

                if (CurrentConnection != null)
                {
                    CurrentConnection.Status = ConnectionStatus.Disconnected;
                    CurrentConnection.DisconnectedAt = DateTime.Now;
                }

                RaiseStatusChanged(ConnectionStatus.Disconnected,
                    $"Disconnected from {ip}:{port}", ip, port);
            }
            catch (Exception ex)
            {
                RaiseLog(ConnectionStatus.Error, $"Error during disconnect: {ex.Message}");
            }
        }

        private string GetSocketErrorMessage(SocketError error)
        {
            switch (error)
            {
                case SocketError.ConnectionRefused:
                    return "Connection refused. Check that equipment is running and port is correct.";
                case SocketError.HostNotFound:
                case SocketError.HostUnreachable:
                    return "Host not found or unreachable. Check the IP address.";
                case SocketError.NetworkUnreachable:
                    return "Network unreachable. Check your network connection.";
                case SocketError.TimedOut:
                    return "Connection timed out. Equipment may be offline.";
                default:
                    return $"Socket error: {error}";
            }
        }

        private void RaiseStatusChanged(ConnectionStatus status, string message, string ip = "", int port = 0)
        {
            ConnectionStatusChanged?.Invoke(this, new ConnectionEventArgs(status, message, ip, port));
        }

        private void RaiseLog(ConnectionStatus status, string message)
        {
            LogMessage?.Invoke(this, new ConnectionEventArgs(status, message));
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                _cts?.Cancel();
                _tcpClient?.Close();
                _disposed = true;
            }
        }
    }
}
