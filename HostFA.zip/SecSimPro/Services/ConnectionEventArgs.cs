using System;

namespace SecSimPro.Services
{
    public enum ConnectionStatus
    {
        Disconnected,
        Connecting,
        Connected,
        Error
    }

    public class ConnectionEventArgs : EventArgs
    {
        public ConnectionStatus Status { get; set; }
        public string Message { get; set; }
        public DateTime Timestamp { get; set; }
        public string IpAddress { get; set; }
        public int Port { get; set; }

        public ConnectionEventArgs(ConnectionStatus status, string message, string ip = "", int port = 0)
        {
            Status = status;
            Message = message;
            Timestamp = DateTime.Now;
            IpAddress = ip;
            Port = port;
        }
    }
}
