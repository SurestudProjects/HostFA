using System;
using SecSimPro.Services;

namespace SecSimPro.Models
{
    public class EquipmentConnection
    {
        public string EquipmentId { get; set; }
        public string IpAddress { get; set; }
        public int Port { get; set; }
        public ConnectionStatus Status { get; set; }
        public DateTime? ConnectedAt { get; set; }
        public DateTime? DisconnectedAt { get; set; }
        public string Description { get; set; }

        public string DisplayName => string.IsNullOrWhiteSpace(Description)
            ? $"{IpAddress}:{Port}"
            : $"{Description} ({IpAddress}:{Port})";

        public string StatusText
        {
            get
            {
                switch (Status)
                {
                    case ConnectionStatus.Connected:
                        return ConnectedAt.HasValue
                            ? $"Connected since {ConnectedAt.Value:HH:mm:ss}"
                            : "Connected";
                    case ConnectionStatus.Connecting:
                        return "Connecting...";
                    case ConnectionStatus.Disconnected:
                        return "Disconnected";
                    case ConnectionStatus.Error:
                        return "Connection Error";
                    default:
                        return "Unknown";
                }
            }
        }

        public EquipmentConnection()
        {
            Status = ConnectionStatus.Disconnected;
            EquipmentId = Guid.NewGuid().ToString("N").Substring(0, 8).ToUpper();
        }
    }
}
