using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace SecSimPro.Models
{
    [Serializable]
    public class ConnectionProfile
    {
        public string ProfileName { get; set; }
        public string IpAddress { get; set; }
        public int Port { get; set; }
        public string Description { get; set; }
        public int TimeoutSeconds { get; set; }
        public bool AutoReconnect { get; set; }
        public DateTime CreatedAt { get; set; }

        public ConnectionProfile()
        {
            TimeoutSeconds = 10;
            AutoReconnect = false;
            CreatedAt = DateTime.Now;
        }

        public ConnectionProfile(string name, string ip, int port, string description = "") : this()
        {
            ProfileName = name;
            IpAddress = ip;
            Port = port;
            Description = description;
        }
    }

    [Serializable]
    [XmlRoot("ConnectionProfiles")]
    public class ConnectionProfileList
    {
        [XmlElement("Profile")]
        public List<ConnectionProfile> Profiles { get; set; } = new List<ConnectionProfile>();

        private static readonly string ProfilesPath =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                         "SecSimPro", "profiles.xml");

        public static ConnectionProfileList Load()
        {
            try
            {
                if (File.Exists(ProfilesPath))
                {
                    var serializer = new XmlSerializer(typeof(ConnectionProfileList));
                    using (var reader = new StreamReader(ProfilesPath))
                    {
                        return (ConnectionProfileList)serializer.Deserialize(reader);
                    }
                }
            }
            catch { /* Return empty list on error */ }

            return new ConnectionProfileList();
        }

        public void Save()
        {
            try
            {
                var dir = Path.GetDirectoryName(ProfilesPath);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                var serializer = new XmlSerializer(typeof(ConnectionProfileList));
                using (var writer = new StreamWriter(ProfilesPath))
                {
                    serializer.Serialize(writer, this);
                }
            }
            catch { /* Silently fail on save error */ }
        }
    }
}
