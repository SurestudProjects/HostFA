# SecSimPro — Equipment Connection Manager
### .NET 4.6 WinForms Application

A SECS/GEM-inspired equipment connection manager for connecting to manufacturing equipment via TCP/IP.

---

## Project Structure

```
SecSimPro/
├── SecSimPro.sln                        ← Open this in Visual Studio
└── SecSimPro/
    ├── SecSimPro.csproj                 ← .NET 4.6 WinForms project
    ├── Program.cs                        ← Entry point
    ├── Properties/
    │   └── AssemblyInfo.cs
    ├── Forms/
    │   ├── MainForm.cs / .Designer.cs   ← Main application window
    │   └── ConnectionForm.cs / .Designer.cs ← Connect dialog
    ├── Models/
    │   ├── EquipmentConnection.cs        ← Connection state model
    │   └── ConnectionProfile.cs         ← Saved profile (XML persistence)
    └── Services/
        ├── TcpConnectionService.cs       ← TCP connect/disconnect logic
        └── ConnectionEventArgs.cs        ← Event data / status enum
```

---

## How to Build & Run

### Requirements
- **Visual Studio 2017 / 2019 / 2022** (any edition)
- **.NET Framework 4.6** (included in Windows 8.1+)

### Steps
1. Open `SecSimPro.sln` in Visual Studio
2. Press **F5** (Debug) or **Ctrl+F5** (Run without debug)
3. No NuGet packages required — uses only built-in .NET 4.6 assemblies

---

## Features (v1.0)

| Feature | Details |
|---------|---------|
| **TCP Connect** | Connects to any equipment IP + Port via raw TCP socket |
| **Disconnect** | Prompts user for confirmation before disconnecting |
| **Saved Profiles** | Connection profiles saved to `%AppData%\SecSimPro\profiles.xml` |
| **Keep-Alive Monitor** | Background thread detects lost connections |
| **Activity Log** | Dark-themed timestamped log with color-coded severity levels |
| **Live Duration** | Shows elapsed connected time in real time |
| **Status Indicator** | Color-coded dot: Grey=Off, Orange=Connecting, Green=On, Red=Error |

---

## How to Connect to Your Equipment Simulator

1. Start your simulator and note the **IP address** and **port** it listens on
2. In SecSimPro, click **File → Connect** (or `Ctrl+N`, or the toolbar **Connect** button)
3. Enter the IP and port — optionally give it a name to save as a profile
4. Click **Connect**
5. The status indicator turns **green** when connected
6. To disconnect: click **Disconnect** and confirm the prompt

---

## Planned Enhancements (future)
- SECS-II message send/receive
- S1F1/S1F2 (Are You There) heartbeat
- Message log with hex dump
- Event subscriptions
- Equipment state machine visualization

---

## Default Port Reference

| Protocol | Default Port |
|----------|-------------|
| SECS-I / HSMS | 5000 / 5010 |
| S7 (Siemens PLC) | 102 |
| Modbus TCP | 502 |
| Custom TCP | User-defined |
